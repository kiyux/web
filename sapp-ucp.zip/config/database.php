<?php
/**
 * config/database.php
 * -----------------------------------------------------------------------
 * Koneksi PDO ke MySQL + pemetaan nama tabel/kolom.
 *
 * >>> [GANTI DI SINI] <<<  Sesuaikan nilai-nilai di bawah dengan struktur
 * database SA-MP Anda yang SUDAH ADA, TANPA perlu mengubah kode di file
 * lain (auth/register.php, dashboard/profile.php, dst).
 * -----------------------------------------------------------------------
 */

// -------------------------------------------------------------------------
// 1. KREDENSIAL DATABASE
// -------------------------------------------------------------------------
// PENTING (Least Privilege): JANGAN gunakan akun 'root' di sini.
// Buat user MySQL khusus lewat phpMyAdmin, contoh:
//
//   CREATE USER 'ucp_web'@'localhost' IDENTIFIED BY 'PASSWORD_KUAT_ACAK';
//   GRANT SELECT, INSERT, UPDATE ON nama_database.playerucp        TO 'ucp_web'@'localhost';
//   GRANT SELECT, INSERT, UPDATE ON nama_database.characters       TO 'ucp_web'@'localhost';
//   GRANT SELECT, INSERT, UPDATE ON nama_database.character_stories TO 'ucp_web'@'localhost';
//   GRANT SELECT, INSERT, UPDATE ON nama_database.refund_requests  TO 'ucp_web'@'localhost';
//   GRANT SELECT, INSERT, UPDATE ON nama_database.player_reports   TO 'ucp_web'@'localhost';
//   GRANT SELECT, INSERT          ON nama_database.admin_audit_log TO 'ucp_web'@'localhost';
//   GRANT SELECT                  ON nama_database.registration_quiz TO 'ucp_web'@'localhost';
//   -- JANGAN beri DROP, ALTER, GRANT OPTION, atau akses ke database lain.
//   FLUSH PRIVILEGES;
//
// Simpan kredensial di luar folder yang bisa diakses publik (di luar
// document root) jika hosting Anda memungkinkan, atau minimal pastikan
// file ini TIDAK bisa diakses langsung lewat browser (lihat .htaccess).

define('DB_HOST', getenv('DB_HOST') ?: '15.235.173.7');          // [GANTI DI SINI]
define('DB_NAME', getenv('DB_NAME') ?: 's244276_db1784159884526'); // [GANTI DI SINI]
define('DB_USER', getenv('DB_USER') ?: 'u244276_EZtWH2orl5');            // [GANTI DI SINI] JANGAN pakai root
define('DB_PASS', getenv('DB_PASS') ?: 'QDkL@^lvTpZ8ejsc7=wWofA4'); // [GANTI DI SINI] Sebaiknya via environment variable

// -------------------------------------------------------------------------
// 2. PEMETAAN TABEL & KOLOM AKUN (playerucp)
// -------------------------------------------------------------------------
// Jika nama tabel/kolom login Anda berbeda dari contoh, cukup ubah di sini.
// Seluruh query di file lain memanggil lewat konstanta ini, bukan hardcode.
define('TB_ACCOUNT', 'playerucp');   // [GANTI DI SINI] nama tabel akun
define('COL_ID', 'ID');              // [GANTI DI SINI]
define('COL_VERIFYCODE', 'verifycode');
define('COL_USERNAME', 'ucp');  // [GANTI DI SINI]
define('COL_PASSWORD', 'password');  // [GANTI DI SINI] kolom hash SHA-256 (64 char, uppercase)
define('COL_SALT', 'salt');          // [GANTI DI SINI]
define('COL_EMAIL', 'email');        // [GANTI DI SINI]
define('COL_ADMIN_LEVEL', 'admin_level'); // [GANTI DI SINI]
define('COL_IS_BANNED', 'is_banned');     // [GANTI DI SINI]

// -------------------------------------------------------------------------
// 3. URUTAN PENGGABUNGAN SALT + PASSWORD SEBELUM DI-HASH
// -------------------------------------------------------------------------
// WAJIB DICOCOKKAN dengan fungsi hashing di script gamemode PAWN Anda.
// Dua pola paling umum di SA-MP:
//   'salt_password' -> SHA256(salt . password)
//   'password_salt' -> SHA256(password . salt)
// Buka source gamemode Anda (biasanya di fungsi OnPlayerRegister /
// dini_Set / whirlpool-style hash) untuk memastikan urutan yang benar.
define('HASH_ORDER', 'salt_password'); // [GANTI DI SINI] 'salt_password' atau 'password_salt'

// -------------------------------------------------------------------------
// 4. KONEKSI PDO
// -------------------------------------------------------------------------
function getPDO(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // lempar exception, jangan tampilkan error mentah ke user
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false, // prepared statement asli dari MySQL, bukan emulasi PHP -> mitigasi SQL Injection lebih kuat
        ];
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            // Jangan pernah echo $e->getMessage() ke user di production (bisa bocorkan info DB)
            error_log('DB Connection Error: ' . $e->getMessage());
            http_response_code(500);
            die('Terjadi kesalahan pada server. Silakan coba lagi nanti.');
        }
    }
    return $pdo;
}
