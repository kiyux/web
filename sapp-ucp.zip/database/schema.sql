SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------------------------------------------------------
-- 1. TABEL CHARACTER STORY (character_stories)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `character_stories` (
  `story_id`     INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `char_id`      INT NOT NULL,                            
  `content`      TEXT NOT NULL,
  `status`       ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `reviewed_by`  INT NOT NULL,                            
  `review_note`  VARCHAR(255) DEFAULT NULL,
  `submitted_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `reviewed_at`  DATETIME DEFAULT NULL,
  PRIMARY KEY (`story_id`),
  KEY `idx_char` (`char_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------------------------
-- 2. TABEL REFUND REQUEST
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `refund_requests` (
  `refund_id`    INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `char_id`      INT NOT NULL,
  `item_name`    VARCHAR(100) NOT NULL,
  `description`  TEXT NOT NULL,
  `evidence_path` VARCHAR(255) DEFAULT NULL,
  `status`       ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `handled_by`   INT DEFAULT NULL,
  `created_at`   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `handled_at`   DATETIME DEFAULT NULL,
  PRIMARY KEY (`refund_id`),
  KEY `idx_char` (`char_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------------------------
-- 3. TABEL REPORT PLAYER
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `player_reports` (
  `report_id`     INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `reporter_char_id` INT NOT NULL,
  `target_char_name` VARCHAR(24) NOT NULL,
  `reason`        TEXT NOT NULL,
  `evidence_path` VARCHAR(255) DEFAULT NULL,
  `status`        ENUM('open','reviewing','closed') NOT NULL DEFAULT 'open',
  `handled_by`    INT DEFAULT NULL,
  `created_at`    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`report_id`),
  KEY `idx_reporter` (`reporter_char_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------------------------
-- 4. TABEL AUDIT LOG ADMIN
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `admin_audit_log` (
  `log_id`      BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `admin_id`    INT NOT NULL,
  `action`      VARCHAR(100) NOT NULL,                    
  `target_type` VARCHAR(50)  DEFAULT NULL,                
  `target_id`   INT DEFAULT NULL,
  `detail`      VARCHAR(255) DEFAULT NULL,
  `ip_address`  VARCHAR(45)  DEFAULT NULL,
  `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`log_id`),
  KEY `idx_admin` (`admin_id`),
  KEY `idx_action` (`action`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------------------------
-- 5. TABEL QUIZ RULES
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `registration_quiz` (
  `quiz_id`      INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `question`     VARCHAR(255) NOT NULL,
  `option_a`     VARCHAR(150) NOT NULL,
  `option_b`     VARCHAR(150) NOT NULL,
  `option_c`     VARCHAR(150) NOT NULL,
  `option_d`     VARCHAR(150) NOT NULL,
  `correct_option` ENUM('a','b','c','d') NOT NULL,
  `is_active`    TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`quiz_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Input data soal kuis otomatis
INSERT INTO `registration_quiz`
  (`question`,`option_a`,`option_b`,`option_c`,`option_d`,`correct_option`) VALUES
('Apa yang dimaksud dengan Metagaming?', 'Menggunakan informasi OOC di dalam IC', 'Bermain dengan banyak karakter sekaligus', 'Membeli kendaraan baru', 'Melapor bug ke admin', 'a'),
('Powergaming adalah tindakan yang...', 'Dilarang karena memaksakan aksi ke player lain tanpa peluang gagal', 'Diperbolehkan jika situasi mendesak', 'Hanya berlaku untuk admin', 'Tidak berkaitan dengan roleplay', 'a'),
('Bolehkah membagikan akun UCP ke orang lain (Share Account)?', 'Boleh, asal ke teman dekat', 'Tidak boleh, akun bersifat pribadi', 'Boleh jika sudah izin ke admin secara lisan', 'Boleh, tidak ada aturan terkait', 'b');

SET FOREIGN_KEY_CHECKS = 1;
