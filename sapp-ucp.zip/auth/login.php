<?php
/**
 * auth/login.php
 * Halaman Login UCP
 */
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../config/database.php';

session_start();

// Jika sudah login, langsung lempar ke dashboard
if (isset($_SESSION['ucp_logged_in'])) {
    header('Location: ../dashboard/profile.php');
    exit;
}

$errors = $_SESSION['login_errors'] ?? [];
unset($_SESSION['login_errors']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login UCP - Los Santos Roleplay</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-neutral-950 text-white bg-[url('/assets/img/los-santos-bg.jpg')] bg-cover bg-center bg-fixed">
<div class="min-h-screen bg-black/75 backdrop-blur-sm flex items-center justify-center px-4 py-10">

  <form action="login_process.php" method="POST"
        class="w-full max-w-md bg-neutral-900/60 backdrop-blur-xl border border-amber-500/20 rounded-2xl shadow-2xl p-6 sm:p-8 space-y-5">

    <h1 class="text-2xl sm:text-3xl font-bold text-amber-400 text-center tracking-wide">Login UCP</h1>
    <p class="text-center text-neutral-400 text-sm">Masuk untuk mengelola akun dan karakter Anda</p>

    <?php if (!empty($errors)): ?>
      <div class="bg-red-900/40 border border-red-500/40 rounded-lg p-3 text-sm text-red-200">
        <ul class="list-disc list-inside space-y-1">
          <?php foreach ($errors as $err): ?>
            <li><?= e($err) ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">

    <div class="space-y-4">
      <div>
        <label class="block text-sm text-neutral-300 mb-1">Username UCP</label>
        <input type="text" name="username" required
               class="w-full rounded-lg bg-neutral-800/70 border border-neutral-700 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 px-4 py-2.5 outline-none transition">
      </div>
      <div>
        <label class="block text-sm text-neutral-300 mb-1">Password</label>
        <input type="password" name="password" required
               class="w-full rounded-lg bg-neutral-800/70 border border-neutral-700 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 px-4 py-2.5 outline-none transition">
      </div>
    </div>

    <button type="submit"
            class="w-full bg-amber-500 hover:bg-amber-400 text-neutral-900 font-bold py-3 rounded-lg transition">
      Masuk
    </button>

    <div class="text-center pt-2">
      <p class="text-sm text-neutral-400">
        Belum memiliki akun? 
        <a href="register.php" class="text-amber-400 hover:text-amber-300 font-semibold transition hover:underline">
          Daftar di sini
        </a>
      </p>
    </div>

  </form>
</div>
</body>
</html>
