<?php
/**
 * auth/logout.php
 * Menghapus session login dan mengalihkan user kembali ke halaman login
 */

// 1. Jalankan session terlebih dahulu agar sistem tahu session mana yang mau dihapus
session_start();

// 2. Kosongkan semua data yang ada di dalam array $_SESSION
$_SESSION = array();

// 3. Hapus cookie session dari browser jika ada (opsional tapi sangat disarankan demi keamanan)
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params["path"],
        $params["domain"],
        $params["secure"],
        $params["httponly"]
    );
}

// 4. Hancurkan/destroy data session yang ada di server
session_destroy();

// 5. Alihkan user ke halaman login kembali
header("Location:/sapp-ucp/index.php");
exit;
