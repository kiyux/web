<?php
/**
 * auth/register.php
 * Menampilkan form registrasi + kuis rules dengan sistem step-by-step (satu per satu).
 * Proses validasi & insert database ada di auth/register_process.php
 */
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../config/database.php';

session_start();

// Ambil soal kuis aktif dari database secara acak sebanyak 10 soal
$pdo = getPDO();
$stmt = $pdo->query(
    "SELECT quiz_id, question, option_a, option_b, option_c, option_d
     FROM registration_quiz WHERE is_active = 1 ORDER BY RAND() LIMIT 10"
);
$questions = $stmt->fetchAll();
$totalQuiz = count($questions);

$errors = $_SESSION['register_errors'] ?? [];
unset($_SESSION['register_errors']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar UCP - Los Santos Roleplay</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-neutral-950 text-white bg-[url('/assets/img/los-santos-bg.jpg')] bg-cover bg-center bg-fixed">
<div class="min-h-screen bg-black/75 backdrop-blur-sm flex items-center justify-center px-4 py-10">

  <form action="register_process.php" method="POST" id="registerForm"
        class="w-full max-w-lg bg-neutral-900/60 backdrop-blur-xl border border-amber-500/20 rounded-2xl shadow-2xl p-6 sm:p-8 space-y-5">

    <h1 class="text-2xl sm:text-3xl font-bold text-amber-400 text-center tracking-wide mb-2">Daftar Akun UCP</h1>

    <?php if (isset($_SESSION['register_success'])): ?>
      <div class="bg-emerald-950/80 border border-emerald-500/40 rounded-xl p-4 text-sm text-emerald-200 space-y-3">
        <div>
          <?= $_SESSION['register_success'] ?>
        </div>
        <a href="login.php"
           class="inline-block text-center bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold px-4 py-2 rounded-lg text-xs tracking-wider transition">
          LOGIN SEKARANG
        </a>
        <?php unset($_SESSION['register_success']); ?>
      </div>
    <?php endif; ?>

        <?php if (!empty($errors)): ?>
      <!-- Tambahkan id="php-session-error" di bawah ini -->
      <div id="php-session-error" class="bg-red-900/40 border border-red-500/40 rounded-lg p-3 text-sm text-red-200">
        <ul class="list-disc list-inside space-y-1">
          <?php foreach ($errors as $err): ?>
            <li><?= e($err) ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">

    <!-- STEP 1: Pendaftaran Akun -->
    <div class="quiz-step space-y-4" id="step-1">
      <!-- Wadah Notifikasi Eror Dinamis untuk Step 1 -->
      <div id="js-error-container" class="hidden mb-4 text-xs p-3.5 rounded-xl border bg-red-950/40 border-red-500/30 text-red-400">
          <ul id="js-error-list" class="list-disc list-inside space-y-1"></ul>
      </div>

      <p class="text-center text-neutral-400 text-sm mb-4">Langkah 1: Silakan isi data akun UCP Anda</p>
      
      <div>
        <label class="block text-sm text-neutral-300 mb-1">Username (in-game)</label>
        <input type="text" name="username" required minlength="3" maxlength="24"
               pattern="[A-Za-z0-9_]{3,24}"
               class="w-full rounded-lg bg-neutral-800/70 border border-neutral-700 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 px-4 py-2.5 outline-none transition">
      </div>
      <div>
        <label class="block text-sm text-neutral-300 mb-1">Email</label>
        <input type="email" name="email" required
               class="w-full rounded-lg bg-neutral-800/70 border border-neutral-700 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 px-4 py-2.5 outline-none transition">
      </div>
      <div>
        <label class="block text-sm text-neutral-300 mb-1">Password</label>
        <input type="password" name="password" required minlength="8"
               class="w-full rounded-lg bg-neutral-800/70 border border-neutral-700 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 px-4 py-2.5 outline-none transition">
        <p class="text-xs text-neutral-500 mt-1">Minimal 8 karakter, kombinasi huruf & angka.</p>
      </div>

      <div class="pt-4 flex justify-between items-center">
        <p class="text-sm text-neutral-400">
          Sudah punya akun? <a href="login.php" class="text-amber-400 font-semibold hover:underline">Login</a>
        </p>
        <button type="button" onclick="nextStep(1)"
                class="bg-amber-500 hover:bg-amber-400 text-neutral-900 font-bold px-5 py-2.5 rounded-lg transition text-sm">
          Lanjut ke Kuis →
        </button>
      </div>
    </div>

    <!-- STEP 2 DST: Soal-soal Kuis -->
    <?php 
    $stepIndex = 2; 
    foreach ($questions as $index => $q): 
        $quizNo = $index + 1;
        $isLast = ($quizNo === $totalQuiz);
    ?>
      <div class="quiz-step hidden space-y-4" id="step-<?= $stepIndex ?>">
        <div class="flex justify-between items-center border-b border-neutral-800 pb-2">
          <h2 class="text-lg font-semibold text-amber-400">Kuis Peraturan Roleplay</h2>
          <span class="text-xs text-neutral-400 bg-neutral-800 px-2 py-1 rounded">Soal <?= $quizNo ?> dari <?= $totalQuiz ?></span>
        </div>

        <!-- Wadah Notifikasi Eror Khusus Lembar Kuis Ini -->
        <div id="quiz-error-<?= $stepIndex ?>" class="hidden text-xs p-3 rounded-xl border bg-red-950/40 border-red-500/30 text-red-400 font-medium tracking-wide">
            • Harap pilih salah satu jawaban kuis terlebih dahulu!
        </div>
        
        <fieldset class="space-y-3">
          <legend class="text-sm font-medium text-neutral-200 mb-3 leading-relaxed"><?= e($q['question']) ?></legend>
          
          <?php foreach (['a','b','c','d'] as $opt): ?>
            <?php if(!empty($q['option_' . $opt])): ?>
              <label class="flex items-center gap-3 text-sm text-neutral-300 bg-neutral-800/40 border border-neutral-800/60 rounded-xl px-4 py-3 cursor-pointer hover:bg-neutral-800 hover:border-neutral-700 transition group">
                <input type="radio" name="quiz[<?= (int)$q['quiz_id'] ?>]" value="<?= $opt ?>" required class="accent-amber-500 w-4 h-4">
                <span class="group-hover:text-white transition"><strong class="uppercase text-amber-500/85 font-mono"><?= $opt ?>.</strong> <?= e($q['option_' . $opt]) ?></span>
              </label>
            <?php endif; ?>
          <?php endforeach; ?>
        </fieldset>

        <div class="pt-4 flex justify-between gap-3">
          <button type="button" onclick="prevStep(<?= $stepIndex ?>)"
                  class="bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-white font-medium px-4 py-2.5 rounded-lg transition text-sm">
            ← Kembali
          </button>
          
          <?php if ($isLast): ?>
            <button type="submit" onclick="return validateLastStep(<?= $stepIndex ?>)"
                    class="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-6 py-2.5 rounded-lg transition text-sm shadow-md">
              Daftar Sekarang ✓
            </button>
          <?php else: ?>
            <button type="button" onclick="nextStep(<?= $stepIndex ?>)"
                    class="bg-amber-500 hover:bg-amber-400 text-neutral-900 font-bold px-5 py-2.5 rounded-lg transition text-sm">
              Pertanyaan Selanjutnya →
            </button>
          <?php endif; ?>
        </div>
      </div>
    <?php 
        $stepIndex++;
    endforeach; 
    ?>

  </form>
</div>

<script>
function nextStep(currentStep) {
    const currentContainer = document.getElementById('step-' + currentStep);
    let isValid = true;
    let errors = [];
    
    // Hapus/sembunyikan notifikasi eror PHP Session dari percobaan sebelumnya
    const phpSessionError = document.getElementById('php-session-error');
    if (phpSessionError) {
        phpSessionError.style.display = 'none';
    }
    
    // Reset eror Step 1 jika ada
    const errorContainer = document.getElementById('js-error-container');
    const errorList = document.getElementById('js-error-list');
    if (currentStep === 1 && errorContainer && errorList) {
        errorContainer.classList.add('hidden');
        errorList.innerHTML = "";
    }
    
    // Reset eror Step Kuis jika ada
    const quizErrorBox = document.getElementById('quiz-error-' + currentStep);
    if (quizErrorBox) {
        quizErrorBox.classList.add('hidden');
    }
    
    // VALIDASI STEP 1 (DATA AKUN)
    if (currentStep === 1) {
        const usernameInput = currentContainer.querySelector('input[name="username"]');
        const emailInput = currentContainer.querySelector('input[name="email"]');
        const passwordInput = currentContainer.querySelector('input[name="password"]');

        const usernameRegex = /^[A-Za-z0-9_]{3,24}$/;
        if (!usernameRegex.test(usernameInput.value.trim())) {
            isValid = false;
            errors.push("Username hanya boleh huruf, angka, underscore (3-24 karakter).");
        }

        if (!emailInput.checkValidity() || !emailInput.value.trim()) {
            isValid = false;
            errors.push("Format email tidak valid.");
        }

        const passwordValue = passwordInput.value;
        const hasLetter = /[A-Za-z]/.test(passwordValue);
        const hasNumber = /[0-9]/.test(passwordValue);

        if (passwordValue.length < 8 || !hasLetter || !hasNumber) {
            isValid = false;
            errors.push("Password minimal 8 karakter dan mengandung kombinasi huruf & angka.");
        }
    } 
    // VALIDASI STEP KUIS (RADIO BUTTONS MAJU)
    else {
        const requiredInputs = currentContainer.querySelectorAll('input[required]');
        if (requiredInputs.length > 0 && requiredInputs[0].type === 'radio') {
            const nameGroup = requiredInputs[0].name;
            const escapedName = nameGroup.replace(/\[/g, '\\[').replace(/\]/g, '\\]');
            const checkedRadio = currentContainer.querySelector(`input[name="${escapedName}"]:checked`);
            if (!checkedRadio) {
                isValid = false;
            }
        }
    }

    // JIKA ADA EROR SUNTIKKAN KE HALAMAN
    if (!isValid) {
        if (currentStep === 1 && errorContainer && errorList) {
            errors.forEach(function(msg) {
                const li = document.createElement('li');
                li.textContent = msg;
                errorList.appendChild(li);
            });
            errorContainer.classList.remove('hidden');
        } else if (quizErrorBox) {
            // Munculkan kotak merah peringatan kuis di dalam halaman kuis aktif
            quizErrorBox.classList.remove('hidden');
        }
        currentContainer.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        return;
    }

    // JIKA BERHASIL LANJUT KE STEP BERIKUTNYA
    currentContainer.classList.add('hidden');
    const nextContainer = document.getElementById('step-' + (currentStep + 1));
    if (nextContainer) {
        nextContainer.classList.remove('hidden');
    }
}

// VALIDASI KHUSUS TOMBOL DAFTAR DI SOAL TERAKHIR
function validateLastStep(currentStep) {
    const currentContainer = document.getElementById('step-' + currentStep);
    const quizErrorBox = document.getElementById('quiz-error-' + currentStep);
    
    if (quizErrorBox) {
        quizErrorBox.classList.add('hidden');
    }

    const requiredInputs = currentContainer.querySelectorAll('input[required]');
    if (requiredInputs.length > 0 && requiredInputs[0].type === 'radio') {
        const nameGroup = requiredInputs[0].name;
        const escapedName = nameGroup.replace(/\[/g, '\\[').replace(/\]/g, '\\]');
        const checkedRadio = currentContainer.querySelector(`input[name="${escapedName}"]:checked`);
        
        if (!checkedRadio) {
            if (quizErrorBox) {
                quizErrorBox.classList.remove('hidden');
                currentContainer.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            }
            return false; // Gagalkan submit form ke register_process.php
        }
    }
    return true; // Izinkan submit form jika sudah terisi
}

function prevStep(currentStep) {
    // Sembunyikan pesan eror kuis saat menekan tombol kembali
    const quizErrorBox = document.getElementById('quiz-error-' + currentStep);
    if (quizErrorBox) {
        quizErrorBox.classList.add('hidden');
    }
    document.getElementById('step-' + currentStep).classList.add('hidden');
    document.getElementById('step-' + (currentStep - 1)).classList.remove('hidden');
}
</script>

</body>
</html>
