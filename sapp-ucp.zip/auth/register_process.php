<?php
/**
 * auth/register_process.php
 * -----------------------------------------------------------------------
 * Memproses submit form registrasi:
 *   1. Verifikasi CSRF token
 *   2. Rate limiting sederhana
 *   3. Validasi & sanitasi input (regex)
 *   4. Cek jawaban kuis rules — SEMUA harus benar, jika ada yang salah
 *      registrasi ditolak
 *   5. Cek duplikasi username/email (prepared statement)
 *   6. Generate salt acak + hash SHA-256 uppercase (sinkron dgn PAWN)
 *   7. Insert ke database via prepared statement (PDO) — anti SQL Injection
 * -----------------------------------------------------------------------
 */

declare(strict_types=1);

require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../config/database.php';

session_start();
// Hapus session sukses sebelumnya (jika ada) agar tidak memicu bug tampilan ganda
unset($_SESSION['register_success']);
unset($_SESSION['register_errors']);

function fail(string $message): void
{
    $_SESSION['register_errors'] = [$message];
    header('Location: register.php');
    exit;
}

// Hanya terima POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: register.php');
    exit;
}

// -------------------------------------------------------------------------
// 1. CSRF PROTECTION
// -------------------------------------------------------------------------
if (!verifyCsrfToken($_POST['csrf_token'] ?? null)) {
    fail('Sesi form tidak valid atau kedaluwarsa. Silakan coba lagi.');
}

// -------------------------------------------------------------------------
// 2. RATE LIMITING (mitigasi spam / brute-force pendaftaran otomatis)
// -------------------------------------------------------------------------
$clientIp = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
if (tooManyAttempts('register_' . $clientIp, maxAttempts: 5, windowSeconds: 600)) {
    fail('Terlalu banyak percobaan pendaftaran. Coba lagi dalam beberapa menit.');
}

// -------------------------------------------------------------------------
// 3. VALIDASI & SANITASI INPUT
// -------------------------------------------------------------------------
$username = trim((string)($_POST['username'] ?? ''));
$email    = trim((string)($_POST['email'] ?? ''));
$password = (string)($_POST['password'] ?? '');
$quizAnswers = $_POST['quiz'] ?? [];

$errors = [];

if (!isValidUsername($username)) {
    $errors[] = 'Username hanya boleh huruf, angka, underscore (3-24 karakter).';
}
if (!isValidEmail($email)) {
    $errors[] = 'Format email tidak valid.';
}
if (!isStrongPassword($password)) {
    $errors[] = 'Password minimal 8 karakter dan mengandung huruf & angka.';
}
if (!is_array($quizAnswers) || count($quizAnswers) === 0) {
    $errors[] = 'Kuis peraturan wajib dijawab.';
}

if (!empty($errors)) {
    $_SESSION['register_errors'] = $errors;
    header('Location: register.php');
    exit;
}

$pdo = getPDO();

// -------------------------------------------------------------------------
// 4. VALIDASI JAWABAN KUIS — MINIMAL 8 DARI 10 SOAL BENAR
// -------------------------------------------------------------------------
$quizIds = array_map('intval', array_keys($quizAnswers));
$totalQuestionsTested = 10; 

// Cek apakah player menjawab kurang dari 10 soal
if (count($quizIds) < $totalQuestionsTested) {
    fail('Anda harus menjawab semua 10 pertanyaan kuis yang diberikan!');
}

// Ambil kunci jawaban dari database
$placeholders = implode(',', array_fill(0, count($quizIds), '?'));
$stmt = $pdo->prepare(
    "SELECT quiz_id, correct_option FROM registration_quiz WHERE quiz_id IN ($placeholders)"
);
$stmt->execute($quizIds);
$correctMap = [];
foreach ($stmt->fetchAll() as $row) {
    $correctMap[(int)$row['quiz_id']] = $row['correct_option'];
}

// Proses hitung jawaban benar
$scoreCorrect = 0;
foreach ($quizAnswers as $qid => $answer) {
    $qid = (int)$qid;
    $answer = strtolower((string)$answer);
    
    // Jika jawaban cocok dengan database, tambahkan skor
    if (isset($correctMap[$qid]) && $correctMap[$qid] === $answer) {
        $scoreCorrect++;
    }
}

// Syarat kelulusan: Jika jawaban benar kurang dari 8, registrasi ditolak
if ($scoreCorrect < 8) {
    fail("Pendaftaran gagal! Anda hanya menjawab benar {$scoreCorrect} dari 10 soal. (Minimal diperlukan 8 jawaban benar). Silakan pelajari rules kembali!");
}

// -------------------------------------------------------------------------
// 5. CEK DUPLIKASI USERNAME / EMAIL
// -------------------------------------------------------------------------
$table = TB_ACCOUNT; // nilai dari config, bukan input user -> aman diselipkan ke query
$stmt = $pdo->prepare(
    "SELECT " . COL_ID . " FROM `$table` WHERE " . COL_USERNAME . " = :username OR " . COL_EMAIL . " = :email LIMIT 1"
);
$stmt->execute([':username' => $username, ':email' => $email]);

if ($stmt->fetch()) {
    fail('Username atau email sudah terdaftar.');
}

// -------------------------------------------------------------------------
// 6. GENERATE SALT & HASH PASSWORD (SHA-256 + SALT, UPPERCASE)
// -------------------------------------------------------------------------
$salt = generateSalt(16);                 // [GANTI DI SINI] panjang salt jika berbeda dari script PAWN
// Pastikan urutannya password baru salt saat di-hash
$hashedPassword = strtoupper(hash('sha256', $password . $salt));// otomatis strtoupper() di dalam fungsi

// -------------------------------------------------------------------------
// 7. INSERT AKUN BARU — HANYA KOLOM UTAMA UCP
// -------------------------------------------------------------------------
// Generate angka acak 6 digit untuk kode verifikasi in-game
$generatedVerifyCode = rand(100000, 999999);

try {
    $insert = $pdo->prepare(
        "INSERT INTO `$table`
            (" . COL_USERNAME . ", " . COL_PASSWORD . ", " . COL_SALT . ", " . COL_EMAIL . ", verifycode)
         VALUES
            (:username, :password, :salt, :email, :verifycode)"
    );
    $insert->execute([
        ':username'    => $username,
        ':password'    => $hashedPassword,
        ':salt'        => $salt,
        ':email'       => $email,
        ':verifycode'  => $generatedVerifyCode,
    ]);
} catch (PDOException $e) {
    error_log('Register insert error: ' . $e->getMessage());
    // Menampilkan error jika sewaktu-waktu masih ada bentrok kolom database
    fail('Gagal membuat akun. Error: ' . $e->getMessage());
}

// Regenerasi session ID setelah aksi sensitif
session_regenerate_id(true);

$_SESSION['register_success'] = "Akun berhasil dibuat! Kode verifikasi game Anda adalah: <strong style='color:#ffc107; font-size:1.2rem;'>" . $generatedVerifyCode . "</strong>. Silakan catat kode ini untuk login pertama kali di dalam server game.";
header('Location: register.php');
exit;

