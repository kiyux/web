<?php
/**
 * auth/login_process.php
 * Memproses verifikasi login akun UCP
 */
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../config/database.php';

session_start();

// Fungsi untuk mengembalikan user ke halaman login jika terjadi error
function loginFail(string $message): void
{
    $_SESSION['login_errors'] = [$message];
    header('Location: login.php');
    exit;
}

// 1. Validasi Request Method & CSRF Token
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: login.php');
    exit;
}

if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== ($_SESSION['csrf_token'] ?? '')) {
    loginFail('Token keamanan kedaluwarsa. Silakan refresh halaman dan coba lagi.');
}

// 2. Ambil dan Bersihkan Input Form
$username = trim($_POST['username'] ?? '');
$password = $_POST['password'] ?? '';

if (empty($username) || empty($password)) {
    loginFail('Username dan Password wajib diisi.');
}

try {
    $pdo = getPDO();

    // 3. Cari Akun UCP Berdasarkan Nama (case-insensitive)
    // TB_ACCOUNT = 'playerucp', COL_USERNAME = 'ucp' (sesuai database.php Anda)
    $stmt = $pdo->prepare("SELECT * FROM `" . TB_ACCOUNT . "` WHERE LOWER(`" . COL_USERNAME . "`) = LOWER(:username) LIMIT 1");
    $stmt->execute([':username' => $username]);
    $user = $stmt->fetch();

    if (!$user) {
        // Demi keamanan, gunakan pesan error yang umum agar tidak ketahuan apakah username/password yang salah
        loginFail('Username atau Password salah.');
    }

    // 4. Cek Status Banned (Jika kolom COL_IS_BANNED ada di config Anda)
    if (defined('COL_IS_BANNED') && isset($user[COL_IS_BANNED]) && (int)$user[COL_IS_BANNED] === 1) {
        loginFail('Akun UCP Anda telah dibanned dari server.');
    }

    // 5. Verifikasi Password Menggunakan Algoritma SHA-256 + Salt (Sesuai dengan gamemode & register_process)
    $salt = $user[COL_SALT] ?? '';
    $storedPassword = $user[COL_PASSWORD] ?? '';

    // Menggabungkan salt dan password yang diinput, lalu di-hash SHA-256 dan diubah ke uppercase (huruf kapital)
// KODE BARU (SINKRON DENGAN GAME)
    $inputHashedPassword = strtoupper(hash('sha256', $password . $salt));
    if ($inputHashedPassword !== $storedPassword) {
        loginFail('Username atau Password salah.');
    }

    // 6. Login Sukses! Set data penting ke Session
    session_regenerate_id(true); // Regenerasi session ID demi keamanan

    $_SESSION['ucp_logged_in'] = true;
    $_SESSION['ucp_ID']        = $user[COL_ID];
    $_SESSION['ucp_ucp']  = $user[COL_USERNAME];
    
    // Simpan admin level jika didefinisikan untuk keperluan hak akses admin di dashboard
    if (defined('COL_ADMIN_LEVEL') && isset($user[COL_ADMIN_LEVEL])) {
        $_SESSION['ucp_admin'] = (int)$user[COL_ADMIN_LEVEL];
    }

    // Alihkan langsung ke halaman utama Dashboard
    header('Location: ../dashboard/profile.php');
    exit;

} catch (PDOException $e) {
    error_log('Login error: ' . $e->getMessage());
    loginFail('Terjadi kesalahan pada sistem database. Silakan coba beberapa saat lagi.');
}
