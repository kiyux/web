# Los Santos Roleplay — UCP & Landing Page

Blueprint arsitektur untuk website UCP + landing page server SA-MP Roleplay,
terintegrasi dengan tabel `playerucp` yang sudah berjalan di gamemode PAWN Anda.

## Struktur folder

```
sapp-ucp/
├── config/
│   ├── database.php     -> koneksi PDO + [GANTI DI SINI] nama tabel/kolom
│   └── .htaccess         -> blokir akses publik ke folder config/
├── includes/
│   └── functions.php     -> helper keamanan: hash, salt, validasi, CSRF, rate limit
├── auth/
│   ├── register.php      -> form registrasi + kuis rules
│   ├── register_process.php -> proses validasi & insert (PDO prepared statement)
│   └── login.php         -> (buat serupa dengan pola register_process.php)
├── dashboard/
│   └── profile.php       -> dashboard profil karakter (contoh data dummy)
├── admin/                 -> (Review Center, Player Management — kembangkan pola yang sama)
├── database/
│   └── schema.sql         -> skema tabel tambahan + rekomendasi ALTER TABLE
├── assets/
│   ├── css/  js/  img/
└── uploads/
    └── reports/            -> file bukti refund/report (JANGAN publik dieksekusi, lihat catatan di bawah)
```

## Yang WAJIB Anda sesuaikan (`[GANTI DI SINI]`)

Semua titik yang perlu disesuaikan dengan database Anda ditandai komentar
`[GANTI DI SINI]` di dalam kode, terutama di:

1. `config/database.php`
   - `DB_HOST`, `DB_NAME`, `DB_USER`, `DB_PASS`
   - `TB_ACCOUNT`, `COL_ID`, `COL_USERNAME`, `COL_PASSWORD`, `COL_SALT`, `COL_EMAIL`, dst — sesuaikan bila nama tabel/kolom akun Anda berbeda dari `playerucp` / `username` / `password` / `salt` / `email`
   - `HASH_ORDER` — **paling penting**: cek source gamemode PAWN Anda apakah hash dibentuk dari `SHA256(salt+password)` atau `SHA256(password+salt)`, lalu samakan nilainya di sini. Jika salah urutan, semua login lama akan gagal cocok.

2. `database/schema.sql`
   - Tabel `playerucp` TIDAK dibuat ulang — hanya referensi kolom minimum yang dibutuhkan web.
   - Tabel baru (`characters`, `character_stories`, `refund_requests`, dst) menggunakan `account_id` yang mengacu ke `playerucp.id` — sesuaikan nama kolom FK jika primary key akun Anda bukan `id`.

3. `includes/functions.php`
   - `generateSalt()` — sesuaikan `$charset` dan panjang salt agar identik dengan cara gamemode PAWN Anda membuat salt (agar salt baru dari web tetap valid dipakai in-game).

## Cara kerja hashing password (WAJIB dibaca)

Kode ini mengikuti skema Anda: **SHA-256(salt + password) di-uppercase**,
bukan bcrypt/password_hash bawaan PHP, supaya hash yang dibuat dari web
tetap bisa dipakai untuk login in-game oleh gamemode PAWN. Ini
dipertahankan untuk kompatibilitas, meskipun secara keamanan murni
`password_hash()` (bcrypt/argon2) jauh lebih tahan brute-force. Jika ke
depannya gamemode PAWN Anda juga bisa diubah, migrasi bertahap ke argon2
sangat disarankan — namun itu di luar cakupan kompatibilitas saat ini.

## Rekomendasi hak akses MySQL (Least Privilege)

Lihat komentar lengkap di `config/database.php`. Ringkasnya: buat user
MySQL baru khusus web (`ucp_web`), berikan hanya `SELECT, INSERT, UPDATE`
pada tabel-tabel yang dipakai web, dan JANGAN pernah gunakan akun `root`
pada aplikasi web.

## Checklist keamanan yang sudah diimplementasikan

- [x] PDO Prepared Statements di semua query (`ATTR_EMULATE_PREPARES = false`)
- [x] Validasi & sanitasi input dengan regex (username, email, password, nama karakter)
- [x] CSRF token pada form registrasi
- [x] Rate limiting sederhana berbasis session untuk form registrasi
- [x] Escaping output (`e()` / `htmlspecialchars`) untuk mencegah XSS
- [x] Session regeneration setelah aksi sensitif
- [x] `.htaccess` memblokir akses publik ke folder `config/`
- [x] Pesan error generik ke user, detail error dicatat via `error_log()` saja

## Yang masih perlu Anda lengkapi

- `auth/login.php` — ikuti pola `register_process.php`: ambil salt user dari
  DB berdasarkan username, hash ulang password yang diinput dengan salt
  tersebut, bandingkan dengan `hash_equals()` (bukan `==`) terhadap hash
  di database.
- Upload bukti refund/report: simpan file di luar document root bila
  memungkinkan, validasi ekstensi & MIME type sebenarnya (bukan hanya dari
  nama file), beri nama file acak (`bin2hex(random_bytes(16))`), dan
  larang eksekusi PHP di folder `uploads/` lewat `.htaccess`
  (`php_flag engine off` atau `Require all denied` untuk selain GET file statis).
- Halaman admin (`admin/`) — tambahkan middleware pengecekan `admin_level`
  di setiap file sebelum menampilkan konten.
