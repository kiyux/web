<?php
// dashboard/character_story.php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// 1. Hubungkan langsung ke database
require_once __DIR__ . '/../config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 2. Proteksi Session yang Benar (Sesuai dengan hasil dump detektif)
if (!isset($_SESSION['ucp_logged_in']) || $_SESSION['ucp_logged_in'] != 1) {
    header("Location: ../auth/login.php");
    exit();
}

$pdo = getPDO();
// Mengambil nama akun dari session kunci yang benar: 'ucp_ucp'
$username_ucp = $_SESSION['ucp_ucp']; 
$errors = null;
$success = null;

// ========================================================
// PROSES PENYIMPANAN DATA
// ========================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'submit_cs') {
    $char_id = (int)$_POST['char_id'];
    $content = trim($_POST['content']);

    if (empty($char_id) || empty($content)) {
        $errors = "Formulir tidak boleh kosong.";
    } else {
        $str_clean = trim(preg_replace('/\s+/', ' ', $content));
        $word_count = ($str_clean === "") ? 0 : count(explode(" ", $str_clean));

        if ($word_count < 300) {
            $errors = "Cerita Anda baru berisi $word_count kata. Harap tulis minimal 300 kata!";
        } else {
            try {
                // Gunakan LOWER agar pencocokan nama 'tessaja' dengan data di DB tidak sensitif huruf besar/kecil
                $stmt_owner = $pdo->prepare("SELECT pID FROM player_characters WHERE pID = ? AND LOWER(Char_UCP) = LOWER(?)");
                $stmt_owner->execute([$char_id, $username_ucp]);
                $owner_exists = $stmt_owner->fetch();

                if (!$owner_exists) {
                    $errors = "Akses ditolak. Karakter tersebut bukan milik akun UCP Anda.";
                } else {
                    $stmt_check = $pdo->prepare("SELECT story_id, status FROM character_stories WHERE char_id = ?");
                    $stmt_check->execute([$char_id]);
                    $existing = $stmt_check->fetch();

                    if ($existing) {
                        if ($existing['status'] === 'active') {
                            $errors = "Karakter ini sudah memiliki cerita aktif.";
                        } else {
                            $stmt_update = $pdo->prepare("UPDATE character_stories SET content = ?, status = 'pending', review_note = NULL, submitted_at = NOW() WHERE char_id = ?");
                            $stmt_update->execute([$content, $char_id]);
                            $success = "Cerita berhasil diperbarui! Menunggu pemeriksaan kembali oleh admin.";
                        }
                    } else {
                        $stmt_insert = $pdo->prepare("INSERT INTO character_stories (char_id, content, status, submitted_at) VALUES (?, ?, 'pending', NOW())");
                        $stmt_insert->execute([$char_id, $content]);
                        $success = "Cerita berhasil diajukan! Menunggu pemeriksaan admin.";
                    }
                }
            } catch (PDOException $e) {
                $errors = "Gagal memproses database: " . $e->getMessage();
            }
        }
    }
}

// ========================================================
// AMBIL DATA KARAKTER & RIWAYAT
// ========================================================
// Query untuk mencari karakter game berdasarkan akun 'tessaja'
$stmt = $pdo->prepare("SELECT pID, Char_Name FROM player_characters WHERE LOWER(Char_UCP) = LOWER(?)");
$stmt->execute([$username_ucp]);
$my_characters = $stmt->fetchAll();

// Query riwayat CS
$stmt_cs = $pdo->prepare("
    SELECT cs.*, c.Char_Name 
    FROM character_stories cs
    JOIN player_characters c ON cs.char_id = c.pID
    WHERE LOWER(c.Char_UCP) = LOWER(?)
    ORDER BY cs.submitted_at DESC
");
$stmt_cs->execute([$username_ucp]);
$cs_histories = $stmt_cs->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Character Story - UCP</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-neutral-950 text-white">
<div class="max-w-4xl mx-auto p-4 py-8 space-y-6">

    <div class="border-b border-neutral-800 pb-4">
        <a href="profile.php" class="text-xs text-amber-500 hover:underline">◄ Kembali ke Dashboard</a>
        <h1 class="text-3xl font-extrabold text-amber-400 mt-2">Character Story</h1>
        <p class="text-sm text-neutral-400">Kirimkan latar belakang cerita karakter Anda (Minimal 300 kata).</p>
    </div>

    <?php if ($success): ?>
        <div class="bg-emerald-950/40 border border-emerald-500/30 text-emerald-400 p-4 rounded-xl text-sm"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>
    <?php if ($errors): ?>
        <div class="bg-red-950/40 border border-red-500/30 text-red-400 p-4 rounded-xl text-sm"><?= htmlspecialchars($errors) ?></div>
    <?php endif; ?>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div class="md:col-span-2 bg-neutral-900 border border-neutral-800 p-6 rounded-2xl shadow-xl space-y-4">
            <h2 class="text-lg font-bold text-amber-500">Buat Cerita Baru</h2>
            
            <form action="" method="POST" class="space-y-4">
                <input type="hidden" name="action" value="submit_cs">

                <div>
                    <label class="block text-sm font-medium text-neutral-300 mb-1">Pilih Karakter</label>
                    <select name="char_id" required class="w-full rounded-lg bg-neutral-800 border border-neutral-700 text-white px-3 py-2 outline-none focus:border-amber-500">
                        <option value="">-- Pilih Karakter --</option>
                        <?php foreach($my_characters as $char): ?>
                            <option value="<?= $char['pID'] ?>"><?= str_replace('_', ' ', $char['Char_Name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <div class="flex justify-between items-center mb-1">
                        <label class="block text-sm font-medium text-neutral-300">Isi Cerita</label>
                        <span id="wordCount" class="text-xs text-neutral-400 bg-neutral-800 px-2 py-0.5 rounded">0 / 300 kata</span>
                    </div>
                    <textarea name="content" id="csContent" rows="12" required placeholder="Tulis cerita di sini..." class="w-full rounded-lg bg-neutral-800 border border-neutral-700 text-neutral-200 px-4 py-3 outline-none focus:border-amber-500 text-sm leading-relaxed"></textarea>
                </div>

                <button type="submit" id="submitBtn" disabled class="w-full bg-neutral-800 text-neutral-500 font-bold py-3 px-4 rounded-xl transition cursor-not-allowed">
                    Kirim Character Story (Minimal 300 Kata)
                </button>
            </form>
        </div>

        <div class="space-y-4">
            <h2 class="text-lg font-bold text-neutral-300">Riwayat</h2>
            <?php if (empty($cs_histories)): ?>
                <div class="text-center py-8 border border-dashed border-neutral-800 rounded-2xl text-neutral-500 text-sm">Belum ada pengajuan.</div>
            <?php else: ?>
                <div class="space-y-3">
                    <?php foreach($cs_histories as $cs): ?>
                        <div class="bg-neutral-900 border border-neutral-800 p-4 rounded-xl space-y-2">
                            <div class="flex justify-between items-start">
                                <span class="font-bold text-sm text-amber-400"><?= str_replace('_', ' ', $cs['Char_Name']) ?></span>
                                <span class="text-[10px] px-2 py-0.5 rounded-full uppercase tracking-wider font-bold <?= $cs['status'] === 'active' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30' : ($cs['status'] === 'rejected' ? 'bg-red-500/10 text-red-400 border border-red-500/30' : 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/30') ?>">
                                    <?= $cs['status'] === 'active' ? 'Accepted' : $cs['status'] ?>
                                </span>
                            </div>
                            <p class="text-xs text-neutral-400 line-clamp-3 bg-neutral-950/40 p-2 rounded-lg italic">"<?= htmlspecialchars(substr($cs['content'], 0, 100)) ?>..."</p>
                            <?php if(!empty($cs['review_note'])): ?>
                                <div class="bg-red-950/20 border border-red-500/20 p-2 rounded-lg text-xs text-red-300"><strong>Koreksi:</strong> <?= htmlspecialchars($cs['review_note']) ?></div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
const contentArea = document.getElementById('csContent');
const wordCountLabel = document.getElementById('wordCount');
const submitBtn = document.getElementById('submitBtn');

contentArea.addEventListener('input', function() {
    const text = this.value.trim();
    const words = text === "" ? 0 : text.split(/\s+/).length;
    wordCountLabel.textContent = `${words} / 300 kata`;

    if (words >= 300) {
        submitBtn.disabled = false;
        submitBtn.className = "w-full bg-amber-500 text-neutral-950 font-bold py-3 px-4 rounded-xl transition cursor-pointer hover:bg-amber-400";
    } else {
        submitBtn.disabled = true;
        submitBtn.className = "w-full bg-neutral-800 text-neutral-500 font-bold py-3 px-4 rounded-xl transition cursor-not-allowed";
    }
});
</script>
</body>
</html>
