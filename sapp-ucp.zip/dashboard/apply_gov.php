<?php
// dashboard/apply_gov.php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
if (!isset($_SESSION['ucp_logged_in'])) { header("Location: ../auth/login.php"); exit; }

require_once __DIR__ . '/../config/database.php';
$pdo = getPDO();

$ucp_name = $_SESSION['ucp_ucp'] ?? '';
$error = '';
$success = '';

// 1. Ambil daftar karakter milik UCP ini yang tidak sedang masuk fraksi lain (atau sesuaikan dengan kebutuhan)
$stmtChars = $pdo->prepare("SELECT `Char_Name`, `Char_Faction` FROM `player_characters` WHERE `Char_UCP` = ?");
$stmtChars->execute([$ucp_name]);
$myCharacters = $stmtChars->fetchAll();

// 2. Cek status rekrutmen faksi GOV
$stmtGov = $pdo->prepare("SELECT * FROM `factions` WHERE `fac_code` = 'GOV' LIMIT 1");
$stmtGov->execute();
$govData = $stmtGov->fetch();

$recStatus = strtoupper($govData['fac_recruitment'] ?? 'CLOSED');
if ($recStatus !== 'OPEN') {
    // Jika rekrutmen ditutup, lempar balik ke halaman fraksi
    header("Location: fraksi.php?code=GOV");
    exit;
}

// 3. Proses Submit Form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $selectedChar = trim($_POST['char_name'] ?? '');
    $age = intval($_POST['age'] ?? 0);
    $reason = trim($_POST['reason'] ?? '');
    $experience = trim($_POST['experience'] ?? '');

    // Validasi Sederhana
    if (empty($selectedChar) || $age <= 0 || empty($reason)) {
        $error = 'Harap isi semua kolom formulir yang diwajibkan!';
    } else {
        try {
            // Cek apakah karakter ini sudah memiliki permohonan PENDING di GOV (Faction ID = 2)
            $stmtCheck = $pdo->prepare("
                SELECT `app_id` 
                FROM `faction_applications` 
                WHERE `app_ucp_name` = ? AND `app_char_name` = ? AND `app_faction_id` = 2 AND `app_status` = 'PENDING' 
                LIMIT 1
            ");
            $stmtCheck->execute([$ucp_name, $selectedChar]);

            if ($stmtCheck->fetch()) {
                $error = 'Karakter ini masih memiliki lamaran GOV yang sedang ditinjau (PENDING)!';
            } else {
                // Insert Lamaran Baru menggunakan struktur kolom database Anda
                $stmtInsert = $pdo->prepare("
                    INSERT INTO `faction_applications` 
                    (`app_faction_id`, `app_ucp_name`, `app_char_name`, `app_age`, `app_reason`, `app_experience`, `app_status`) 
                    VALUES (2, ?, ?, ?, ?, ?, 'PENDING')
                ");
                $stmtInsert->execute([$ucp_name, $selectedChar, $age, $reason, $experience]);

                $success = 'Permohonan berhasil dikirim ke Balai Kota! Silakan tunggu peninjauan dari Petinggi GOV.';
            }
        } catch (Exception $e) {
            $error = 'Terjadi kesalahan sistem: ' . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulir Permohonan Balai Kota | GOV</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-[#0a0a0a] min-h-screen text-white font-sans antialiased">

    <?php include_once __DIR__ . '/../includes/navbar.php'; ?>

    <main class="max-w-3xl mx-auto px-4 py-8 space-y-6">

        <!-- Header Navigasi -->
        <div class="flex items-center justify-between">
            <a href="fraksi.php?code=GOV" class="inline-flex items-center space-x-2 text-xs font-bold text-neutral-400 hover:text-white transition bg-neutral-900 border border-neutral-800 px-4 py-2 rounded-xl">
                <span>← Batal / Kembali ke GOV</span>
            </a>
            <span class="text-[10px] text-amber-500 font-bold uppercase tracking-widest bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/20">
                Pemerintahan Kota
            </span>
        </div>

        <!-- Banner Form -->
        <div class="bg-neutral-900/80 border border-neutral-800 p-6 rounded-2xl shadow-xl flex items-center space-x-4">
            <div class="w-16 h-16 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-3xl shrink-0">
                🏛️
            </div>
            <div>
                <h1 class="text-xl font-black text-white uppercase tracking-tight">Formulir Rekrutmen Balai Kota</h1>
                <p class="text-xs text-neutral-400 leading-relaxed mt-0.5">
                    Isi data diri karakter Anda dengan jujur untuk mengajukan permohonan menjadi bagian dari staf/pejabat Government.
                </p>
            </div>
        </div>

        <!-- Alert Pesan -->
        <?php if (!empty($error)): ?>
            <div class="bg-red-500/10 border border-red-500/30 text-red-400 p-4 rounded-xl text-xs font-bold">
                ⚠️ <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($success)): ?>
            <div class="bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 p-4 rounded-xl text-xs font-bold space-y-2">
                <p>✅ <?= htmlspecialchars($success) ?></p>
                <div class="pt-2">
                    <a href="fraksi.php?code=GOV" class="inline-block bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-4 py-2 rounded-lg text-[11px] transition">
                        Kembali ke Halaman GOV →
                    </a>
                </div>
            </div>
        <?php endif; ?>

        <!-- Form Input -->
        <?php if (empty($success)): ?>
            <form action="" method="POST" class="bg-neutral-900/80 border border-neutral-800 p-6 rounded-2xl shadow-xl space-y-5">
                
                <!-- Pilih Karakter IC -->
                <div class="space-y-1.5">
                    <label class="text-xs font-bold text-neutral-300 uppercase tracking-wider block">
                        Pilih Karakter IC <span class="text-red-500">*</span>
                    </label>
                    <select name="char_name" required class="w-full bg-neutral-950 border border-neutral-800 focus:border-amber-500 rounded-xl px-4 py-3 text-xs text-white outline-none transition">
                        <option value="">-- Pilih Karakter Anda --</option>
                        <?php foreach ($myCharacters as $char): ?>
                            <option value="<?= htmlspecialchars($char['Char_Name']) ?>">
                                <?= str_replace('_', ' ', $char['Char_Name']) ?> <?= $char['Char_Faction'] > 0 ? '(Sudah Berfaksi)' : '(Sipil)' ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Usia Karakter (IC Age) -->
                <div class="space-y-1.5">
                    <label class="text-xs font-bold text-neutral-300 uppercase tracking-wider block">
                        Usia Karakter (IC) <span class="text-red-500">*</span>
                    </label>
                    <input type="number" name="age" min="18" max="90" placeholder="Contoh: 25" required class="w-full bg-neutral-950 border border-neutral-800 focus:border-amber-500 rounded-xl px-4 py-3 text-xs text-white outline-none transition">
                </div>

                <!-- Alasan Melamar -->
                <div class="space-y-1.5">
                    <label class="text-xs font-bold text-neutral-300 uppercase tracking-wider block">
                        Visi, Misi & Alasan Melamar <span class="text-red-500">*</span>
                    </label>
                    <textarea name="reason" rows="4" required placeholder="Jelaskan alasan karakter Anda ingin bergabung dengan Balai Kota..." class="w-full bg-neutral-950 border border-neutral-800 focus:border-amber-500 rounded-xl p-4 text-xs text-white outline-none transition leading-relaxed"></textarea>
                </div>

                <!-- Pengalaman (Opsional) -->
                <div class="space-y-1.5">
                    <label class="text-xs font-bold text-neutral-300 uppercase tracking-wider block">
                        Pengalaman Kerja / Organisasi (Opsional)
                    </label>
                    <textarea name="experience" rows="3" placeholder="Sebutkan riwayat pekerjaan atau pengalaman berorganisasi sebelumnya (jika ada)..." class="w-full bg-neutral-950 border border-neutral-800 focus:border-amber-500 rounded-xl p-4 text-xs text-white outline-none transition leading-relaxed"></textarea>
                </div>

                <!-- Submit Button -->
                <div class="pt-2">
                    <button type="submit" class="w-full bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs uppercase tracking-wider py-3.5 rounded-xl transition shadow-lg shadow-amber-600/10">
                        Kirim Permohonan Sekarang →
                    </button>
                </div>

            </form>
        <?php endif; ?>

    </main>
</body>
</html>
