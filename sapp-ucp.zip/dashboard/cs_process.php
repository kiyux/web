<?php
// dashboard/cs_process.php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo "Bukan metode POST.";
    exit();
}

$pdo = getPDO();

if (isset($_POST['action']) && $_POST['action'] === 'submit_cs') {
    if (!isset($_SESSION['ucp'])) { 
        exit("Anda harus login terlebih dahulu."); 
    }

    $char_id = (int)$_POST['char_id'];
    $content = trim($_POST['content']);
    $username_ucp = $_SESSION['ucp']; 

    echo "<h3>Mulai Memproses Data...</h3>";
    echo "Char ID: " . $char_id . "<br>";
    echo "UCP: " . $username_ucp . "<br>";

    if (empty($char_id) || empty($content)) {
        exit("Eror: Formulir kosong.");
    }

    // Hitung kata
    $str_clean = trim(preg_replace('/\s+/', ' ', $content));
    $word_count = ($str_clean === "") ? 0 : count(explode(" ", $str_clean));
    echo "Jumlah Kata: " . $word_count . "<br>";

    if ($word_count < 300) {
        exit("Eror: Kata kurang dari 300 (Hanya ada $word_count kata).");
    }

    try {
        // Cek pemilik karakter
        $stmt_owner = $pdo->prepare("SELECT pID FROM player_characters WHERE pID = ? AND Char_UCP = ?");
        $stmt_owner->execute([$char_id, $username_ucp]);
        $owner_exists = $stmt_owner->fetch();

        if (!$owner_exists) {
            exit("Eror: Karakter dengan ID $char_id ini bukan milik UCP $username_ucp di database.");
        }

        echo "Pemilik karakter VALID. Mencoba memasukkan ke tabel character_stories...<br>";

        // Periksa status data CS sebelumnya
        $stmt_check = $pdo->prepare("SELECT story_id, status FROM character_stories WHERE char_id = ?");
        $stmt_check->execute([$char_id]);
        $existing = $stmt_check->fetch();

        if ($existing) {
            if ($existing['status'] === 'active') {
                exit("Eror: Karakter sudah punya cerita aktif.");
            }
            $stmt_update = $pdo->prepare("UPDATE character_stories SET content = ?, status = 'pending', review_note = NULL, submitted_at = NOW() WHERE char_id = ?");
            $stmt_update->execute([$content, $char_id]);
            echo "Berhasil UPDATE data lama!<br>";
        } else {
            $stmt_insert = $pdo->prepare("INSERT INTO character_stories (char_id, content, status, submitted_at) VALUES (?, ?, 'pending', NOW())");
            $stmt_insert->execute([$char_id, $content]);
            echo "Berhasil INSERT data baru!<br>";
        }

        echo "<h2>PROSES SUKSES TANPA EROR!</h2>";
        echo "<a href='character_story.php'>Klik disini untuk kembali</a>";
        exit();

    } catch (PDOException $e) {
        // Tampilkan pesan kesalahan SQL yang membuat kode macet
        echo "<h2>DATABASE ERROR TERJADI:</h2>";
        exit($e->getMessage());
    }
}
