<?php
session_start();
echo "<h3>Data Session Anda Saat Ini:</h3>";
echo "<pre>";
print_r($_SESSION);
echo "</pre>";
?>
