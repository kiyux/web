<?php
/**
 * dashboard/admin_quiz.php
 * Halaman Admin - Tambah Soal Kuis UCP
 */
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../config/database.php';

session_start();

// 1. Proteksi Halaman Admin (Pastikan hanya Admin Level >= 1 yang bisa masuk)
// Sesuaikan session login yang Anda gunakan (contoh: ucp_id / ucp_ID)
$sessionID = $_SESSION['ucp_ID'] ?? $_SESSION['ucp_id'] ?? $_SESSION['ID'] ?? 0;
$pdo = getPDO();

$stmtAdmin = $pdo->prepare("SELECT `admin_level` FROM `" . TB_ACCOUNT . "` WHERE `" . COL_ID . "` = ?");
$stmtAdmin->execute([$sessionID]);
$adminData = $stmtAdmin->fetch();

if (!$adminData || (int)$adminData['admin_level'] < 1) {
    header('Location: ../dashboard/profile.php');
    exit;
}

$message = '';
$status = '';

// 2. PROSES SIMPAN SOAL BARU KE DATABASE (Ketika Form di-Submit)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_quiz'])) {
    $question       = trim($_POST['question'] ?? '');
    $option_a       = trim($_POST['option_a'] ?? '');
    $option_b       = trim($_POST['option_b'] ?? '');
    $option_c       = trim($_POST['option_c'] ?? '');
    $option_d       = trim($_POST['option_d'] ?? '');
    $correct_option = strtolower(trim($_POST['correct_option'] ?? ''));

    if (empty($question) || empty($option_a) || empty($option_b) || empty($correct_option)) {
        $message = "Pertanyaan, Opsi A, Opsi B, dan Kunci Jawaban wajib diisi!";
        $status = "error";
    } else {
        try {
            // Insert data ke tabel registration_quiz sesuai kolom di phpMyAdmin Anda
            $stmtInsert = $pdo->prepare("INSERT INTO `registration_quiz` 
                (`question`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `is_active`) 
                VALUES (?, ?, ?, ?, ?, ?, 1)");
            $stmtInsert->execute([$question, $option_a, $option_b, $option_c, $option_d, $correct_option]);
            
            $message = "Soal kuis baru berhasil ditambahkan ke database!";
            $status = "success";
        } catch (PDOException $e) {
            $message = "Gagal menyimpan data: " . $e->getMessage();
            $status = "error";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Panel - Kelola Kuis</title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="min-h-screen bg-neutral-950 text-white p-4 sm:p-8">

<div class="max-w-2xl mx-auto">
    
    <div class="mb-4">
        <a href="admin.php" class="text-xs text-neutral-450 hover:text-amber-400 bg-neutral-900 border border-neutral-800 px-3 py-1.5 rounded-lg transition">
            ← Kembali ke Dashboard Admin
        </a>
    </div>

    <div class="bg-neutral-900/60 backdrop-blur-xl border border-neutral-800 rounded-2xl p-6 shadow-xl">
        <h2 class="text-xl font-bold text-red-500 mb-1">Tambah Soal Kuis Baru</h2>
        <p class="text-xs text-neutral-400 mb-6">Soal yang ditambahkan akan otomatis diaktifkan (`is_active = 1`) dan siap diacak di form registrasi.</p>

        <?php if (!empty($message)): ?>
            <div class="mb-5 text-sm p-3.5 rounded-xl border <?= $status === 'success' ? 'bg-emerald-950/50 border-emerald-500/30 text-emerald-400' : 'bg-red-950/50 border-red-500/30 text-red-400' ?>">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>

        <form action="" method="POST" class="space-y-4">
            
            <div>
                <label class="block text-sm text-neutral-300 mb-1">Pertanyaan / Soal Kuis</label>
                <textarea name="question" rows="3" required placeholder="Contoh: Apa yang dimaksud dengan tindakan Powergaming?" class="w-full bg-neutral-950 border border-neutral-800 rounded-xl p-3 text-sm text-white focus:outline-none focus:border-red-500 transition"></textarea>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm text-neutral-300 mb-1">Pilihan Opsi A</label>
                    <input type="text" name="option_a" required placeholder="Jawaban A" class="w-full bg-neutral-950 border border-neutral-800 rounded-xl p-3 text-sm text-white focus:outline-none focus:border-red-500 transition">
                </div>
                <div>
                    <label class="block text-sm text-neutral-300 mb-1">Pilihan Opsi B</label>
                    <input type="text" name="option_b" required placeholder="Jawaban B" class="w-full bg-neutral-950 border border-neutral-800 rounded-xl p-3 text-sm text-white focus:outline-none focus:border-red-500 transition">
                </div>
                <div>
                    <label class="block text-sm text-neutral-300 mb-1">Pilihan Opsi C (Opsional)</label>
                    <input type="text" name="option_c" placeholder="Jawaban C" class="w-full bg-neutral-950 border border-neutral-800 rounded-xl p-3 text-sm text-white focus:outline-none focus:border-red-500 transition">
                </div>
                <div>
                    <label class="block text-sm text-neutral-300 mb-1">Pilihan Opsi D (Opsional)</label>
                    <input type="text" name="option_d" placeholder="Jawaban D" class="w-full bg-neutral-950 border border-neutral-800 rounded-xl p-3 text-sm text-white focus:outline-none focus:border-red-500 transition">
                </div>
            </div>

            <div class="pt-2">
                <label class="block text-sm text-neutral-300 mb-1">Kunci Jawaban Benar (`correct_option`)</label>
                <select name="correct_option" required class="w-full bg-neutral-950 border border-neutral-800 rounded-xl p-3 text-sm text-white focus:outline-none focus:border-red-500 transition cursor-pointer">
                    <option value="" disabled selected>-- Pilih Kunci Jawaban yang Benar --</option>
                    <option value="a">Opsi A</option>
                    <option value="b">Opsi B</option>
                    <option value="c">Opsi C</option>
                    <option value="d">Opsi D</option>
                </select>
                <p class="text-[11px] text-neutral-500 mt-1">Sistem akan menyimpan huruf kecil (a/b/c/d) secara otomatis untuk sinkronisasi logika koreksi.</p>
            </div>

            <div class="pt-4">
                <button type="submit" name="add_quiz" class="w-full py-3 bg-red-650 hover:bg-red-650 bg-red-600 hover:bg-red-500 text-white font-semibold rounded-xl transition shadow-md">
                    Simpan Soal Kuis ✓
                </button>
            </div>

        </form>
    </div>

</div>
</body>
</html>