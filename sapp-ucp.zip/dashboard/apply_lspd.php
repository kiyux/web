<?php
// dashboard/apply_lspd.php
if (session_status() === PHP_SESSION_NONE) { 
    session_start(); 
}

// 1. Cek Login User
if (!isset($_SESSION['ucp_logged_in'])) { 
    header("Location: ../auth/login.php"); 
    exit; 
}

// 2. Load Database Connection
require_once __DIR__ . '/../config/database.php';
$pdo = getPDO();

$ucp_name = $_SESSION['ucp_ucp'] ?? $_SESSION['ucp_username'] ?? $_SESSION['username'] ?? '';

// Ambil daftar karakter IC milik user ini untuk dipilih di dropdown
$stmtMyChars = $pdo->prepare("SELECT `Char_Name` FROM `player_characters` WHERE `Char_UCP` = ? AND (`Char_Faction` = 0 OR `Char_Faction` IS NULL)");
$stmtMyChars->execute([$ucp_name]);
$myCharacters = $stmtMyChars->fetchAll(PDO::FETCH_ASSOC);

// =========================================================================
// 3. CEK STATUS RECRUITMENT LSPD (DARI TABEL FACTIONS)
// =========================================================================
$stmtRec = $pdo->prepare("SELECT `fac_recruitment` FROM `factions` WHERE `fac_id` = 1 LIMIT 1");
$stmtRec->execute();
$is_open = ($stmtRec->fetchColumn() === 'OPEN');

// Jika Recruitment DITUTUP, tampilkan pesan blokir
if (!$is_open) {
    ?>
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Recruitment LSPD Ditutup</title>
        <script src="https://cdn.tailwindcss.com"></script>
    </head>
    <body class="bg-[#0a0a0a] min-h-screen text-white font-sans antialiased flex items-center justify-center p-4">
        <div class="max-w-md w-full bg-neutral-900 border border-red-500/30 p-8 rounded-2xl text-center space-y-4 shadow-2xl">
            <div class="text-4xl">🔒</div>
            <h3 class="text-xl font-black uppercase text-red-500 tracking-wider">Recruitment Ditutup</h3>
            <p class="text-xs text-neutral-400 leading-relaxed">
                High Command LSPD saat ini sedang tidak menerima pendaftaran anggota baru. Silakan pantau pengumuman di Discord resmi kami.
            </p>
            <div class="pt-2">
                <a href="../index.php" class="inline-block px-5 py-2.5 bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-bold rounded-xl transition uppercase tracking-wider">
                    Kembali ke Beranda
                </a>
            </div>
        </div>
    </body>
    </html>
    <?php
    exit; 
}

$error_msg = '';
$success_msg = '';

// =========================================================================
// 4. PROSES SIMPAN FORM PENDAFTARAN KE DATABASE
// =========================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_application'])) {
    $char_name  = trim($_POST['char_name'] ?? '');
    $app_age    = intval($_POST['app_age'] ?? 0);
    $reason     = trim($_POST['app_reason'] ?? '');
    $experience = trim($_POST['app_experience'] ?? '');

    // Validasi Sederhana
    if (empty($char_name) || $app_age <= 0 || empty($reason) || empty($experience)) {
        $error_msg = "Harap isi seluruh formulir pendaftaran dengan lengkap!";
    } else {
        // Cek apakah karakter ini sudah punya lamaran PENDING di LSPD
        $stmtCheckExist = $pdo->prepare("SELECT COUNT(*) FROM `faction_applications` WHERE `app_char_name` = ? AND `app_faction_id` = 1 AND `app_status` = 'PENDING'");
        $stmtCheckExist->execute([$char_name]);
        
        if ($stmtCheckExist->fetchColumn() > 0) {
            $error_msg = "Karakter ini sudah memiliki berkas pendaftaran yang sedang diproses oleh High Command!";
        } else {
            // Simpan ke database faction_applications
            $stmtInsert = $pdo->prepare("INSERT INTO `faction_applications` (`app_faction_id`, `app_ucp_name`, `app_char_name`, `app_age`, `app_reason`, `app_experience`, `app_status`) VALUES (1, ?, ?, ?, ?, ?, 'PENDING')");
            $inserted = $stmtInsert->execute([$ucp_name, $char_name, $app_age, $reason, $experience]);

            if ($inserted) {
                $success_msg = "Berkas pendaftaran Anda berhasil dikirim! Silakan tunggu peninjauan dari High Command LSPD.";
            } else {
                $error_msg = "Gagal mengirim berkas, terjadi kesalahan sistem.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SAPP RP | Form Pendaftaran LSPD</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-[#0a0a0a] min-h-screen text-white font-sans antialiased">
    
    <!-- Navbar -->
    <?php include_once __DIR__ . '/../includes/navbar.php'; ?>

    <main class="max-w-2xl mx-auto px-4 py-8 space-y-6">
        
        <!-- Header Page -->
        <div class="border-b border-neutral-800 pb-4">
            <h1 class="text-2xl font-black uppercase text-blue-500 tracking-wider">Formulir Recruitment LSPD</h1>
            <p class="text-xs text-neutral-400 mt-1">Isi formulir pendaftaran di bawah ini untuk bergabung dengan Los Santos Police Department.</p>
        </div>

        <!-- Alert Notifikasi -->
        <?php if (!empty($error_msg)): ?>
            <div class="bg-red-500/10 border border-red-500/30 text-red-400 p-4 rounded-xl text-xs font-semibold">
                ⚠️ <?= $error_msg ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($success_msg)): ?>
            <div class="bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 p-4 rounded-xl text-xs font-semibold space-y-2">
                <p>✅ <?= $success_msg ?></p>
                <a href="../index.php" class="inline-block mt-2 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-[10px] uppercase font-bold">Kembali ke Beranda</a>
            </div>
        <?php else: ?>

            <!-- Form Pendaftaran -->
            <form action="" method="POST" class="bg-neutral-900 border border-neutral-800 p-6 rounded-2xl space-y-4 shadow-xl text-xs">
                
                <!-- Pilih Karakter IC -->
                <div class="space-y-1">
                    <label class="font-bold text-neutral-300 uppercase tracking-wider">Pilih Karakter IC (In-Game)</label>
                    <?php if (count($myCharacters) > 0): ?>
                        <select name="char_name" class="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition" required>
                            <option value="">-- Pilih Karakter Anda --</option>
                            <?php foreach ($myCharacters as $c): ?>
                                <option value="<?= htmlspecialchars($c['Char_Name']) ?>"><?= str_replace('_', ' ', $c['Char_Name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    <?php else: ?>
                        <p class="text-red-400 italic">Anda tidak memiliki karakter sipil (Non-Faction). Buat karakter dulu di In-Game / Dashboard.</p>
                    <?php endif; ?>
                </div>

                <!-- Umur IC -->
                <div class="space-y-1">
                    <label class="font-bold text-neutral-300 uppercase tracking-wider">Umur Karakter (IC Age)</label>
                    <input type="number" name="app_age" min="18" max="70" placeholder="Contoh: 25" class="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition" required>
                </div>

                <!-- Alasan Bergabung -->
                <div class="space-y-1">
                    <label class="font-bold text-neutral-300 uppercase tracking-wider">Alasan Ingin Bergabung LSPD</label>
                    <textarea name="app_reason" rows="4" placeholder="Jelaskan visi, misi, dan motivasi karakter Anda bergabung dengan kepolisian..." class="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition" required></textarea>
                </div>

                <!-- Pengalaman Roleplay -->
                <div class="space-y-1">
                    <label class="font-bold text-neutral-300 uppercase tracking-wider">Pengalaman Roleplay / Fraksi Sebelumnya</label>
                    <textarea name="app_experience" rows="3" placeholder="Tuliskan pengalaman RP Anda di server ini atau server lain (misal: Pernah jadi Mechanic, Taxidriver, dll)..." class="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition" required></textarea>
                </div>

                <!-- Tombol Submit -->
                <div class="pt-2 flex justify-end space-x-3">
                    <a href="../index.php" class="px-5 py-2.5 bg-neutral-800 hover:bg-neutral-700 font-bold rounded-xl text-neutral-300 transition">Batal</a>
                    <button type="submit" name="submit_application" class="px-6 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl uppercase tracking-wider transition shadow-lg shadow-blue-950/40">
                        Kirim Pendaftaran
                    </button>
                </div>
            </form>

        <?php endif; ?>

    </main>
</body>
</html>
