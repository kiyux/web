<?php
// dashboard/admin_manage_cs.php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// PROTEKSI ADMIN: Pastikan user sudah login dan memiliki level admin (misal min level 1)
if (!isset($_SESSION['ucp_logged_in']) || $_SESSION['ucp_logged_in'] != 1 || !isset($_SESSION['ucp_admin']) || $_SESSION['ucp_admin'] < 1) {
    header("Location: ../auth/login.php");
    exit();
}

$pdo = getPDO();
$success = null;
$errors = null;

// ========================================================
// PROSES APPROVE / REJECT
// ========================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $story_id = (int)$_POST['story_id'];
    $action = $_POST['action'];

    if ($action === 'approve') {
        try {
            $stmt = $pdo->prepare("UPDATE character_stories SET status = 'active', review_note = NULL WHERE story_id = ?");
            $stmt->execute([$story_id]);
            $success = "Character Story berhasil disetujui (Accepted)!";
        } catch (PDOException $e) {
            $errors = "Gagal memperbarui database: " . $e->getMessage();
        }
    } 
    
    if ($action === 'reject') {
        $reason = trim($_POST['reason']);
        if (empty($reason)) {
            $errors = "Harap masukkan alasan penolakan.";
        } else {
            try {
                $stmt = $pdo->prepare("UPDATE character_stories SET status = 'rejected', review_note = ? WHERE story_id = ?");
                $stmt->execute([$reason, $story_id]);
                $success = "Character Story berhasil ditolak dengan alasan.";
            } catch (PDOException $e) {
                $errors = "Gagal memperbarui database: " . $e->getMessage();
            }
        }
    }
}

// ========================================================
// AMBIL SEMUA PENGAJUAN YANG MASIH PENDING
// ========================================================
$stmt = $pdo->prepare("
    SELECT cs.*, c.Char_Name, c.Char_UCP 
    FROM character_stories cs
    JOIN player_characters c ON cs.char_id = c.pID
    WHERE cs.status = 'pending'
    ORDER BY cs.submitted_at ASC
");
$stmt->execute();
$pending_list = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Kelola Character Story</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-neutral-950 text-white">
<div class="max-w-5xl mx-auto p-4 py-8 space-y-6">

    <div class="border-b border-neutral-800 pb-4 flex justify-between items-center">
        <div>
            <a href="profile.php" class="text-xs text-amber-500 hover:underline">◄ Kembali ke Dashboard</a>
            <h1 class="text-3xl font-extrabold text-amber-400 mt-2">Kelola Character Story</h1>
            <p class="text-sm text-neutral-400">Daftar pengajuan pending yang butuh pemeriksaan admin.</p>
        </div>
        <div class="bg-neutral-900 border border-neutral-800 px-4 py-2 rounded-xl text-right">
            <span class="text-xs text-neutral-400 block">Admin Active</span>
            <span class="text-sm font-bold text-amber-500"><?= htmlspecialchars($_SESSION['ucp_ucp']) ?> (Lvl: <?= $_SESSION['ucp_admin'] ?>)</span>
        </div>
    </div>

    <?php if ($success): ?>
        <div class="bg-emerald-950/40 border border-emerald-500/30 text-emerald-400 p-4 rounded-xl text-sm"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>
    <?php if ($errors): ?>
        <div class="bg-red-950/40 border border-red-500/30 text-red-400 p-4 rounded-xl text-sm"><?= htmlspecialchars($errors) ?></div>
    <?php endif; ?>

    <?php if (empty($pending_list)): ?>
        <div class="text-center py-20 border border-dashed border-neutral-800 rounded-3xl text-neutral-500">
            <p class="text-lg font-bold">Tidak ada antrean pending!</p>
            <p class="text-xs mt-1">Semua pengajuan Character Story telah selesai diproses.</p>
        </div>
    <?php else: ?>
        <div class="space-y-6">
            <?php foreach($pending_list as $row): ?>
                <div class="bg-neutral-900 border border-neutral-800 p-6 rounded-2xl shadow-xl space-y-4">
                    <div class="flex justify-between items-center border-b border-neutral-800 pb-3">
                        <div>
                            <span class="text-xs text-amber-500 font-bold tracking-wider uppercase">Pengajuan</span>
                            <h3 class="text-lg font-extrabold text-white"><?= str_replace('_', ' ', $row['Char_Name']) ?> <span class="text-xs font-normal text-neutral-400">(UCP: <?= htmlspecialchars($row['Char_UCP']) ?>)</span></h3>
                        </div>
                        <span class="text-xs text-neutral-500">Dikirim: <?= $row['submitted_at'] ?></span>
                    </div>

                    <!-- Kotak Isi Cerita -->
                    <div class="bg-neutral-950 p-4 rounded-xl border border-neutral-800/60 max-h-80 overflow-y-auto">
                        <p class="text-sm text-neutral-300 leading-relaxed whitespace-pre-wrap"><?= htmlspecialchars($row['content']) ?></p>
                    </div>

                    <!-- Jumlah Kata -->
                    <div class="text-xs text-neutral-400">
                        Total: <strong class="text-amber-400"><?= count(explode(" ", trim(preg_replace('/\s+/', ' ', $row['content'])))) ?></strong> kata
                    </div>

                    <!-- Tombol Aksi -->
                    <div class="flex flex-col sm:flex-row gap-3 pt-2">
                        <!-- Form Terima -->
                        <form action="" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin MENYETUJUI cerita ini?');">
                            <input type="hidden" name="story_id" value="<?= $row['story_id'] ?>">
                            <input type="hidden" name="action" value="approve">
                            <button type="submit" class="w-full sm:w-auto bg-emerald-600 hover:bg-emerald-500 text-neutral-950 font-bold px-5 py-2.5 rounded-xl transition text-sm">
                                Approve (Terima)
                            </button>
                        </form>

                        <!-- Form Tolak -->
                        <form action="" method="POST" class="flex-1 flex gap-2" onsubmit="return confirm('Apakah Anda yakin ingin MENOLAK cerita ini?');">
                            <input type="hidden" name="story_id" value="<?= $row['story_id'] ?>">
                            <input type="hidden" name="action" value="reject">
                            <input type="text" name="reason" placeholder="Alasan penolakan..." required class="flex-1 bg-neutral-950 border border-neutral-800 rounded-xl px-4 py-2 text-sm text-white focus:outline-none focus:border-red-500">
                            <button type="submit" class="bg-red-600 hover:bg-red-500 text-white font-bold px-5 py-2.5 rounded-xl transition text-sm">
                                Reject (Tolak)
                            </button>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

</div>
</body>
</html>
