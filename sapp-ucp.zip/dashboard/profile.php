<?php
/**
 * dashboard/profile.php
 * Halaman Dashboard UCP - Terhubung ke Data Karakter
 */
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Proteksi Halaman
if (!isset($_SESSION['ucp_logged_in']) || $_SESSION['ucp_logged_in'] !== true) {
    header('Location: ../auth/login.php');
    exit;
}

$pdo = getPDO();

// 1. Ambil data UCP untuk memastikan akun valid
$sessionID = $_SESSION['ucp_ID'] ?? $_SESSION['ucp_id'] ?? $_SESSION['ID'] ?? 0;

$stmtUCP = $pdo->prepare("SELECT `" . COL_ID . "`, `" . COL_USERNAME . "`, `admin_level` FROM `" . TB_ACCOUNT . "` WHERE `" . COL_ID . "` = ?");
$stmtUCP->execute([$sessionID]); 
$userData = $stmtUCP->fetch();

if (!$userData) {
    session_destroy();
    header('Location: ../auth/login.php');
    exit;
}

// 2. AMBIL DATA DARI TABEL PLAYER_CHARACTER DULUAN
$stmtChar = $pdo->prepare("SELECT * FROM `player_characters` WHERE `Char_UCP` = ? LIMIT 1");
$stmtChar->execute([$userData[COL_USERNAME]]);
$charData = $stmtChar->fetch();

// 1. Bikin array kosong untuk menampung lisensi yang aktif
$activeLicenses = [];

// 2. Cek satu per satu kolom lisensi dari database
if (($charData['Char_SimA'] ?? 0) == 1) $activeLicenses[] = 'SIM A (Mobil)';
if (($charData['Char_SimB'] ?? 0) == 1) $activeLicenses[] = 'SIM B (Truk/Berat)';
if (($charData['Char_SimC'] ?? 0) == 1) $activeLicenses[] = 'SIM C (Motor)';
if (($charData['Char_WeaponLic'] ?? 0) == 1) $activeLicenses[] = 'Weapon License';
if (($charData['Char_HuntingLic'] ?? 0) == 1) $activeLicenses[] = 'Hunting License';

if (empty($activeLicenses)) {
    $activeLicenses[] = 'Tidak memiliki lisensi aktif';
}

// 3. AMBIL DATA KENDARAAN MENGGUNAKAN ID KARAKTER
$vehicles = [];
if ($charData) {
    $stmtVeh = $pdo->prepare("SELECT * FROM `player_vehicles` WHERE `PVeh_OwnerID` = ?");
    $stmtVeh->execute([$charData['pID'] ?? 0]); 
    $vehicles = $stmtVeh->fetchAll();
}

$vehicleNames = [
    400 => 'Landstalker',
    411 => 'Infernus',
    415 => 'Cheetah', 
    422 => 'Bobcat',
    453 => 'Reefer',      
    462 => 'Faggio',
    560 => 'Sultan',
    586 => 'Wayfarer',
    602 => 'Alpha',
];

// 4. MAPPING FRAKSI & PEKERJAAN
$factionList = [
    0 => 'Tidak Ada',
    1 => 'Los Santos Police Department',
    2 => 'Government / Pemerintah',
    3 => 'San Andreas Medical Services',
    4 => 'Transportasi',
    5 => 'Bengkel Los Santos',
    6 => 'Pedagang',
    7 => 'Tentara',
];
$jobList = [
    0 => 'Pengangguran',
    1 => 'Supir Bus',
    2 => 'Penambang',
    3 => 'Tukang Kayu',
    4 => 'Tukang Ayam',
    5 => 'Tukang Jahit',
    6 => 'Tukang Minyak',
    7 => 'Nelayan',
    8 => 'Pemerah Susu',
    9 => 'Petani',
    10 => 'Kargo Driver',
    11 => 'Recycler',
    12 => 'Trashmaster',
];

$properties = [];
if ($charData) {
    $stmtHouse = $pdo->prepare("SELECT * FROM `house` WHERE `HS_OwnerID` = ?");
    $stmtHouse->execute([$charData['pID'] ?? 0]); 
    $properties = $stmtHouse->fetchAll();
}

$factionID = (int)($charData['Char_Faction'] ?? 0); 
$factionName = $factionList[$factionID] ?? 'Tidak Ada';
$jobID = (int)($charData['Char_Job'] ?? 0);
$jobName = $jobList[$jobID] ?? 'Pengangguran';

$character = [
    'name'        => $charData['Char_Name'] ?? $userData[COL_USERNAME], 
    'level'       => $charData['Char_Level'] ?? 1, 
    'cash'        => $charData['Char_Money'] ?? 0, 
    'bank'        => $charData['Char_BankMoney'] ?? 0,
    'job'         => $jobName,
    'faction'     => $factionName, 
    'health'      => $charData['Char_Health'] ?? 100,
    'hunger'      => $charData['Char_Hunger'] ?? 100,
    'licenses'    => $activeLicenses,
    'vehicles'    => $vehicles,
    'properties'  => $properties,
    'admin_level' => (int)($userData['admin_level'] ?? 0), 
    'activity_log' => [
        ['time' => date('d M Y, H:i'), 'text' => 'Login ke Dashboard UCP'],
    ],
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard UCP - Los Santos Roleplay</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Rye&display=swap" rel="stylesheet">
    <style>
      body { font-family: 'Inter', sans-serif; }
      .font-graffiti { font-family: 'Rye', serif; }
    </style>
</head>
<body class="min-h-screen bg-neutral-950 text-white">

    <!-- Efek Background Halaman -->
    <div class="fixed inset-0 -z-10 bg-[url('/assets/img/los-santos-bg.jpg')] bg-cover bg-center"></div>
    <div class="fixed inset-0 -z-10 bg-gradient-to-b from-black/90 via-black/80 to-black/95"></div>

    <!-- Panggil File Navbar Yang Baru -->
    <?php include_once __DIR__ . '/../includes/navbar.php'; ?>

    <!-- Konten Utama -->
    <div class="max-w-6xl mx-auto px-4 sm:px-6 py-6 sm:py-10">

      <!-- Kartu Identitas Karakter -->
      <section class="bg-neutral-900/60 backdrop-blur-xl border border-amber-500/20 rounded-2xl p-5 sm:p-7 mb-6 shadow-xl">
        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <p class="text-xs uppercase tracking-widest text-amber-400/80 mb-1">Akun UCP Aktif</p>
            <h2 class="text-2xl sm:text-3xl font-bold tracking-wide"><?= htmlspecialchars($character['name']) ?></h2>
            <p class="text-neutral-400 text-sm mt-1">Pekerjaan: <?= htmlspecialchars($character['job']) ?> &middot; Faksi: <?= htmlspecialchars($character['faction']) ?></p>
          </div>
          <div class="flex gap-3">
            <div class="bg-black/40 border border-neutral-700 rounded-xl px-4 py-3 text-center min-w-[90px]">
              <p class="text-[10px] uppercase text-neutral-400">Level</p>
              <p class="text-xl font-bold text-amber-400"><?= (int)$character['level'] ?></p>
            </div>
          </div>
        </div>

        <!-- Status bar HP & Hunger -->
        <div class="grid grid-cols-2 gap-4 mt-5">
          <div>
            <div class="flex justify-between text-xs mb-1 text-neutral-400"><span>Kesehatan</span><span><?= (int)$character['health'] ?>%</span></div>
            <div class="h-2 rounded-full bg-neutral-800 overflow-hidden">
              <div class="h-full bg-red-500 rounded-full" style="width: <?= (int)$character['health'] ?>%"></div>
            </div>
          </div>
          <div>
            <div class="flex justify-between text-xs mb-1 text-neutral-400"><span>Kelaparan</span><span><?= (int)$character['hunger'] ?>%</span></div>
            <div class="h-2 rounded-full bg-neutral-800 overflow-hidden">
              <div class="h-full bg-amber-500 rounded-full" style="width: <?= (int)$character['hunger'] ?>%"></div>
            </div>
          </div>
        </div>
      </section>

      <!-- Grid: Keuangan, Lisensi, Properti -->
      <section class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        <div class="bg-neutral-900/60 backdrop-blur-xl border border-neutral-800/60 rounded-2xl p-5 shadow-lg">
          <p class="text-xs uppercase tracking-widest text-amber-400/80 mb-3">Keuangan</p>
          <div class="flex justify-between items-center mb-2">
            <span class="text-neutral-400 text-sm">Uang Tunai</span>
            <span class="font-semibold text-emerald-400">$<?= number_format($character['cash']) ?></span>
          </div>
          <div class="flex justify-between items-center">
            <span class="text-neutral-400 text-sm">Bank</span>
            <span class="font-semibold text-emerald-500">$<?= number_format($character['bank']) ?></span>
          </div>
        </div>

        <div class="bg-neutral-900/60 backdrop-blur-xl border border-neutral-800/60 rounded-2xl p-5 shadow-lg">
          <p class="text-xs uppercase tracking-widest text-amber-400/80 mb-3">Lisensi Aktif</p>
          <div class="flex flex-wrap gap-2">
            <?php foreach ($character['licenses'] as $lic): ?>
              <span class="text-xs bg-amber-500/10 text-amber-300 border border-amber-500/30 rounded-full px-3 py-1"><?= htmlspecialchars($lic) ?></span>
            <?php endforeach; ?>
          </div>
        </div>

        <div class="bg-neutral-900/60 backdrop-blur-xl border border-neutral-800/60 rounded-2xl p-5 sm:col-span-2 lg:col-span-1 shadow-lg">
          <p class="text-xs uppercase tracking-widest text-amber-400/80 mb-3">Kepemilikan Properti</p>
          <?php if (empty($character['properties'])): ?>
            <p class="text-neutral-500 text-xs italic">Belum memiliki aset properti.</p>
          <?php else: ?>
            <div class="space-y-3">
              <?php foreach ($character['properties'] as $prop): ?>
                <div class="text-sm border-b border-neutral-800 pb-2 last:border-none last:pb-0">
                  <p class="font-medium text-amber-400">🏠 Rumah #<?= (int)$prop['ID'] ?></p>
                  <p class="text-neutral-400 text-xs">Lokasi: <?= htmlspecialchars($prop['Address'] ?? 'San Andreas') ?></p>
                </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>
      </section>

      <!-- Kendaraan -->
      <section class="bg-neutral-900/60 backdrop-blur-xl border border-neutral-800/60 rounded-2xl p-5 sm:p-7 mb-6 shadow-lg">
        <p class="text-xs uppercase tracking-widest text-amber-400/80 mb-4">Daftar Kendaraan</p>
        <?php if (empty($character['vehicles'])): ?>
          <p class="text-neutral-500 text-xs italic">Belum memiliki kendaraan terdaftar.</p>
        <?php else: ?>
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <?php foreach ($character['vehicles'] as $v): ?>
              <?php 
                $modelID = (int)($v['PVeh_ModelID'] ?? 0);
                $vName = $vehicleNames[$modelID] ?? "Unknown Vehicle (ID: {$modelID})";
              ?>
              <div class="flex items-center justify-between bg-black/30 border border-neutral-800 rounded-xl px-4 py-3">
                <div>
                  <p class="font-medium text-sm"><?= htmlspecialchars($vName) ?></p> 
                </div>
                <span class="text-xs text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 rounded-full px-3 py-1">Aktif</span>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </section>

      <!-- Log Aktivitas -->
      <section class="bg-neutral-900/60 backdrop-blur-xl border border-neutral-800/60 rounded-2xl p-5 sm:p-7 shadow-lg">
        <p class="text-xs uppercase tracking-widest text-amber-400/80 mb-4">Log Aktivitas Akun</p>
        <ul class="space-y-3">
          <?php foreach ($character['activity_log'] as $log): ?>
            <li class="flex gap-3 text-sm border-l-2 border-amber-500/40 pl-3">
              <span class="text-neutral-500 shrink-0 w-32"><?= htmlspecialchars($log['time']) ?></span>
              <span class="text-neutral-200"><?= htmlspecialchars($log['text']) ?></span>
            </li>
          <?php endforeach; ?>
        </ul>
      </section>

    </div>
</body>
</html>
