<?php
// dashboard/gacha.php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
if (!isset($_SESSION['ucp_logged_in'])) { header("Location: ../auth/login.php"); exit; }

require_once __DIR__ . '/../config/database.php';
$pdo = getPDO();

// Mengambil nama UCP dari session Anda ('tessaja')
$ucp_name = $_SESSION['ucp_ucp'] ?? '';

// Ambil saldo karakter berdasarkan kolom penghubung Char_UCP yang tepat
$stmt = $pdo->prepare("SELECT `Char_Money` FROM `player_characters` WHERE `Char_UCP` = ? LIMIT 1");
$stmt->execute([$ucp_name]);
$user_money = $stmt->fetch()['Char_Money'] ?? 0;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Los Santos RP | Roulette Gacha</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-[#0a0a0a] min-h-screen text-white font-sans antialiased">

    <?php include_once __DIR__ . '/../includes/navbar.php'; ?>

    <main class="max-w-md mx-auto px-4 py-8 text-center space-y-5">
        <div>
            <h1 class="text-2xl font-extrabold tracking-tight text-white uppercase">Roulette Spin</h1>
            <p class="text-xs text-neutral-400">Putar roda keberuntungan untuk mendapatkan item premium</p>
        </div>

        <!-- TAMPILAN INFORMASI UANG IC PLAYER -->
        <div class="bg-neutral-900/50 border border-neutral-800 p-3 rounded-xl flex justify-between items-center px-4">
            <div class="text-left">
                <span class="text-[10px] text-neutral-400 block uppercase font-bold tracking-wider">Uang IC Anda</span>
                <!-- Element ID ini yang akan di-update oleh JavaScript secara real-time -->
                <span id="playerMoneyDisplay" class="text-base font-black text-emerald-400">$<?= number_format($user_money) ?></span>
            </div>
            <div class="text-right">
                <span class="text-[10px] text-neutral-400 block uppercase font-bold tracking-wider">Biaya Spin</span>
                <span class="text-xs font-bold text-red-400">-$500 IC</span>
            </div>
        </div>

        <!-- CONTAINER ROULETTE -->
        <div class="relative flex justify-center items-center py-4">
            <div class="absolute top-0 z-10 w-0 h-0 border-l-[15px] border-l-transparent border-r-[15px] border-r-transparent border-t-[25px] border-t-amber-500"></div>
            <canvas id="wheelCanvas" width="340" height="340" class="rounded-full border-4 border-neutral-800 shadow-2xl transition-transform duration-[5000ms] ease-out"></canvas>
        </div>

        <!-- TOMBOL SPIN -->
        <div>
            <button id="spinBtn" onclick="startSpin()" class="w-full py-3.5 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-black rounded-xl transition text-sm uppercase tracking-widest shadow-md">
                SPIN SEKARANG
            </button>
        </div>

        <!-- NOTIFIKASI HASIL -->
        <div id="resultBox" class="hidden p-4 rounded-xl text-xs font-bold border bg-neutral-900/60 border-neutral-800 text-amber-400 animate-pulse"></div>
    </main>

    <script>
        const canvas = document.getElementById('wheelCanvas');
        const ctx = canvas.getContext('2d');
        const spinBtn = document.getElementById('spinBtn');
        const resultBox = document.getElementById('resultBox');
        const moneyDisplay = document.getElementById('playerMoneyDisplay');

        // 1. UPDATE DAFTAR HADIAH AGAR SINKRON DENGAN BACKEND (Termasuk Nasi Goreng)
        const prizes = ["Zonk", "Money $1,000", "10 Gold", "Toy Rare Box", "Nasi Goreng", "Money $5,000", "Cheetah"];
        const colors = ["#171717", "#262626", "#171717", "#262626", "#171717", "#262626", "#171717"];
        const totalSlices = prizes.length;
        const sliceAngle = (2 * Math.PI) / totalSlices;

        // Variabel penampung derajat rotasi kumulatif agar putaran kedua tetap berputar maju
        let currentRotation = 0;

        function drawWheel() {
            ctx.clearRect(0, 0, canvas.width, canvas.height); // Bersihkan canvas sebelum menggambar
            for (let i = 0; i < totalSlices; i++) {
                const angle = i * sliceAngle;
                ctx.beginPath();
                ctx.fillStyle = colors[i];
                ctx.moveTo(170, 170);
                ctx.arc(170, 170, 170, angle, angle + sliceAngle);
                ctx.lineTo(170, 170);
                ctx.fill();
                ctx.strokeStyle = '#404040';
                ctx.lineWidth = 1;
                ctx.stroke();

                ctx.save();
                ctx.translate(170, 170);
                ctx.rotate(angle + sliceAngle / 2);
                ctx.fillStyle = i % 2 === 0 ? '#fbbf24' : '#ffffff';
                ctx.font = 'bold 10px sans-serif'; // Ukuran font disesuaikan agar muat
                ctx.textAlign = "right";
                ctx.fillText(prizes[i], 150, 5);
                ctx.restore();
            }
        }

        drawWheel();

        function startSpin() {
            spinBtn.disabled = true;
            resultBox.classList.add('hidden');

            fetch('gacha_process.php', { method: 'POST' })
            .then(res => res.json())
            .then(data => {
                if (data.status === 'error') {
                    alert(data.message);
                    spinBtn.disabled = false;
                    return;
                }

                const winningID = data.winning_id;
                const extraRotations = 5 * 360; // 5 kali putaran penuh
                const targetAnglePerItem = 360 / totalSlices;
                
                // Hitung derajat pemberhentian agar jarum di atas (90 derajat) menunjuk tepat pada hadiah
                const stopAngle = 360 - (winningID * targetAnglePerItem) - (targetAnglePerItem / 2) - 90;
                
                // Menggunakan sisa rotasi sebelumnya ditambahkan dengan putaran penuh baru + target sudut
                // Metode ini memaksa roda selalu berputar searah jarum jam secara kontinu di spin ke-2, ke-3 dst.
                currentRotation += extraRotations + (stopAngle - (currentRotation % 360));

                // Aktifkan kembali animasi transisi CSS
                canvas.style.transition = "transform 5000ms ease-out";
                canvas.style.transform = `rotate(${currentRotation}deg)`;

                // Animasi Selesai (Jeda 5.2 detik)
                setTimeout(() => {
                    resultBox.innerHTML = `🎉 SELAMAT! Anda Mendapatkan: <br><span class="text-sm font-extrabold uppercase mt-1 block">${data.prize_name}</span>`;
                    resultBox.classList.remove('hidden');
                    
                    // UPDATE ANGKA SISA UANG TERBARU SECARA INSTAN
                    moneyDisplay.innerText = data.new_balance;
                    
                    spinBtn.disabled = false;
                }, 5200);
            })
            .catch(err => {
                alert("Terjadi kesalahan jaringan.");
                spinBtn.disabled = false;
            });
        }
    </script>
</body>
</html>
