<?php
// dashboard/daftar_fraksi.php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
if (!isset($_SESSION['ucp_logged_in'])) { header("Location: ../auth/login.php"); exit; }

require_once __DIR__ . '/../config/database.php';
$pdo = getPDO();

$ucp_name = $_SESSION['ucp_ucp'] ?? '';
$error = '';
$success = '';

// Ambil semua karakter milik akun UCP ini untuk dipilih di form
$stmtChars = $pdo->prepare("SELECT `Char_Name` FROM `player_characters` WHERE `Char_UCP` = ? AND `Char_Faction` = 0");
$stmtChars->execute([$ucp_name]);
$myCharacters = $stmtChars->fetchAll();

// Cek status rekrutmen LSPD (Disini kita set manual True, nanti bisa dihubungkan ke DB)
$is_lspd_open = true; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $char_name = $_POST['char_name'] ?? '';
    $age = intval($_POST['age'] ?? 0);
    $reason = trim($_POST['reason'] ?? '');
    $experience = trim($_POST['experience'] ?? '');

    if (!$is_lspd_open) {
        $error = "Pendaftaran LSPD saat ini sudah ditutup!";
    } elseif (empty($char_name) || $age <= 0 || empty($reason) || empty($experience)) {
        $error = "Semua kolom formulir wajib diisi dengan jujur!";
    } else {
        // Cek apakah karakter ini sudah pernah mengirim lamaran yang masih PENDING
        $stmtCheck = $pdo->prepare("SELECT `app_id` FROM `faction_applications` WHERE `app_char_name` = ? AND `app_status` = 'PENDING'");
        $stmtCheck->execute([$char_name]);
        
        if ($stmtCheck->fetch()) {
            $error = "Karakter ini sudah memiliki lamaran aktif yang sedang diperiksa!";
        } else {
            // Simpan data lamaran (LSPD ID = 1)
            $stmtInsert = $pdo->prepare("
                INSERT INTO `faction_applications` (`app_faction_id`, `app_ucp_name`, `app_char_name`, `app_age`, `app_reason`, `app_experience`) 
                VALUES (1, ?, ?, ?, ?, ?)
            ");
            if ($stmtInsert->execute([$ucp_name, $char_name, $age, $reason, $experience])) {
                $success = "Lamaran Anda berhasil dikirim! Silakan pantau berkala UCP Anda.";
            } else {
                $error = "Gagal mengirim lamaran, sistem error.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LSPD | Formulir Pendaftaran Academy</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-[#0a0a0a] min-h-screen text-white font-sans antialiased">

    <?php include_once __DIR__ . '/../includes/navbar.php'; ?>

    <main class="max-w-2xl mx-auto px-4 py-8 space-y-6">
        <div>
            <a href="fraksi.php?code=LSPD" class="inline-flex items-center space-x-2 text-xs font-bold text-neutral-400 hover:text-white transition bg-neutral-900 border border-neutral-800 px-4 py-2 rounded-xl">
                <span>← Kembali ke Profile LSPD</span>
            </a>
        </div>

        <div class="bg-neutral-900/80 border border-neutral-800 p-6 rounded-2xl shadow-xl space-y-6">
            <div class="border-b border-neutral-800 pb-4">
                <span class="text-[10px] text-blue-400 font-bold uppercase tracking-widest block">Formulir Penerimaan Instansi</span>
                <h1 class="text-xl font-black text-white uppercase tracking-tight">Los Santos Police Academy</h1>
            </div>

            <?php if ($error): ?>
                <div class="p-4 bg-red-500/10 border border-red-500/20 text-red-400 text-xs rounded-xl">⚠️ <?= $error ?></div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs rounded-xl">✨ <?= $success ?></div>
            <?php else: ?>

                <form action="" method="POST" class="space-y-4">
                    <!-- Pilih Karakter -->
                    <div class="space-y-1">
                        <label class="text-xs font-bold text-neutral-300 uppercase">Pilih Karakter Anda</label>
                        <select name="char_name" class="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-blue-500 transition" required>
                            <option value="">-- Pilih Karakter Bebas Faksi --</option>
                            <?php foreach ($myCharacters as $char): ?>
                                <option value="<?= $char['Char_Name'] ?>"><?= str_replace('_', ' ', $char['Char_Name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <p class="text-[10px] text-neutral-500">Hanya menampilkan karakter yang saat ini tidak terikat faksi legal manapun.</p>
                    </div>

                    <!-- Umur Karakter -->
                    <div class="space-y-1">
                        <label class="text-xs font-bold text-neutral-300 uppercase">Umur Karakter (IC Age)</label>
                        <input type="number" name="age" min="17" max="60" placeholder="Contoh: 25" class="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-blue-500 transition" required>
                    </div>

                    <!-- Alasan Mendaftar -->
                    <div class="space-y-1">
                        <label class="text-xs font-bold text-neutral-300 uppercase">Alasan Ingin Bergabung dengan LSPD</label>
                        <textarea name="reason" rows="4" placeholder="Jelaskan motivasi karakter Anda mendaftar sebagai penegak hukum..." class="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-blue-500 transition resize-none" required></textarea>
                    </div>

                    <!-- Pengalaman RP -->
                    <div class="space-y-1">
                        <label class="text-xs font-bold text-neutral-300 uppercase">Pengalaman Kerja / Roleplay Sebelumnya</label>
                        <textarea name="experience" rows="3" placeholder="Sebutkan riwayat organisasi faksi/family atau pengalaman sejenis..." class="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-blue-500 transition resize-none" required></textarea>
                    </div>

                    <button type="submit" class="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs uppercase tracking-wider transition shadow-lg shadow-blue-600/10">
                        Kirim Formulir Lamaran
                    </button>
                </form>
            <?php endif; ?>
        </div>
    </main>
</body>
</html>
