<?php
// dashboard/review_gov.php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
if (!isset($_SESSION['ucp_logged_in'])) { header("Location: ../auth/login.php"); exit; }

require_once __DIR__ . '/../config/database.php';
$pdo = getPDO();

$ucp_name = $_SESSION['ucp_ucp'] ?? '';

// Validasi Akses: Hanya Petinggi GOV (Faction 2, Rank >= 8)
$isHighCommand = false;
try {
    $stmtCheck = $pdo->prepare("SELECT `Char_FactionRank` FROM `player_characters` WHERE `Char_UCP` = ? AND `Char_Faction` = 2 AND `Char_FactionRank` >= 8 LIMIT 1");
    $stmtCheck->execute([$ucp_name]);
    if ($stmtCheck->fetch()) {
        $isHighCommand = true;
    }
} catch (Exception $e) {
    $isHighCommand = false;
}

if (!$isHighCommand) {
    header("Location: fraksi.php?code=GOV");
    exit;
}

$message = '';
$error = '';

// PROSES UPDATE LOGO FACTION
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_logo'])) {
    $logoUrl = trim($_POST['fac_logo'] ?? '');

    if (!empty($logoUrl)) {
        if (filter_var($logoUrl, FILTER_VALIDATE_URL)) {
            try {
                $stmtLogo = $pdo->prepare("UPDATE `factions` SET `fac_logo` = ? WHERE `fac_code` = 'GOV'");
                $stmtLogo->execute([$logoUrl]);
                $message = "Logo instansi GOV berhasil diperbarui!";
            } catch (Exception $e) {
                $error = "Gagal memperbarui logo: " . $e->getMessage();
            }
        } else {
            $error = "URL Logo tidak valid! Pastikan diawali http:// atau https://";
        }
    } else {
        $error = "URL Logo tidak boleh kosong!";
    }
}

// 1. PROSES TOGGLE BUKA/TUTUP REKRUTMEN
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_recruitment'])) {
    $newStatus = ($_POST['toggle_recruitment'] === 'OPEN') ? 'OPEN' : 'CLOSED';
    try {
        $stmtToggle = $pdo->prepare("UPDATE `factions` SET `fac_recruitment` = ? WHERE `fac_code` = 'GOV'");
        $stmtToggle->execute([$newStatus]);
        $message = "Status rekrutmen GOV berhasil diubah menjadi: " . $newStatus;
    } catch (Exception $e) {
        $error = "Gagal mengubah status rekrutmen: " . $e->getMessage();
    }
}

// 2. PROSES AKSI ACCEPT / REJECT LAMARAN
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action_type'])) {
    $appId = intval($_POST['app_id'] ?? 0);
    $action = $_POST['action_type']; // 'ACCEPTED' atau 'REJECTED'

    if ($appId > 0 && in_array($action, ['ACCEPTED', 'REJECTED'])) {
        try {
            $stmtUpdate = $pdo->prepare("UPDATE `faction_applications` SET `app_status` = ? WHERE `app_id` = ? AND `app_faction_id` = 2");
            $stmtUpdate->execute([$action, $appId]);
            $message = "Status berkas lamaran #" . $appId . " berhasil diperbarui menjadi " . $action . "!";
        } catch (Exception $e) {
            $error = "Gagal memperbarui status: " . $e->getMessage();
        }
    }
}

// 3. AMBIL DATA FACTION GOV (Logo & Status Recruitment)
$stmtGov = $pdo->prepare("SELECT `fac_recruitment`, `fac_logo` FROM `factions` WHERE `fac_code` = 'GOV' LIMIT 1");
$stmtGov->execute();
$govData = $stmtGov->fetch();

$currentRecruitment = strtoupper($govData['fac_recruitment'] ?? 'CLOSED');
$currentLogo = $govData['fac_logo'] ?? 'https://via.placeholder.com/150';

// 4. AMBIL DAFTAR LAMARAN GOV
$stmtList = $pdo->prepare("SELECT * FROM `faction_applications` WHERE `app_faction_id` = 2 ORDER BY `app_id` DESC");
$stmtList->execute();
$applications = $stmtList->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Peninjauan Permohonan GOV</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-[#0a0a0a] min-h-screen text-white font-sans antialiased">

    <?php include_once __DIR__ . '/../includes/navbar.php'; ?>

    <main class="max-w-5xl mx-auto px-4 py-8 space-y-6">

        <!-- Top Header Navigation -->
        <div class="flex items-center justify-between">
            <a href="fraksi.php?code=GOV" class="inline-flex items-center space-x-2 text-xs font-bold text-neutral-400 hover:text-white transition bg-neutral-900 border border-neutral-800 px-4 py-2 rounded-xl">
                <span>← Kembali ke Halaman GOV</span>
            </a>
            <span class="text-[10px] text-amber-500 font-bold uppercase tracking-widest bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/20">
                Petinggi Balai Kota
            </span>
        </div>

        <!-- Header Status Layanan & Kontrol Buka/Tutup -->
        <div class="bg-neutral-900/80 border border-neutral-800 p-6 rounded-2xl shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div class="flex items-center space-x-4">
                <div class="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-2xl shrink-0">
                    ⚖️
                </div>
                <div>
                    <h1 class="text-xl font-black text-white uppercase tracking-tight">Panel Verifikasi Berkas GOV</h1>
                    <p class="text-xs text-neutral-400 leading-relaxed">Kelola pendaftaran dan atur status rekrutmen layanan instansi.</p>
                </div>
            </div>

            <!-- Widget Kontrol Buka/Tutup Layanan -->
            <div class="bg-neutral-950 border border-neutral-800 p-3 rounded-xl flex items-center justify-between md:justify-end space-x-4">
                <div class="text-right">
                    <span class="block text-[10px] font-bold text-neutral-500 uppercase">Status Pendaftaran</span>
                    <?php if ($currentRecruitment === 'OPEN'): ?>
                        <span class="text-xs font-black text-emerald-400 flex items-center gap-1.5">
                            <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span> DIBUKA
                        </span>
                    <?php else: ?>
                        <span class="text-xs font-black text-red-500 flex items-center gap-1.5">
                            <span class="w-2 h-2 rounded-full bg-red-500"></span> DITUTUP
                        </span>
                    <?php endif; ?>
                </div>

                <form action="" method="POST">
                    <?php if ($currentRecruitment === 'OPEN'): ?>
                        <button type="submit" name="toggle_recruitment" value="CLOSED" onclick="return confirm('Tutup pendaftaran rekrutmen GOV?')" class="bg-red-600/20 hover:bg-red-600 border border-red-500/30 hover:border-red-600 text-red-400 hover:text-white text-xs font-bold px-4 py-2 rounded-lg transition">
                            Tutup Layanan
                        </button>
                    <?php else: ?>
                        <button type="submit" name="toggle_recruitment" value="OPEN" onclick="return confirm('Buka pendaftaran rekrutmen GOV?')" class="bg-emerald-600/20 hover:bg-emerald-600 border border-emerald-500/30 hover:border-emerald-600 text-emerald-400 hover:text-white text-xs font-bold px-4 py-2 rounded-lg transition">
                            Buka Layanan
                        </button>
                    <?php endif; ?>
                </form>
            </div>
        </div>

        <!-- Alert Notifikasi -->
        <?php if (!empty($message)): ?>
            <div class="bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 p-4 rounded-xl text-xs font-bold">
                ✅ <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($error)): ?>
            <div class="bg-red-500/10 border border-red-500/30 text-red-400 p-4 rounded-xl text-xs font-bold">
                ⚠️ <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <!-- Widget Pengaturan Logo Faksi (Telah Dipisah ke Luar Header) -->
        <div class="bg-neutral-900/80 border border-neutral-800 p-6 rounded-2xl shadow-xl space-y-4">
            <div class="flex items-center space-x-3 border-b border-neutral-800 pb-3">
                <span class="text-lg">🖼️</span>
                <h2 class="text-sm font-bold text-white uppercase tracking-wider">Pengaturan Logo Faksi</h2>
            </div>

            <form action="" method="POST" class="flex flex-col sm:flex-row items-center gap-4">
                <!-- Preview Logo Saat Ini -->
                <div class="w-16 h-16 rounded-xl bg-neutral-950 border border-neutral-800 flex items-center justify-center overflow-hidden shrink-0">
                    <img src="<?= htmlspecialchars($currentLogo) ?>" alt="Logo Faksi" class="w-full h-full object-contain p-1" onerror="this.src='https://via.placeholder.com/150'">
                </div>

                <div class="flex-1 w-full space-y-1">
                    <label class="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block">URL Gambar Logo (Direct Image Link)</label>
                    <input type="url" name="fac_logo" value="<?= htmlspecialchars($currentLogo) ?>" placeholder="https://i.imgur.com/example.png" required class="w-full bg-neutral-950 border border-neutral-800 focus:border-amber-500 text-white text-xs rounded-xl p-3 outline-none transition">
                </div>

                <button type="submit" name="update_logo" class="w-full sm:w-auto bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs px-5 py-3 rounded-xl uppercase tracking-wider transition self-end">
                    Simpan Logo
                </button>
            </form>
        </div>

        <!-- Daftar Berkas Permohonan -->
        <div class="space-y-4">
            <h3 class="text-xs font-black uppercase tracking-wider text-neutral-400">Berkas Permohonan Masuk</h3>
            <?php if (count($applications) === 0): ?>
                <div class="bg-neutral-900/80 border border-neutral-800 p-8 rounded-2xl text-center text-xs text-neutral-500 italic">
                    Belum ada permohonan masuk untuk instansi Government.
                </div>
            <?php else: ?>
                <?php foreach ($applications as $app): ?>
                    <div class="bg-neutral-900/80 border border-neutral-800 p-5 rounded-2xl shadow-md space-y-4">
                        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-b border-neutral-800/80 pb-3">
                            <div>
                                <span class="text-xs font-black text-amber-400 uppercase tracking-wider">
                                    <?= str_replace('_', ' ', $app['app_char_name']) ?>
                                </span>
                                <span class="text-[11px] text-neutral-500 font-mono ml-2">(UCP: <?= htmlspecialchars($app['app_ucp_name']) ?>)</span>
                            </div>
                            
                            <div>
                                <?php if ($app['app_status'] === 'PENDING'): ?>
                                    <span class="text-[10px] font-bold bg-amber-500/10 border border-amber-500/30 text-amber-400 px-3 py-1 rounded-full uppercase">PENDING</span>
                                <?php elseif ($app['app_status'] === 'ACCEPTED'): ?>
                                    <span class="text-[10px] font-bold bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 px-3 py-1 rounded-full uppercase">ACCEPTED</span>
                                <?php else: ?>
                                    <span class="text-[10px] font-bold bg-red-500/10 border border-red-500/30 text-red-500 px-3 py-1 rounded-full uppercase">REJECTED</span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-neutral-300">
                            <div>
                                <strong class="text-neutral-500 block text-[10px] uppercase">Usia Karakter:</strong>
                                <span><?= intval($app['app_age']) ?> Tahun</span>
                            </div>
                            <div>
                                <strong class="text-neutral-500 block text-[10px] uppercase">Tanggal Pengajuan:</strong>
                                <span><?= htmlspecialchars($app['app_created_at']) ?></span>
                            </div>
                            <div class="md:col-span-2 bg-neutral-950 p-3 rounded-xl border border-neutral-800/60">
                                <strong class="text-neutral-500 block text-[10px] uppercase mb-1">Visi, Misi & Alasan:</strong>
                                <p class="leading-relaxed whitespace-pre-line text-neutral-300"><?= htmlspecialchars($app['app_reason']) ?></p>
                            </div>
                            <?php if (!empty($app['app_experience'])): ?>
                                <div class="md:col-span-2 bg-neutral-950 p-3 rounded-xl border border-neutral-800/60">
                                    <strong class="text-neutral-500 block text-[10px] uppercase mb-1">Pengalaman Kerja/Organisasi:</strong>
                                    <p class="leading-relaxed whitespace-pre-line text-neutral-400"><?= htmlspecialchars($app['app_experience']) ?></p>
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Action Buttons (Accept/Reject) -->
                        <?php if ($app['app_status'] === 'PENDING'): ?>
                            <form action="" method="POST" class="flex gap-3 pt-2 border-t border-neutral-800/80">
                                <input type="hidden" name="app_id" value="<?= $app['app_id'] ?>">
                                
                                <button type="submit" name="action_type" value="ACCEPTED" onclick="return confirm('Apakah Anda yakin ingin MENERIMA permohonan ini?')" class="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs py-2.5 rounded-xl uppercase tracking-wider transition">
                                    Accept (Terima)
                                </button>
                                
                                <button type="submit" name="action_type" value="REJECTED" onclick="return confirm('Apakah Anda yakin ingin MENOLAK permohonan ini?')" class="flex-1 bg-red-600 hover:bg-red-500 text-white font-bold text-xs py-2.5 rounded-xl uppercase tracking-wider transition">
                                    Reject (Tolak)
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

    </main>
</body>
</html>
