<?php
// dashboard/settings.php
ini_set('display_errors', 1); 
error_reporting(E_ALL);

require_once __DIR__ . '/../config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['ucp_logged_in']) || $_SESSION['ucp_logged_in'] != 1) {
    header("Location: ../auth/login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SAPP-ROLEPLAY | Pengaturan Akun</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body {
            background-color: #0a0a0a;
            background-image: 
                radial-gradient(at 0% 0%, rgba(245, 158, 11, 0.05) 0px, transparent 50%),
                radial-gradient(at 100% 100%, rgba(245, 158, 11, 0.03) 0px, transparent 50%);
        }
    </style>
</head>
<body class="min-h-screen text-white font-sans antialiased">

    <?php include_once __DIR__ . '/../includes/navbar.php'; ?>

    <main class="max-w-md mx-auto px-4 py-8 space-y-6">
        
        <div>
            <h1 class="text-2xl font-extrabold tracking-tight text-white">Pengaturan Akun</h1>
            <p class="text-xs text-neutral-400">Pilih opsi konfigurasi keamanan UCP Anda</p>
        </div>

        <!-- PILIHAN MENU SETTINGS -->
        <div class="flex flex-col space-y-3">
            
            <!-- Tombol Ganti Password -->
            <a href="change_password.php" class="flex items-center justify-between p-4 bg-neutral-900/60 border border-neutral-800/80 rounded-2xl hover:border-amber-500/50 hover:bg-neutral-900 transition group shadow-lg">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center text-amber-500 font-bold text-lg">
                        🔑
                    </div>
                    <div>
                        <h4 class="text-xs font-bold text-neutral-200 group-hover:text-amber-400 transition">Ganti Password</h4>
                        <p class="text-[10px] text-neutral-400 mt-0.5">Perbarui kata sandi akun UCP berkala</p>
                    </div>
                </div>
                <span class="text-neutral-600 group-hover:text-amber-500 transition text-xs font-bold">→</span>
            </a>

            <!-- Tombol Verifikasi Email -->
            <a href="verify_email.php" class="flex items-center justify-between p-4 bg-neutral-900/60 border border-neutral-800/80 rounded-2xl hover:border-amber-500/50 hover:bg-neutral-900 transition group shadow-lg">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center text-amber-500 font-bold text-lg">
                        📧
                    </div>
                    <div>
                        <h4 class="text-xs font-bold text-neutral-200 group-hover:text-amber-400 transition">Verifikasi Email</h4>
                        <p class="text-[10px] text-neutral-400 mt-0.5">Hubungkan email aktif untuk pemulihan</p>
                    </div>
                </div>
                <span class="text-neutral-600 group-hover:text-amber-500 transition text-xs font-bold">→</span>
            </a>

        </div>

    </main>

</body>
</html>
