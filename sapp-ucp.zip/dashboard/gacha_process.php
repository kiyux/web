<?php
// dashboard/gacha_process.php
ini_set('display_errors', 0); 
header('Content-Type: application/json');

require_once __DIR__ . '/../config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['ucp_logged_in']) || $_SESSION['ucp_logged_in'] != 1) {
    echo json_encode(['status' => 'error', 'message' => 'Silakan login terlebih dahulu.']);
    exit;
}

try {
    $pdo = getPDO();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
    
    $ucp_name = $_SESSION['ucp_ucp'] ?? '';

    if (empty($ucp_name)) {
        echo json_encode(['status' => 'error', 'message' => 'Error: Sesi UCP tidak terdeteksi. Silakan relogin!']);
        exit;
    }

    $biaya_gacha = 500;

    // 1. CEK SALDO PLAYER SEKARANG BERDASARKAN CHAR_UCP
    $stmtCek = $pdo->prepare("SELECT `Char_Money` FROM `player_characters` WHERE `Char_UCP` = ? LIMIT 1");
    $stmtCek->execute([$ucp_name]);
    $playerData = $stmtCek->fetch();

    if (!$playerData) {
        echo json_encode(['status' => 'error', 'message' => 'Karakter untuk akun UCP Anda tidak ditemukan di database!']);
        exit;
    }

    if ($playerData['Char_Money'] < $biaya_gacha) {
        echo json_encode(['status' => 'error', 'message' => 'Uang IC Anda tidak cukup! Butuh $' . number_format($biaya_gacha)]);
        exit;
    }

    // 2. POTONG UANG PLAYER KARENA PENGUNDIAN DIMULAI
    $new_balance = $playerData['Char_Money'] - $biaya_gacha;
    $stmtPotong = $pdo->prepare("UPDATE `player_characters` SET `Char_Money` = ? WHERE `Char_UCP` = ?");
    $stmtPotong->execute([$new_balance, $ucp_name]);

    // 3. DAFTAR HADIAH & PERSENTASE
    $hadiah_list = [
        0 => ['name' => 'Zonk / Coba Lagi', 'rate' => 40, 'type' => 'zonk', 'val' => 0],
        1 => ['name' => 'Bonus Uang IC $1,000', 'rate' => 30, 'type' => 'money', 'val' => 1000],
        2 => ['name' => '10 Gold Points',    'rate' => 15, 'type' => 'gold',  'val' => 10],
        3 => ['name' => 'Toy Rare Box',       'rate' => 10, 'type' => 'item',  'val' => 1002],
        4 => ['name' => 'Bonus Uang IC $5,000', 'rate' => 4,  'type' => 'money', 'val' => 5000],
        5 => ['name' => 'Kendaraan Cheetah',   'rate' => 1,  'type' => 'veh',   'val' => 415], 
    ];

    $rand = rand(1, 100);
    $currentWeight = 0;
    $winningID = 0;

    foreach ($hadiah_list as $id => $hadiah) {
        $currentWeight += $hadiah['rate'];
        if ($rand <= $currentWeight) {
            $winningID = $id;
            break;
        }
    }

    $pemenang = $hadiah_list[$winningID];

        // 4. TAMBAHKAN HADIAH KE DATABASE
    if ($pemenang['type'] === 'money') {
        $new_balance += $pemenang['val']; 
        $stmtHadiah = $pdo->prepare("UPDATE `player_characters` SET `Char_Money` = ? WHERE `Char_UCP` = ?");
        $stmtHadiah->execute([$new_balance, $ucp_name]);
    } else {
        // JIKALAU MENDAPAT TOY, GOLD, ATAU KENDARAAN, MASUKKAN KE TABEL REWARDS
        $stmtReward = $pdo->prepare("INSERT INTO `player_rewards` (`Char_UCP`, `reward_name`, `reward_type`, `reward_value`, `status`) VALUES (?, ?, ?, ?, 0)");
        $stmtReward->execute([$ucp_name, $pemenang['name'], $pemenang['type'], $pemenang['val']]);
    }

    echo json_encode([
        'status' => 'success',
        'winning_id' => $winningID,
        'prize_name' => $pemenang['name'],
        'new_balance' => '$' . number_format($new_balance)
    ]);
    exit;

} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => "Database Error: " . $e->getMessage()]);
    exit;
}
