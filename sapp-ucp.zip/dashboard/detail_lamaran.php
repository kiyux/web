<?php
// dashboard/detail_lamaran.php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
if (!isset($_SESSION['ucp_logged_in'])) { header("Location: ../auth/login.php"); exit; }

require_once __DIR__ . '/../config/database.php';

// Menggunakan fungsi getPDO() bawaan config Anda, atau membuat koneksi instan jika tidak ada
try {
    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
    $options = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION];
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
} catch (Exception $e) {
    die("Koneksi database gagal: " . $e->getMessage());
}

$ucp_name = $_SESSION['ucp_ucp'] ?? $_SESSION['ucp_username'] ?? $_SESSION['username'] ?? '';

// VALIDASI DATA: Hanya High Command LSPD (Rank >= 12) yang boleh melihat berkas ini
$stmtCheckLeader = $pdo->prepare("SELECT `Char_Faction`, `Char_FactionRank` FROM `player_characters` WHERE `Char_UCP` = ? AND `Char_Faction` = 1 AND `Char_FactionRank` >= 12 LIMIT 1");
$stmtCheckLeader->execute([$ucp_name]);
$isLeader = $stmtCheckLeader->fetch(PDO::FETCH_ASSOC);

if (!$isLeader) {
    echo "<div style='color:#ef4444; background:#0f0f0f; font-family:sans-serif; text-align:center; padding:50px; min-height:100vh;'>
            <h3 style='margin-bottom:10px;'>AKSES DITOLAK</h3>
            <p style='color:#737373; font-size:13px;'>Hanya pimpinan tinggi (High Command) LSPD yang memiliki otoritas memeriksa berkas pendaftaran.</p>
          </div>";
    exit;
}

// AMBIL ID LAMARAN DARI URL
$app_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$stmtApp = $pdo->prepare("SELECT * FROM `faction_applications` WHERE `app_id` = ? AND `app_faction_id` = 1 LIMIT 1");
$stmtApp->execute([$app_id]);
$app = $stmtApp->fetch(PDO::FETCH_ASSOC);

if (!$app) {
    echo "<div style='color:#f59e0b; background:#0f0f0f; font-family:sans-serif; text-align:center; padding:50px; min-height:100vh;'>
            <h3>BERKAS TIDAK DITEMUKAN</h3>
            <p style='color:#737373; font-size:13px;'>Data lamaran tidak valid atau telah dihapus dari sistem database.</p>
            <br><a href='review_fraksi.php' style='color:#3b82f6; text-decoration:none; font-size:13px;'>← Kembali ke Panel</a>
          </div>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LSPD Panel | Berkas Seleksi #<?= $app['app_id'] ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-[#0a0a0a] min-h-screen text-white font-sans antialiased">
    
    <?php include_once __DIR__ . '/../includes/navbar.php'; ?>
    
    <main class="max-w-3xl mx-auto px-4 py-8 space-y-6">
        
        <!-- Header Navigasi -->
        <div class="flex justify-between items-center border-b border-neutral-900 pb-4">
            <div class="space-y-0.5">
                <a href="review_fraksi.php" class="text-xs text-blue-500 hover:underline inline-flex items-center space-x-1 mb-1">
                    <span>← Kembali ke Daftar Lamaran</span>
                </a>
                <h1 class="text-lg font-black uppercase text-neutral-200 tracking-wider">Lembar Verifikasi Berkas</h1>
                <p class="text-[11px] text-neutral-500">ID Registrasi Dokumen: #<?= $app['app_id'] ?> — Status: 
                    <span class="px-2 py-0.5 rounded font-bold text-[10px] 
                        <?= $app['app_status'] === 'PENDING' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' : '' ?>
                        <?= $app['app_status'] === 'ACCEPTED' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : '' ?>
                        <?= $app['app_status'] === 'REJECTED' ? 'bg-red-500/10 text-red-400 border border-red-500/20' : '' ?> uppercase">
                        <?= $app['app_status'] ?>
                    </span>
                </p>
            </div>
            
            <!-- Akses Pintas Tindakan Langsung jika status masih PENDING -->
            <?php if ($app['app_status'] === 'PENDING'): ?>
                <div class="flex space-x-2">
                    <a href="review_fraksi.php?action=prepare_accept&id=<?= $app['app_id'] ?>" class="px-3 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold uppercase transition">
                        Proses Terima
                    </a>
                    <a href="review_fraksi.php?action=reject&id=<?= $app['app_id'] ?>" onclick="return confirm('Apakah Anda yakin ingin menolak lamaran ini?')" class="px-3 py-2 bg-neutral-900 hover:bg-red-600/20 border border-neutral-800 hover:border-red-500/30 text-neutral-400 hover:text-red-400 rounded-xl text-xs font-bold uppercase transition">
                        Tolak
                    </a>
                </div>
            <?php endif; ?>
        </div>

        <!-- BLOK INFORMASI UTAMA PELAMAR -->
        <div class="bg-neutral-900/40 border border-neutral-900 rounded-2xl p-6 space-y-6">
            
            <!-- Bagian 1: Identitas Karakter (IC) -->
            <div class="space-y-3">
                <h3 class="text-xs font-bold text-blue-400 uppercase tracking-widest border-b border-neutral-800 pb-1">I. Data Identitas Karakter (In-Character)</h3>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    <div>
                        <span class="block text-neutral-500 text-[10px] uppercase font-semibold">Nama Lengkap Karakter:</span>
                        <p class="text-neutral-200 font-mono text-sm font-bold"><?= str_replace('_', ' ', $app['app_char_name']) ?></p>
                    </div>
                    <div>
                        <span class="block text-neutral-500 text-[10px] uppercase font-semibold">Usia / Umur Karakter:</span>
                        <p class="text-neutral-200 font-medium"><?= intval($app['app_age']) ?> Tahun</p>
                    </div>
                </div>
            </div>

            <!-- Bagian 2: Riwayat Informasi Pemilik Akun (OOC) -->
            <div class="space-y-3">
                <h3 class="text-xs font-bold text-blue-400 uppercase tracking-widest border-b border-neutral-800 pb-1">II. Informasi Pemilik Akun (Out-Of-Character)</h3>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    <div>
                        <span class="block text-neutral-500 text-[10px] uppercase font-semibold">Nama Akun UCP:</span>
                        <p class="text-neutral-300 font-semibold"><?= htmlspecialchars($app['app_ucp_name']) ?></p>
                    </div>
                    <div>
                        <span class="block text-neutral-500 text-[10px] uppercase font-semibold">Tanggal Pengiriman Berkas:</span>
                        <p class="text-neutral-400"><?= isset($app['app_created_at']) ? $app['app_created_at'] : 'Tidak terdata' ?></p>
                    </div>
                </div>
            </div>

            <!-- Bagian 3: Pertanyaan Esai Seleksi -->
            <div class="space-y-4">
                <h3 class="text-xs font-bold text-blue-400 uppercase tracking-widest border-b border-neutral-800 pb-1">III. Dokumen Jawaban Kuesioner Seleksi</h3>
                
                <div class="space-y-1">
                    <span class="block font-bold text-neutral-400 text-[10px] uppercase">Pertanyaan 1: Apa visi, misi, atau alasan utama karakter Anda ingin bergabung ke dalam instansi Kepolisian (LSPD)?</span>
                    <div class="bg-neutral-950/70 border border-neutral-900 p-4 rounded-xl text-xs text-neutral-300 leading-relaxed whitespace-pre-line font-serif italic">
                        "<?= htmlspecialchars($app['app_reason']) ?>"
                    </div>
                </div>

                <div class="space-y-1">
                    <span class="block font-bold text-neutral-400 text-[10px] uppercase">Pertanyaan 2: Deskripsikan pengalaman Roleplay (RP) Anda serta faksi/instansi apa saja yang pernah Anda ikuti sebelumnya?</span>
                    <div class="bg-neutral-950/70 border border-neutral-900 p-4 rounded-xl text-xs text-neutral-300 leading-relaxed whitespace-pre-line font-serif italic">
                        "<?= htmlspecialchars($app['app_experience']) ?>"
                    </div>
                </div>
            </div>

        </div>

        <!-- Catatan Kaki Dokumen Hukum Internal -->
        <p class="text-[10px] text-center text-neutral-600 italic">
            Dokumen ini dihasilkan secara otomatis melalui sistem pendaftaran SAPP UCP Fraksi. Segala bentuk kecurangan penulisan OOC Lie dapat dijatuhi hukuman ban sesuai ketentuan server.
        </p>

    </main>

</body>
</html>
