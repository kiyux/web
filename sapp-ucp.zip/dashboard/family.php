<?php
// dashboard/family.php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
if (!isset($_SESSION['ucp_logged_in'])) { header("Location: ../auth/login.php"); exit; }

require_once __DIR__ . '/../config/database.php';
$pdo = getPDO();

$ucp_name = $_SESSION['ucp_ucp'] ?? '';
$msg = '';

// 1. Ambil data karakter login untuk pengecekan hak akses Leader
$stmtCek = $pdo->prepare("SELECT `Char_Name`, `Char_Family`, `Char_FamilyRank` FROM `player_characters` WHERE `Char_UCP` = ? LIMIT 1");
$stmtCek->execute([$ucp_name]);
$myChar = $stmtCek->fetch();

// Tangkap ID Family yang sedang dipilih/diklik oleh user (jika ada)
$selectedFamID = isset($_GET['id']) ? intval($_GET['id']) : null;

// Cek apakah user yang login adalah LEADER dari Family yang sedang dipilih
$isLeaderOfSelected = ($myChar && $selectedFamID !== null && $myChar['Char_Family'] == $selectedFamID && $myChar['Char_FamilyRank'] >= 4);

// ==========================================
// PROSES BACKEND (HANYA UNTUK LEADER)
// ==========================================
if ($isLeaderOfSelected) {
    // A. PROSES UPDATE LATAR BELAKANG & LOGO
    if (isset($_POST['update_story'])) {
        $story_text = $_POST['story_text'] ?? '';
        $logo_url = $_POST['logo_url'] ?? '';
        
        $stmtUpdate = $pdo->prepare("UPDATE `families` SET `F_Story` = ?, `F_Logo` = ? WHERE `F_ID` = ?");
        $stmtUpdate->execute([$story_text, $logo_url, $selectedFamID]);
        $msg = "<div class='p-3 text-xs bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-xl mb-4 max-w-4xl mx-auto'>Data family berhasil diperbarui!</div>";
    }

    // B. PROSES KICK ANGGOTA
    if (isset($_POST['kick_member'])) {
        $target_name = $_POST['target_name'] ?? '';
        $stmtKick = $pdo->prepare("UPDATE `player_characters` SET `Char_Family` = -1, `Char_FamilyRank` = 0 WHERE `Char_Name` = ? AND `Char_Family` = ?");
        $stmtKick->execute([$target_name, $selectedFamID]);
        $msg = "<div class='p-3 text-xs bg-red-500/10 border border-red-500/20 text-red-400 rounded-xl mb-4 max-w-4xl mx-auto'>Anggota ".str_replace('_', ' ', $target_name)." berhasil dikeluarkan!</div>";
    }
}

// ==========================================
// QUERY DATA UNTUK TAMPILAN
// ==========================================
$familyData = null;
$memberList = [];

if ($selectedFamID !== null) {
    // Ambil detail Family yang dipilih
    $stmtFam = $pdo->prepare("SELECT * FROM `families` WHERE `F_ID` = ? LIMIT 1");
    $stmtFam->execute([$selectedFamID]);
    $familyData = $stmtFam->fetch();

    if ($familyData) {
        // Ambil list anggota dari Family yang dipilih
        $stmtMembers = $pdo->prepare("SELECT `Char_Name`, `Char_FamilyRank` FROM `player_characters` WHERE `Char_Family` = ? ORDER BY `Char_FamilyRank` DESC");
        $stmtMembers->execute([$selectedFamID]);
        $memberList = $stmtMembers->fetchAll();
    }
}

// Ambil semua daftar family untuk menu utama
$allFamilies = $pdo->query("SELECT `F_ID`, `F_Name`, `F_Story`, `F_Logo` FROM `families` ORDER BY `F_ID` ASC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Los Santos RP | Family Directory</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-[#0a0a0a] min-h-screen text-white font-sans antialiased">

    <?php include_once __DIR__ . '/../includes/navbar.php'; ?>

    <main class="max-w-5xl mx-auto px-4 py-8 space-y-6">
        
        <?= $msg ?>

        <!-- ======================================================= -->
        <!-- TAMPILAN 1: DAFTAR FAMILY (SEBELUM DIKLIK)              -->
        <!-- ======================================================= -->
        <?php if (!$familyData): ?>
            
            <div class="space-y-2">
                <h1 class="text-xl font-black uppercase tracking-wider text-amber-500">Direktori Family Server</h1>
                <p class="text-xs text-neutral-400">Silakan pilih salah satu faksi/family terdaftar di bawah untuk melihat struktur organisasi lengkap.</p>
            </div>

            <!-- KOTAK PERINGATAN OOC -->
            <div class="bg-red-500/5 border border-red-500/20 p-4 rounded-xl flex items-start space-x-3 mt-4">
                <span class="text-lg mt-0.5">⚠️</span>
                <div class="space-y-0.5">
                    <h4 class="text-xs font-black uppercase text-red-400 tracking-wider">Peringatan Keras (OOC Information)</h4>
                    <p class="text-[11px] text-neutral-400 leading-relaxed">
                        Seluruh informasi di halaman ini bersifat **Out Of Character (OOC)**. Dilarang keras membawa informasi dari web ini ke dalam game tanpa alur penyelidikan RP yang sah (Anti-Metagaming).
                    </p>
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                <?php foreach ($allFamilies as $fam): ?>
                    <a href="family.php?id=<?= $fam['F_ID'] ?>" 
                       class="flex p-5 rounded-2xl bg-neutral-900/80 border border-neutral-800/80 hover:border-amber-500/40 hover:bg-neutral-900 transition text-left group gap-4 shadow-md items-start">
                        
                        <!-- TAMPILAN LOGO DI LIST UTAMA -->
                        <div class="w-16 h-16 rounded-xl bg-neutral-950 border border-neutral-800 flex items-center justify-center overflow-hidden shrink-0">
                            <?php if (!empty($fam['F_Logo'])): ?>
                                <img src="<?= htmlspecialchars($fam['F_Logo']) ?>" class="w-full h-full object-cover group-hover:scale-110 transition duration-300" alt="Logo">
                            <?php else: ?>
                                <span class="text-lg font-black text-neutral-600 group-hover:text-amber-500 transition"><?= strtoupper(substr($fam['F_Name'], 0, 2)) ?></span>
                            <?php endif; ?>
                        </div>

                        <div class="space-y-1.5 flex-1">
                            <div class="flex justify-between items-center">
                                <span class="text-sm font-black uppercase text-neutral-100 group-hover:text-amber-400 transition"><?= htmlspecialchars($fam['F_Name']) ?></span>
                                <span class="text-[9px] bg-neutral-950 px-1.5 py-0.5 border border-neutral-800 rounded text-neutral-500 font-mono">ID: #<?= $fam['F_ID'] ?></span>
                            </div>
                            <p class="text-xs text-neutral-400 line-clamp-2 leading-relaxed">
                                <?= htmlspecialchars($fam['F_Story'] ?? 'Latar belakang cerita belum dikonfigurasi.') ?>
                            </p>
                            <div class="text-[10px] font-bold text-amber-500 flex items-center pt-1">
                                Lihat Anggota <span class="ml-1 group-hover:translate-x-1 transition-transform">→</span>
                            </div>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>

        <!-- ======================================================= -->
        <!-- TAMPILAN 2: DETAIL UTUH 1 HALAMAN (JIKA SUDAH DIKLIK)    -->
        <!-- ======================================================= -->
        <?php else: ?>
            
            <div>
                <a href="family.php" class="inline-flex items-center space-x-2 text-xs font-bold text-neutral-400 hover:text-white transition bg-neutral-900 border border-neutral-800 px-4 py-2 rounded-xl">
                    <span>← Kembali ke Daftar Family</span>
                </a>
            </div>

            <div class="space-y-6 mt-4">
                
                <!-- KARTU ATAS: LOGO, NAMA, & KAS -->
                <div class="bg-neutral-900/80 border border-neutral-800 p-6 rounded-2xl shadow-xl flex flex-col sm:flex-row justify-between items-center gap-6">
                    
                    <div class="flex items-center space-x-4 self-start sm:self-center">
                        <!-- LOGO BESAR DI DETAIL -->
                        <div class="w-20 h-20 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-center overflow-hidden shrink-0 shadow-inner">
                            <?php if (!empty($familyData['F_Logo'])): ?>
                                <img src="<?= htmlspecialchars($familyData['F_Logo']) ?>" class="w-full h-full object-cover" alt="Logo Big">
                            <?php else: ?>
                                <span class="text-2xl font-black text-neutral-700"><?= strtoupper(substr($familyData['F_Name'], 0, 2)) ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="space-y-1">
                            <span class="text-[10px] text-amber-500 font-bold uppercase tracking-widest block">Organisasi Terdaftar</span>
                            <h1 class="text-2xl font-black text-white uppercase tracking-tight"><?= htmlspecialchars($familyData['F_Name']) ?></h1>
                        </div>
                    </div>
                    
                    <div class="flex items-center space-x-4 w-full sm:w-auto justify-end">
                        <div class="bg-neutral-950 border border-neutral-800 px-5 py-3 rounded-xl text-left">
                            <span class="text-[9px] text-neutral-400 font-bold uppercase block">Nama Leader</span>
                            <span class="text-sm font-bold text-neutral-200"><?= str_replace('_', ' ', $familyData['F_Leader']) ?></span>
                        </div>
                        <div class="bg-neutral-950 border border-neutral-800 px-5 py-3 rounded-xl text-left">
                            <span class="text-[9px] text-neutral-400 font-bold uppercase block">Total Uang Kas</span>
                            <span class="text-lg font-black text-emerald-400">$<?= number_format($familyData['F_Money']) ?></span>
                        </div>
                    </div>
                </div>

                <!-- KOTAK PERINGATAN METAGAMING -->
                <div class="bg-red-500/5 border border-red-500/20 p-4 rounded-xl flex items-start space-x-3">
                    <span class="text-base mt-0.5">🚫</span>
                    <div class="space-y-0.5">
                        <h4 class="text-xs font-black uppercase text-red-400 tracking-wider">Dilarang Metagaming</h4>
                        <p class="text-[11px] text-neutral-400 leading-relaxed">
                            Melihat daftar nama anggota faksi **<?= htmlspecialchars($familyData['F_Name']) ?>** di bawah ini bersifat OOC.
                        </p>
                    </div>
                </div>

                <!-- SEJARAH / LATAR BELAKANG & FORM EDIT LEADER -->
                <div class="bg-neutral-900/80 border border-neutral-800 p-6 rounded-2xl shadow-xl space-y-3">
                    <h3 class="text-xs font-black uppercase tracking-wider text-neutral-300">Latar Belakang & Sejarah</h3>
                    
                    <?php if ($isLeaderOfSelected): ?>
                        <form method="POST" class="space-y-3">
                            <div>
                                <label class="text-[10px] uppercase font-bold text-neutral-400 block mb-1">Link URL Logo Family (Gunakan Link Gambar Direct imgur/discord/postimages. gunakan gambar 1:1)</label>
                                <input type="url" name="logo_url" class="w-full bg-neutral-950 border border-neutral-800 rounded-xl p-3 text-xs text-neutral-300 focus:outline-none focus:border-amber-500 transition" placeholder="https://i.imgur.com/contoh.png" value="<?= htmlspecialchars($familyData['F_Logo'] ?? '') ?>">
                            </div>
                            <div>
                                <label class="text-[10px] uppercase font-bold text-neutral-400 block mb-1">Cerita / Sejarah Faksi</label>
                                <textarea name="story_text" rows="6" class="w-full bg-neutral-950 border border-neutral-800 rounded-xl p-4 text-xs text-neutral-300 focus:outline-none focus:border-amber-500 transition leading-relaxed" placeholder="Tulis cerita faksi secara lengkap..."><?= htmlspecialchars($familyData['F_Story'] ?? '') ?></textarea>
                            </div>
                            <button type="submit" name="update_story" class="px-5 py-2.5 bg-amber-500 text-neutral-950 font-black text-xs rounded-xl hover:bg-amber-400 transition uppercase tracking-wider shadow-md">Simpan Perubahan Data</button>
                        </form>
                    <?php else: ?>
                        <p class="text-xs text-neutral-400 leading-relaxed bg-neutral-950/50 border border-neutral-800/50 p-4 rounded-xl whitespace-pre-line">
                            <?= htmlspecialchars($familyData['F_Story'] ?? 'Latar belakang cerita faksi belum diatur.') ?>
                        </p>
                    <?php endif; ?>
                </div>

                <!-- DAFTAR ANGGOTA -->
                <div class="bg-neutral-900/80 border border-neutral-800 p-6 rounded-2xl shadow-xl space-y-4">
                    <h3 class="text-xs font-black uppercase tracking-wider text-neutral-300">Daftar Anggota Aktif (<?= count($memberList) ?>)</h3>
                    
                    <div class="overflow-hidden border border-neutral-800 rounded-xl bg-neutral-950">
                        <table class="w-full text-left border-collapse text-xs">
                            <thead>
                                <tr class="bg-neutral-900 text-neutral-400 font-bold border-b border-neutral-800">
                                    <th class="p-3.5 pl-5">Nama Karakter</th>
                                    <th class="p-3.5">Tingkatan Pangkat</th>
                                    <?php if ($isLeaderOfSelected): ?><th class="p-3.5 text-right pr-5">Tindakan Otoritas</th><?php endif; ?>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-neutral-800/60">
                                <?php foreach ($memberList as $member): ?>
                                    <tr class="hover:bg-neutral-900/40 transition">
                                        <td class="p-3.5 pl-5 font-semibold text-neutral-200"><?= str_replace('_', ' ', $member['Char_Name']) ?></td>
                                        <td class="p-3.5">
                                            <span class="text-neutral-400 bg-neutral-900 px-2.5 py-1 border border-neutral-800/80 rounded font-mono text-[11px]">Rank <?= $member['Char_FamilyRank'] ?></span>
                                        </td>
                                        
                                        <?php if ($isLeaderOfSelected): ?>
                                            <td class="p-3.5 text-right pr-5">
                                                <?php if ($member['Char_Name'] !== $myChar['Char_Name']): ?>
                                                    <form method="POST" onsubmit="return confirm('Keluarkan anggota ini dari family?');" class="inline">
                                                        <input type="hidden" name="target_name" value="<?= $member['Char_Name'] ?>">
                                                        <button type="submit" name="kick_member" class="text-[10px] bg-red-600/10 border border-red-600/30 hover:bg-red-600 text-red-400 hover:text-white px-3 py-1.5 rounded-lg transition font-bold uppercase tracking-wider shadow-sm">KICK FROM FAMILY</button>
                                                    </form>
                                                <?php else: ?>
                                                    <span class="text-[11px] text-neutral-500 italic font-medium">Anda (Pemimpin)</span>
                                                <?php endif; ?>
                                            </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>

        <?php endif; ?>
    </main>
</body>
</html>
