<?php
// dashboard/fraksi.php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
if (!isset($_SESSION['ucp_logged_in'])) { header("Location: ../auth/login.php"); exit; }

require_once __DIR__ . '/../config/database.php';
$pdo = getPDO();

$ucp_name = $_SESSION['ucp_ucp'] ?? '';

// Validasi khusus High Command LSPD (Faction 1, Rank >= 15)
$show_lspd_panel = false;
// Validasi khusus High Command GOV (Faction 2, Rank >= 8)
$show_gov_panel = false;

if (!empty($ucp_name)) {
    try {
        // Cek Petinggi LSPD
        $stmtCheckLspd = $pdo->prepare("SELECT `Char_FactionRank` FROM `player_characters` WHERE `Char_UCP` = ? AND `Char_Faction` = 1 AND `Char_FactionRank` >= 15 LIMIT 1");
        $stmtCheckLspd->execute([$ucp_name]);
        if ($stmtCheckLspd->fetch()) { $show_lspd_panel = true; }

        // Cek Petinggi GOV
        $stmtCheckGov = $pdo->prepare("SELECT `Char_FactionRank` FROM `player_characters` WHERE `Char_UCP` = ? AND `Char_Faction` = 2 AND `Char_FactionRank` >= 8 LIMIT 1");
        $stmtCheckGov->execute([$ucp_name]);
        if ($stmtCheckGov->fetch()) { $show_gov_panel = true; }

    } catch (Exception $e) {
        $show_lspd_panel = false;
        $show_gov_panel = false;
    }
}

// Tangkap kode fraksi yang dipilih dari URL (Fixed)
$selectedCode = isset($_GET['code']) ? strtoupper($_GET['code']) : null;

$factionData = null;
$memberList = [];

if ($selectedCode !== null) {
    // Ambil detail fraksi yang dipilih
    $stmtFac = $pdo->prepare("SELECT * FROM `factions` WHERE `fac_code` = ? LIMIT 1");
    $stmtFac->execute([$selectedCode]);
    $factionData = $stmtFac->fetch();

    // Jika fraksi ditemukan, ambil daftar anggotanya berdasarkan ID Faksi
    if ($factionData) {
        $stmtMembers = $pdo->prepare("
            SELECT `Char_Name`, `Char_FactionRank` 
            FROM `player_characters` 
            WHERE `Char_Faction` = ? 
            ORDER BY `Char_FactionRank` DESC
        ");
        $stmtMembers->execute([$factionData['fac_id']]); 
        $memberList = $stmtMembers->fetchAll();
    }
}

// Ambil semua daftar fraksi untuk menu utama
$allFactions = $pdo->query("SELECT * FROM `factions` ORDER BY `fac_id` ASC")->fetchAll();

// Definisikan susunan pangkat LSPD
$lspd_ranks = [
    0 => "N/A", 1 => "BRIPDA", 2 => "BRIPTU", 3 => "BRIPKA", 4 => "AIPDA",
    5 => "AIPTU", 6 => "IPDA", 7 => "IPTU", 8 => "AKP", 9 => "KOMPOL",
    10 => "AKPB", 11 => "KOMBES", 12 => "BRIGJEN", 13 => "IRJEN", 14 => "KOMJEN", 15 => "JENDPOL"
];

// Definisikan susunan pangkat GOV / Government (Updated Rank 9 & 10)
$gov_ranks = [
    0 => "N/A", 1 => "STAFF MAGANG", 2 => "STAFF", 3 => "STAFF SENIOR", 4 => "WAKIL DIVISI",
    5 => "KEPALA DIVISI", 6 => "SEKRETARIS DAERAH", 7 => "WAKIL WALIKOTA", 8 => "WALIKOTA",
    9 => "GUBERNUR", 10 => "PRESIDEN / HIGH COMMAND"
];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Los Santos RP | Faksi Pemerintahan</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-[#0a0a0a] min-h-screen text-white font-sans antialiased">

    <?php include_once __DIR__ . '/../includes/navbar.php'; ?>

    <main class="max-w-5xl mx-auto px-4 py-8 space-y-6">

        <!-- ======================================================= -->
        <!-- TAMPILAN 1: DAFTAR FRAKSI (JIKA BELUM MEMILIH)          -->
        <!-- ======================================================= -->
        <?php if (!$factionData): ?>
            
            <div class="space-y-2">
                <h1 class="text-xl font-black uppercase tracking-wider text-amber-500">Direktori Fraksi Pemerintahan</h1>
                <p class="text-xs text-neutral-400">Silakan pilih lembaga instansi negara di bawah ini untuk melihat detail informasi.</p>
            </div>

            <!-- Peringatan OOC -->
            <div class="bg-red-500/5 border border-red-500/20 p-4 rounded-xl flex items-start space-x-3 mt-4">
                <span class="text-lg mt-0.5">⚠️</span>
                <div class="space-y-0.5">
                    <h4 class="text-xs font-black uppercase text-red-400 tracking-wider">Peringatan Keras (OOC Info)</h4>
                    <p class="text-[11px] text-neutral-400 leading-relaxed">
                        Seluruh nama anggota instansi hukum/negara yang tertera di halaman ini bersifat OOC. Dilarang menyalahgunakan info ini untuk keperluan IC tanpa melalui alur bermain peran (RP) yang sah!
                    </p>
                </div>
            </div>

            <!-- Grid Menu Fraksi -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                <?php foreach ($allFactions as $fac): ?>
                    <a href="fraksi.php?code=<?= $fac['fac_code'] ?>" 
                       class="flex p-5 rounded-2xl bg-neutral-900/80 border border-neutral-800/80 hover:border-amber-500/40 hover:bg-neutral-900 transition text-left group gap-4 items-center shadow-md">
                        
                        <div class="w-14 h-14 rounded-xl bg-neutral-950 border border-neutral-800 flex items-center justify-center overflow-hidden shrink-0">
                            <?php if (!empty($fac['fac_logo'])): ?>
                                <img src="<?= htmlspecialchars($fac['fac_logo']) ?>" class="w-full h-full object-contain p-1" alt="Logo">
                            <?php else: ?>
                                <span class="text-xs font-black text-neutral-500 group-hover:text-amber-500 transition"><?= $fac['fac_code'] ?></span>
                            <?php endif; ?>
                        </div>

                        <div class="space-y-1 flex-1">
                            <span class="text-sm font-black uppercase text-neutral-100 group-hover:text-amber-400 transition block"><?= htmlspecialchars($fac['fac_name']) ?></span>
                            <p class="text-xs text-neutral-400 line-clamp-1 leading-relaxed">
                                <?= htmlspecialchars($fac['fac_story'] ?? 'Deskripsi belum diatur.') ?>
                            </p>
                            <?php if (in_array($fac['fac_code'], ['LSPD', 'GOV'])): ?>
                                <span class="text-[9px] text-emerald-400 uppercase font-bold tracking-wider">Klik untuk Detail →</span>
                            <?php else: ?>
                                <span class="text-[9px] text-neutral-600 uppercase font-bold tracking-wider">Fitur Belum Siap</span>
                            <?php endif; ?>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>

        <!-- ======================================================= -->
        <!-- TAMPILAN 2: DETAIL FRAKSI (JIKA SUDAH DIKLIK)           -->
        <!-- ======================================================= -->
        <?php else: ?>
            
            <div>
                <a href="fraksi.php" class="inline-flex items-center space-x-2 text-xs font-bold text-neutral-400 hover:text-white transition bg-neutral-900 border border-neutral-800 px-4 py-2 rounded-xl">
                    <span>← Kembali ke Daftar Fraksi</span>
                </a>
            </div>

            <!-- PERCABANGAN DETAIL FRAKSI -->
            <?php if ($selectedCode === 'LSPD'): ?>
                <!-- DETAIL KHUSUS LSPD -->
                <?php 
                    $recStatus = strtoupper($factionData['fac_recruitment'] ?? 'CLOSED');
                    $isOpen = ($recStatus === 'OPEN');
                ?>
                <div class="space-y-6 mt-4">
                    <div class="bg-neutral-900/80 border border-neutral-800 p-6 rounded-2xl shadow-xl flex flex-col sm:flex-row justify-between items-center gap-6">
                        <div class="flex items-center space-x-4 self-start sm:self-center">
                            <div class="w-20 h-20 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-center overflow-hidden shrink-0 shadow-inner">
                                <?php if (!empty($factionData['fac_logo'])): ?>
                                    <img src="<?= htmlspecialchars($factionData['fac_logo']) ?>" class="w-full h-full object-contain p-1" alt="LSPD Logo">
                                <?php else: ?>
                                    <span class="text-xl font-black text-amber-500">🚨</span>
                                <?php endif; ?>
                            </div>
                            <div class="space-y-1">
                                <span class="text-[10px] text-blue-400 font-bold uppercase tracking-widest block">Divisi Penegakan Hukum</span>
                                <h1 class="text-2xl font-black text-white uppercase tracking-tight"><?= htmlspecialchars($factionData['fac_name']) ?></h1>
                            </div>
                        </div>

                        <div class="flex flex-col sm:flex-row items-center gap-3 w-full md:w-auto">
                            <div class="bg-neutral-950 border border-neutral-800 px-4 py-2 rounded-xl text-center w-full sm:w-auto">
                                <span class="text-[9px] text-neutral-500 font-bold uppercase block">Recruitment</span>
                                <?php if ($isOpen): ?>
                                    <span class="text-xs font-black text-emerald-400 tracking-wider uppercase animate-pulse">OPEN</span>
                                <?php else: ?>
                                    <span class="text-xs font-black text-red-500 tracking-wider uppercase">CLOSED</span>
                                <?php endif; ?>
                            </div>
                            
                            <?php if ($isOpen): ?>
                                <a href="apply_lspd.php" class="w-full sm:w-auto text-center bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs px-5 py-3 rounded-xl uppercase tracking-wider transition shadow-lg shadow-blue-600/10">
                                    Join Academy →
                                </a>
                            <?php else: ?>
                                <button disabled class="w-full sm:w-auto text-center bg-neutral-800 text-neutral-500 font-bold text-xs px-5 py-3 rounded-xl uppercase tracking-wider cursor-not-allowed">
                                    Ditutup
                                </button>
                            <?php endif; ?>

                            <div class="bg-blue-600/10 border border-blue-500/20 px-5 py-3 rounded-xl text-center w-full sm:w-auto">
                                <span class="text-[9px] text-blue-400 font-bold uppercase block">Status Instansi</span>
                                <span class="text-xs font-black text-white tracking-widest uppercase">AKTIF / LEGAL</span>
                            </div>
                        </div>
                    </div>

                    <?php if ($show_lspd_panel): ?>
                        <div class="bg-gradient-to-r from-blue-950/40 to-neutral-900/40 border border-blue-500/30 p-4 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4 shadow-lg shadow-blue-950/20">
                            <div class="flex items-center space-x-3.5 text-center sm:text-left">
                                <div class="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center text-blue-400 border border-blue-500/20 shrink-0">
                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>
                                </div>
                                <div>
                                    <h4 class="text-xs font-black uppercase text-blue-400 tracking-wider">Mako LSPD Command Panel</h4>
                                    <p class="text-[11px] text-neutral-400">Terdeteksi status Anda sebagai High Command. Anda memiliki akses peninjauan berkas rekrutmen warga baru.</p>
                                </div>
                            </div>
                            <a href="review_fraksi.php" class="w-full sm:w-auto px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs uppercase tracking-wider text-center transition shadow-md shadow-blue-950/50 whitespace-nowrap">
                                Buka Panel Lamaran →
                            </a>
                        </div>
                    <?php endif; ?>

                    <div class="bg-neutral-900/80 border border-neutral-800 p-6 rounded-2xl shadow-xl space-y-3">
                        <h3 class="text-xs font-black uppercase tracking-wider text-neutral-300">Visi, Misi & Sejarah</h3>
                        <p class="text-xs text-neutral-400 leading-relaxed bg-neutral-950/50 p-4 rounded-xl whitespace-pre-line">
                            <?= htmlspecialchars($factionData['fac_story'] ?? 'Detail visi misi belum dikonfigurasi.') ?>
                        </p>
                    </div>

                    <div class="bg-neutral-900/80 border border-neutral-800 p-6 rounded-2xl shadow-xl space-y-4">
                        <h3 class="text-xs font-black uppercase tracking-wider text-neutral-300">Daftar Roster Personel Kepolisian (<?= count($memberList) ?>)</h3>
                        <div class="overflow-hidden border border-neutral-800 rounded-xl bg-neutral-950">
                            <table class="w-full text-left border-collapse text-xs">
                                <thead>
                                    <tr class="bg-neutral-900 text-neutral-400 font-bold border-b border-neutral-800">
                                        <th class="p-3.5 pl-5">Nama Anggota Polisi</th>
                                        <th class="p-3.5 text-right pr-5">Pangkat Dinas</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-neutral-800/60">
                                    <?php if (count($memberList) === 0): ?>
                                        <tr><td colspan="2" class="p-4 text-center text-neutral-500 italic">Tidak ada personel polisi yang terdaftar saat ini.</td></tr>
                                    <?php else: ?>
                                        <?php foreach ($memberList as $member): ?>
                                            <tr class="hover:bg-neutral-900/40 transition">
                                                <td class="p-3.5 pl-5 font-semibold text-blue-400">
                                                    Officer <?= str_replace('_', ' ', $member['Char_Name']) ?>
                                                </td>
                                                <td class="p-3.5 text-right pr-5">
                                                    <span class="text-blue-400 bg-blue-950/40 px-2.5 py-1 border border-blue-800/40 rounded font-mono text-[11px] font-bold tracking-wider">
                                                        <?php 
                                                            $rNum = intval($member['Char_FactionRank']);
                                                            echo $lspd_ranks[$rNum] ?? ("RANK " . $rNum);
                                                        ?>
                                                    </span>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            <?php elseif ($selectedCode === 'GOV'): ?>
                <!-- DETAIL KHUSUS GOVERNMENT (GOV) -->
                <?php 
                    $recStatus = strtoupper($factionData['fac_recruitment'] ?? 'CLOSED');
                    $isOpen = ($recStatus === 'OPEN');
                ?>
                <div class="space-y-6 mt-4">
                    <div class="bg-neutral-900/80 border border-neutral-800 p-6 rounded-2xl shadow-xl flex flex-col sm:flex-row justify-between items-center gap-6">
                        <div class="flex items-center space-x-4 self-start sm:self-center">
                            <div class="w-20 h-20 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-center overflow-hidden shrink-0 shadow-inner">
                                <?php if (!empty($factionData['fac_logo'])): ?>
                                    <img src="<?= htmlspecialchars($factionData['fac_logo']) ?>" class="w-full h-full object-contain p-1" alt="GOV Logo">
                                <?php else: ?>
                                    <span class="text-2xl">🏛️</span>
                                <?php endif; ?>
                            </div>
                            <div class="space-y-1">
                                <span class="text-[10px] text-amber-500 font-bold uppercase tracking-widest block">Pemerintahan Kota</span>
                                <h1 class="text-2xl font-black text-white uppercase tracking-tight"><?= htmlspecialchars($factionData['fac_name']) ?></h1>
                            </div>
                        </div>

                        <div class="flex flex-col sm:flex-row items-center gap-3 w-full md:w-auto">
                            <div class="bg-neutral-950 border border-neutral-800 px-4 py-2 rounded-xl text-center w-full sm:w-auto">
                                <span class="text-[9px] text-neutral-500 font-bold uppercase block">Layanan & Rekrutmen</span>
                                <?php if ($isOpen): ?>
                                    <span class="text-xs font-black text-emerald-400 tracking-wider uppercase animate-pulse">OPEN</span>
                                <?php else: ?>
                                    <span class="text-xs font-black text-red-500 tracking-wider uppercase">CLOSED</span>
                                <?php endif; ?>
                            </div>
                            
                            <?php if ($isOpen): ?>
                                <a href="apply_gov.php" class="w-full sm:w-auto text-center bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs px-5 py-3 rounded-xl uppercase tracking-wider transition shadow-lg shadow-amber-600/10">
                                    Ajukan Permohonan →
                                </a>
                            <?php else: ?>
                                <button disabled class="w-full sm:w-auto text-center bg-neutral-800 text-neutral-500 font-bold text-xs px-5 py-3 rounded-xl uppercase tracking-wider cursor-not-allowed">
                                    Layanan Ditutup
                                </button>
                            <?php endif; ?>

                            <div class="bg-amber-600/10 border border-amber-500/20 px-5 py-3 rounded-xl text-center w-full sm:w-auto">
                                <span class="text-[9px] text-amber-400 font-bold uppercase block">Status Instansi</span>
                                <span class="text-xs font-black text-white tracking-widest uppercase">BALAI KOTA</span>
                            </div>
                        </div>
                    </div>

                    <?php if ($show_gov_panel): ?>
                        <div class="bg-gradient-to-r from-amber-950/40 to-neutral-900/40 border border-amber-500/30 p-4 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4 shadow-lg shadow-amber-950/20">
                            <div class="flex items-center space-x-3.5 text-center sm:text-left">
                                <div class="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center text-amber-400 border border-amber-500/20 shrink-0">
                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5m0 0h4m-4 0V11m0 0h4m-4 0H9" /></svg>
                                </div>
                                <div>
                                    <h4 class="text-xs font-black uppercase text-amber-400 tracking-wider">Balai Kota Command Panel</h4>
                                    <p class="text-[11px] text-neutral-400">Akses Petinggi Pemerintah. Anda dapat memroses berkas permohonan lisensi/rekrutmen warga.</p>
                                </div>
                            </div>
                            <a href="review_gov.php" class="w-full sm:w-auto px-5 py-2.5 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-xl text-xs uppercase tracking-wider text-center transition shadow-md shadow-amber-950/50 whitespace-nowrap">
                                Buka Panel Permohonan →
                            </a>
                        </div>
                    <?php endif; ?>

                    <div class="bg-neutral-900/80 border border-neutral-800 p-6 rounded-2xl shadow-xl space-y-3">
                        <h3 class="text-xs font-black uppercase tracking-wider text-neutral-300">Tugas & Layanan Balai Kota</h3>
                        <p class="text-xs text-neutral-400 leading-relaxed bg-neutral-950/50 p-4 rounded-xl whitespace-pre-line">
                            <?= htmlspecialchars($factionData['fac_story'] ?? 'Detail layanan belum dikonfigurasi.') ?>
                        </p>
                    </div>

                    <div class="bg-neutral-900/80 border border-neutral-800 p-6 rounded-2xl shadow-xl space-y-4">
                        <h3 class="text-xs font-black uppercase tracking-wider text-neutral-300">Daftar Aparat & Pejabat Pemerintah (<?= count($memberList) ?>)</h3>
                        <div class="overflow-hidden border border-neutral-800 rounded-xl bg-neutral-950">
                            <table class="w-full text-left border-collapse text-xs">
                                <thead>
                                    <tr class="bg-neutral-900 text-neutral-400 font-bold border-b border-neutral-800">
                                        <th class="p-3.5 pl-5">Nama Pejabat / Pegawai</th>
                                        <th class="p-3.5 text-right pr-5">Jabatan Dinas</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-neutral-800/60">
                                    <?php if (count($memberList) === 0): ?>
                                        <tr><td colspan="2" class="p-4 text-center text-neutral-500 italic">Belum ada pejabat/pegawai yang terdaftar saat ini.</td></tr>
                                    <?php else: ?>
                                        <?php foreach ($memberList as $member): ?>
                                            <tr class="hover:bg-neutral-900/40 transition">
                                                <td class="p-3.5 pl-5 font-semibold text-amber-400">
                                                    <?= str_replace('_', ' ', $member['Char_Name']) ?>
                                                </td>
                                                <td class="p-3.5 text-right pr-5">
                                                    <span class="text-amber-400 bg-amber-950/40 px-2.5 py-1 border border-amber-800/40 rounded font-mono text-[11px] font-bold tracking-wider">
                                                        <?php 
                                                            $rNum = intval($member['Char_FactionRank']);
                                                            echo $gov_ranks[$rNum] ?? ("RANK " . $rNum);
                                                        ?>
                                                    </span>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            <?php else: ?>
                <!-- JIKA MEMILIH FAKSI YANG BELUM SIAP -->
                <div class="bg-neutral-900/80 border border-neutral-800 p-12 rounded-2xl text-center space-y-3 max-w-md mx-auto mt-6 shadow-xl">
                    <div class="text-4xl">🛠️</div>
                    <h2 class="text-base font-black uppercase text-amber-500 tracking-wide">Faksi Sedang Dikembangkan</h2>
                    <p class="text-xs text-neutral-400 leading-relaxed">
                        Halaman untuk <strong><?= htmlspecialchars($factionData['fac_name']) ?></strong> saat ini masih dalam tahap pengerjaan.
                    </p>
                </div>
            <?php endif; ?>

        <?php endif; ?>
    </main>
</body>
</html>
