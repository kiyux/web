<?php
/**
 * dashboard/admin.php
 * Halaman Admin Panel - Mengelola Server & Player
 */
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../config/database.php';

session_start();

// 1. Proteksi Halaman Dasar (Harus Login UCP)
if (!isset($_SESSION['ucp_logged_in']) || $_SESSION['ucp_logged_in'] !== true) {
    header('Location: ../auth/login.php');
    exit;
}

$pdo = getPDO();

// 2. Ambil data UCP & Cek Level Admin
// Kita cari session ID yang aktif (apakah ucp_ID, ucp_id, atau ID)
$sessionID = $_SESSION['ucp_ID'] ?? $_SESSION['ucp_id'] ?? $_SESSION['ID'] ?? 0;

$stmtUCP = $pdo->prepare("SELECT `" . COL_ID . "`, `" . COL_USERNAME . "`, `admin_level` FROM `" . TB_ACCOUNT . "` WHERE `" . COL_ID . "` = ?");
$stmtUCP->execute([$sessionID]);
$userData = $stmtUCP->fetch();

// Jika bukan admin (misal level admin harus > 0), tendang kembali ke dashboard profile
if (!$userData || (int)$userData['admin_level'] < 1) {
    header('Location: profile.php');
    exit;
}

// 3. FITUR AKSI ADMIN: Hapus Kendaraan / Ban Player (Opsional jika tombol diklik)
if (isset($_GET['action']) && isset($_GET['target_id'])) {
    $targetID = (int)$_GET['target_id'];
    
    if ($_GET['action'] === 'delete_veh') {
        $stmtDel = $pdo->prepare("DELETE FROM `player_vehicles` WHERE `id` = ?");
        $stmtDel->execute([$targetID]);
        header('Location: admin.php?status=veh_deleted');
        exit;
    }
}

// 4. STATISTIK SERVER (Menghitung Total Data)
$totalPlayers = $pdo->query("SELECT COUNT(*) FROM `player_characters`")->fetchColumn();
$totalVehicles = $pdo->query("SELECT COUNT(*) FROM `player_vehicles`")->fetchColumn();
$totalHouses = $pdo->query("SELECT COUNT(*) FROM `house`")->fetchColumn();

// 5. AMBIL 10 KARAKTER TERBARU YANG TERDAFTAR
$stmtLatestChar = $pdo->query("SELECT `pID`, `Char_Name`, `Char_Level`, `Char_UCP` FROM `player_characters` ORDER BY `pID` DESC LIMIT 10");
$latestCharacters = $stmtLatestChar->fetchAll();

// 6. AMBIL 10 KENDARAAN TERBARU DI SERVER
$stmtLatestVeh = $pdo->query("SELECT `id`, `PVeh_OwnerID`, `PVeh_ModelID` FROM `player_vehicles` ORDER BY `id` DESC LIMIT 10");
$latestVehicles = $stmtLatestVeh->fetchAll();

// Kamus Nama Kendaraan (Sama seperti di profile.php)
$vehicleNames = [
    400 => 'Landstalker', 411 => 'Infernus', 415 => 'Cheetah', 422 => 'Bobcat',
    453 => 'Reefer',      462 => 'Faggio',     560 => 'Sultan',   586 => 'Wayfarer',
    602 => 'Alpha',       522 => 'NRG-500',    545 => 'Bullet',   534 => 'Remington'
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Los Santos RP</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Rye&display=swap" rel="stylesheet">
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="min-h-screen bg-neutral-950 text-white">

<div class="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-10">
    
    <header class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-10 border-b border-neutral-800 pb-5">
        <div>
            <h1 class="text-3xl font-bold tracking-wide text-red-500">Admin Panel</h1>
            <p class="text-neutral-400 text-sm">Selamat datang, Admin <span class="text-white font-semibold"><?= e($userData[COL_USERNAME]) ?></span> (Level: <?= (int)$userData['admin_level'] ?>)</p>
        </div>
        
        <nav class="flex items-center gap-3">
            <div class="flex flex-wrap items-center gap-3">
    <!-- 1. Tombol Kelola Kuis Rules (Amber Solid) -->
    <a href="admin_quiz.php" class="flex items-center space-x-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-neutral-950 rounded-xl text-sm transition font-semibold shadow-md shadow-amber-950/20">
        <!-- Icon Kuis (SVG) -->
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <span>+ Kelola Kuis Rules</span>
    </a>

    <!-- 2. Tombol Kelola Cerita CS (Amber Solid - Disamakan dengan tombol Kuis) -->
    <a href="admin_manage_cs.php" class="flex items-center space-x-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-neutral-950 rounded-xl text-sm transition font-semibold shadow-md shadow-amber-950/20">
        <!-- Icon Perisai/Kelola (SVG) -->
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
        </svg>
        <span>Kelola Cerita (CS)</span>
    </a>

    <!-- 3. Tombol Kembali ke UCP (Dark Border - Sebagai tombol sekunder) -->
    <a href="profile.php" class="flex items-center space-x-2 px-4 py-2 bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white rounded-xl text-sm transition font-medium border border-neutral-800">
        <!-- Icon Kembali (SVG) -->
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
        </svg>
        <span>Kembali ke UCP</span>
    </a>
</div>
            <a href="../auth/logout.php" class="px-4 py-2 bg-red-600 hover:bg-red-500 rounded-xl text-sm transition font-medium">Keluar</a>
        </nav>
    </header>

    <?php if (isset($_GET['status']) && $_GET['status'] === 'veh_deleted'): ?>
        <div class="mb-6 p-4 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 rounded-xl text-sm">
            ✓ Kendaraan berhasil dihapus dari database server!
        </div>
    <?php endif; ?>

    <section class="grid grid-cols-1 sm:grid-cols-3 gap-5 mb-10">
        <div class="bg-neutral-900/60 border border-neutral-800 rounded-2xl p-6 shadow-lg">
            <p class="text-xs uppercase tracking-widest text-neutral-400 mb-1">Total Karakter</p>
            <p class="text-3xl font-bold text-amber-400"><?= number_format($totalPlayers) ?></p>
        </div>
        <div class="bg-neutral-900/60 border border-neutral-800 rounded-2xl p-6 shadow-lg">
            <p class="text-xs uppercase tracking-widest text-neutral-400 mb-1">Total Kendaraan Server</p>
            <p class="text-3xl font-bold text-blue-400"><?= number_format($totalVehicles) ?></p>
        </div>
        <div class="bg-neutral-900/60 border border-neutral-800 rounded-2xl p-6 shadow-lg">
            <p class="text-xs uppercase tracking-widest text-neutral-400 mb-1">Total Rumah/Properti</p>
            <p class="text-3xl font-bold text-emerald-400"><?= number_format($totalHouses) ?></p>
        </div>
    </section>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        <section class="bg-neutral-900/40 border border-neutral-800/80 rounded-2xl p-5 shadow-xl">
            <h2 class="text-lg font-semibold text-amber-400 mb-4">10 Karakter Terdaftar Terbaru</h2>
            <div class="overflow-x-auto">
                <table class="w-full text-left text-sm text-neutral-300">
                    <thead class="text-xs uppercase bg-neutral-900 text-neutral-400 border-b border-neutral-800">
                        <tr>
                            <th class="p-3">pID</th>
                            <th class="p-3">Nama IC</th>
                            <th class="p-3">UCP</th>
                            <th class="p-3">Level</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-neutral-800/60">
                        <?php foreach ($latestCharacters as $char): ?>
                            <tr class="hover:bg-neutral-900/30">
                                <td class="p-3 font-mono">#<?= $char['pID'] ?></td>
                                <td class="p-3 font-medium text-white"><?= e($char['Char_Name']) ?></td>
                                <td class="p-3 text-neutral-400"><?= e($char['Char_UCP']) ?></td>
                                <td class="p-3 text-amber-400 font-bold"><?= $char['Char_Level'] ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <section class="bg-neutral-900/40 border border-neutral-800/80 rounded-2xl p-5 shadow-xl">
            <h2 class="text-lg font-semibold text-blue-400 mb-4">10 Kendaraan Server Terbaru</h2>
            <div class="overflow-x-auto">
                <table class="w-full text-left text-sm text-neutral-300">
                    <thead class="text-xs uppercase bg-neutral-900 text-neutral-400 border-b border-neutral-800">
                        <tr>
                            <th class="p-3">ID Veh</th>
                            <th class="p-3">Model/Nama</th>
                            <th class="p-3">ID Pemilik</th>
                            <th class="p-3 text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-neutral-800/60">
                        <?php foreach ($latestVehicles as $veh): ?>
                            <?php 
                                $modID = (int)$veh['PVeh_ModelID'];
                                $vName = $vehicleNames[$modID] ?? "Unknown ({$modID})";
                            ?>
                            <tr class="hover:bg-neutral-900/30">
                                <td class="p-3 font-mono">#<?= $veh['id'] ?></td>
                                <td class="p-3 text-white font-medium"><?= e($vName) ?></td>
                                <td class="p-3 text-neutral-400">Character pID: <?= $veh['PVeh_OwnerID'] ?></td>
                                <td class="p-3 text-center">
                                    <a href="admin.php?action=delete_veh&target_id=<?= $veh['id'] ?>" 
                                       onclick="return confirm('Apakah Anda yakin ingin menghapus kendaraan ini dari server?')" 
                                       class="text-xs bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 rounded-lg px-2 py-1 transition">
                                        Hapus
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>

    </div>

</div>
</body>
</html>
