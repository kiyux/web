<?php
// dashboard/change_password.php
ini_set('display_errors', 1); 
error_reporting(E_ALL);

require_once __DIR__ . '/../config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 1. PROTEKSI HALAMAN
if (!isset($_SESSION['ucp_logged_in']) || $_SESSION['ucp_logged_in'] != 1) {
    header("Location: ../auth/login.php");
    exit;
}

$status_message = "";
$status_type = ""; // 'success' atau 'error'
$sessionID = $_SESSION['ucp_ID'] ?? $_SESSION['ucp_id'] ?? $_SESSION['ID'] ?? 0;

// Menentukan langkah form (Step 1: Input Password, Step 2: Input OTP)
$step = $_SESSION['cp_step'] ?? 1;

try {
    $pdo = getPDO();
    $tabel_akun = defined('TB_ACCOUNT') ? TB_ACCOUNT : 'playerucp';
    $kolom_id = defined('COL_ID') ? COL_ID : 'ID';
    $kolom_pass = defined('COL_PASSWORD') ? COL_PASSWORD : 'password';
    $kolom_salt = defined('COL_SALT') ? COL_SALT : 'salt';
    $kolom_email = 'email'; // Sesuaikan jika di DB Anda menggunakan 'Email' (kapital)
} catch (Exception $e) {
    die("Koneksi database gagal.");
}

// 2. PROSES SUBMIT FORM
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // --- PROSES LANGKAH 1: Validasi Password & Kirim OTP via SMTP ---
    if (isset($_POST['action_request_otp'])) {
        $old_password = $_POST['old_password'] ?? '';
        $new_password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';

        if (empty($old_password) || empty($new_password) || empty($confirm_password)) {
            $status_message = "Semua kolom wajib diisi!";
            $status_type = "error";
        } elseif ($new_password !== $confirm_password) {
            $status_message = "Konfirmasi password baru tidak cocok!";
            $status_type = "error";
        } elseif (strlen($new_password) < 5) {
            $status_message = "Password baru terlalu pendek (Minimal 5 karakter)!";
            $status_type = "error";
        } else {
            // Ambil data akun dari database
            $stmt = $pdo->prepare("SELECT `{$kolom_pass}`, `{$kolom_salt}`, `{$kolom_email}` FROM `{$tabel_akun}` WHERE `{$kolom_id}` = ? LIMIT 1");
            $stmt->execute([$sessionID]);
            $user = $stmt->fetch();

            if ($user) {
                $db_hash = $user[$kolom_pass];
                $db_salt = $user[$kolom_salt];
                $user_email = $user[$kolom_email];

                if (empty($user_email)) {
                    $status_message = "Akun Anda belum menghubungkan Email. Silakan verifikasi email terlebih dahulu!";
                    $status_type = "error";
                } else {
                    // Cek kecocokan password lama (Disamakan dengan register: Password + Salt)
                    $old_hash_check = strtoupper(hash('sha256', $old_password . $db_salt));

                    if ($old_hash_check !== strtoupper($db_hash)) {
                        $status_message = "Kata sandi lama yang Anda masukkan salah!";
                        $status_type = "error";
                    } else {
                        // Generate OTP 6 Digit acak
                        $otp_code = rand(100000, 999999);
                        
                        // Siapkan data hash baru (Disamakan dengan register: Password Baru + Salt)
                        $new_hash = strtoupper(hash('sha256', $new_password . $db_salt));

                        // Simpan data sementara ke dalam Session
                        $_SESSION['cp_otp'] = $otp_code;
                        $_SESSION['cp_new_hash'] = $new_hash;
                        $_SESSION['cp_step'] = 2;
                        $step = 2;

                        // ==============================================================
                        // KASIH SETTINGAN GMAIL ANDA DI SINI
                        // ==============================================================
                        $smtp_user = "laksanabayu62@gmail.com"; 
                        $smtp_pass = "oawerilhckluptty";  // Spasi sengaja dirapatkan agar aman dibaca script

                        $to = $user_email;
                        $subject = "Kode Verifikasi Ganti Password UCP - Los Santos RP";
                        $message = "Halo,\n\nKami menerima permintaan untuk mengganti password akun UCP Anda.\n\nBerikut adalah kode verifikasi Anda:\n\n=== [ " . $otp_code . " ] ===\n\nKode ini bersifat rahasia. Jangan berikan kode ini kepada siapapun.\n\nSalam,\nLos Santos RP Team.";

                        // Eksekusi kirim email lewat Socket SMTP Gmail (Aman untuk KSWeb/Localhost)
                        $ssl_host = 'ssl://smtp.gmail.com';
                        $port = 465;
                        
                        $fp = @fsockopen($ssl_host, $port, $errno, $errstr, 15);
                        if ($fp) {
                            $headers_smtp = [
                                "From: \"Los Santos RP\" <{$smtp_user}>",
                                "To: <{$to}>",
                                "Subject: {$subject}",
                                "Date: " . date("r"),
                                "Content-Type: text/plain; charset=utf-8"
                            ];

                            fgets($fp, 512); fputs($fp, "EHLO localhost\r\n");
                            fgets($fp, 512); fputs($fp, "AUTH LOGIN\r\n");
                            fgets($fp, 512); fputs($fp, base64_encode($smtp_user) . "\r\n");
                            fgets($fp, 512); fputs($fp, base64_encode($smtp_pass) . "\r\n");
                            fgets($fp, 512); fputs($fp, "MAIL FROM: <{$smtp_user}>\r\n");
                            fgets($fp, 512); fputs($fp, "RCPT TO: <{$to}>\r\n");
                            fgets($fp, 512); fputs($fp, "DATA\r\n");
                            
                            $email_payload = implode("\r\n", $headers_smtp) . "\r\n\r\n" . $message . "\r\n.\r\n";
                            fputs($fp, $email_payload);
                            fgets($fp, 512); fputs($fp, "QUIT\r\n");
                            fclose($fp);

                            $status_message = "📧 Kode verifikasi telah dikirim ke email terdaftar Anda (" . substr($user_email, 0, 3) . "******" . strstr($user_email, '@') . ").";
                            $status_type = "success";
                        } else {
                            // Jika socket gagal (misal: internet mati)
                            // Supaya tidak stuck saat tes di lokal, kita tampilkan OTP-nya sebagai backup
                            $status_message = "⚠️ Gagal terhubung ke server SMTP Gmail. Backup OTP Anda: " . $otp_code;
                            $status_type = "success"; 
                        }
                    }
                }
            } else {
                $status_message = "Akun tidak ditemukan.";
                $status_type = "error";
            }
        }
    }

    // --- PROSES LANGKAH 2: Validasi OTP & Update Password Akhir ---
    if (isset($_POST['action_verify_otp'])) {
        $input_otp = $_POST['otp_code'] ?? '';
        
        if (empty($_SESSION['cp_otp']) || empty($_SESSION['cp_new_hash'])) {
            $status_message = "Sesi kadaluarsa. Silakan ulangi proses dari awal.";
            $status_type = "error";
            $_SESSION['cp_step'] = 1;
            $step = 1;
        } elseif ($input_otp == $_SESSION['cp_otp']) {
            $final_hash = $_SESSION['cp_new_hash'];

            $stmtUpdate = $pdo->prepare("UPDATE `{$tabel_akun}` SET `{$kolom_pass}` = ? WHERE `{$kolom_id}` = ?");
            $stmtUpdate->execute([$final_hash, $sessionID]);

            $status_message = "🔒 Berhasil! Kata sandi UCP Anda telah sukses diganti.";
            $status_type = "success";

            unset($_SESSION['cp_otp']);
            unset($_SESSION['cp_new_hash']);
            unset($_SESSION['cp_step']);
            $step = 1;
        } else {
            $status_message = "❌ Kode verifikasi OTP salah! Periksa kembali email Anda.";
            $status_type = "error";
        }
    }
    
    // Tombol Batal
    if (isset($_POST['action_cancel'])) {
        unset($_SESSION['cp_otp']);
        unset($_SESSION['cp_new_hash']);
        unset($_SESSION['cp_step']);
        header("Location: settings.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SAPP-ROLEPLAY | Ganti Password</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body {
            background-color: #0a0a0a;
            background-image: 
                radial-gradient(at 0% 0%, rgba(245, 158, 11, 0.05) 0px, transparent 50%),
                radial-gradient(at 100% 100%, rgba(245, 158, 11, 0.03) 0px, transparent 50%);
        }
    </style>
</head>
<body class="min-h-screen text-white font-sans antialiased">

    <?php include_once __DIR__ . '/../includes/navbar.php'; ?>

    <main class="max-w-md mx-auto px-4 py-8 space-y-6">
        
        <div class="flex items-center justify-between">
            <div>
                <h1 class="text-xl font-extrabold tracking-tight text-white">Ganti Password</h1>
                <p class="text-xs text-neutral-400">Verifikasi email dua langkah keamanan ganda</p>
            </div>
            <a href="settings.php" class="px-3 py-1.5 bg-neutral-900 border border-neutral-800 rounded-xl text-xs font-semibold text-neutral-400 hover:text-white transition">
                ← Kembali
            </a>
        </div>

        <?php if (!empty($status_message)): ?>
            <div class="p-4 rounded-xl text-xs font-semibold border <?= $status_type === 'success' ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : 'bg-red-500/10 border-red-500/20 text-red-400' ?>">
                <?= htmlspecialchars($status_message) ?>
            </div>
        <?php endif; ?>

        <div class="bg-neutral-900/40 border border-neutral-800/80 p-6 rounded-2xl shadow-xl">
            
            <?php if ($step === 1): ?>
                <!-- ================= FORM INPUT PASSWORD (STEP 1) ================= -->
                <form action="" method="POST" class="space-y-4">
                    <div>
                        <label class="block text-xs text-neutral-400 font-medium mb-1.5">Kata Sandi Lama</label>
                        <input type="password" name="old_password" placeholder="••••••••" required 
                               class="w-full bg-neutral-950 border border-neutral-800/80 rounded-xl px-3 py-2.5 text-xs text-neutral-200 focus:outline-none focus:border-amber-500/60 transition placeholder-neutral-700">
                    </div>
                    
                    <hr class="border-neutral-800/60 my-2">

                    <div>
                        <label class="block text-xs text-neutral-400 font-medium mb-1.5">Kata Sandi Baru</label>
                        <input type="password" name="new_password" placeholder="••••••••" required 
                               class="w-full bg-neutral-950 border border-neutral-800/80 rounded-xl px-3 py-2.5 text-xs text-neutral-200 focus:outline-none focus:border-amber-500/60 transition placeholder-neutral-700">
                    </div>
                    
                    <div>
                        <label class="block text-xs text-neutral-400 font-medium mb-1.5">Konfirmasi Kata Sandi Baru</label>
                        <input type="password" name="confirm_password" placeholder="••••••••" required 
                               class="w-full bg-neutral-950 border border-neutral-800/80 rounded-xl px-3 py-2.5 text-xs text-neutral-200 focus:outline-none focus:border-amber-500/60 transition placeholder-neutral-700">
                    </div>
                    
                    <button type="submit" name="action_request_otp" class="w-full py-3 mt-2 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold rounded-xl transition text-xs uppercase tracking-wider shadow-md">
                        Minta Kode Verifikasi Email
                    </button>
                </form>

            <?php else: ?>
                <!-- ================= FORM KONFIRMASI OTP (STEP 2) ================= -->
                <form action="" method="POST" class="space-y-4">
                    <div class="text-center py-2">
                        <span class="text-3xl">📩</span>
                        <h3 class="text-sm font-bold mt-2 text-neutral-200">Masukkan Kode OTP</h3>
                        <p class="text-[11px] text-neutral-400 mt-1">Masukkan 6 digit kode yang kami kirimkan ke kotak masuk / spam email Anda.</p>
                    </div>

                    <div>
                        <input type="text" name="otp_code" maxlength="6" placeholder="Contoh: 482910" required autocomplete="off"
                               class="w-full bg-neutral-950 border border-neutral-800/80 rounded-xl px-3 py-3 text-sm font-bold tracking-widest text-center text-amber-500 focus:outline-none focus:border-amber-500 transition placeholder-neutral-800">
                    </div>
                    
                    <div class="flex space-x-3 pt-2">
                        <button type="submit" name="action_cancel" class="w-1/3 py-2.5 bg-neutral-850 hover:bg-neutral-800 border border-neutral-800 text-neutral-400 font-bold rounded-xl transition text-xs uppercase">
                            Batal
                        </button>
                        <button type="submit" name="action_verify_otp" class="w-2/3 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl transition text-xs uppercase tracking-wider shadow-md">
                            Verifikasi & Ganti Password
                        </button>
                    </div>
                </form>
            <?php endif; ?>

        </div>

    </main>

</body>
</html>
