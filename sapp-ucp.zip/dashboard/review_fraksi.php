<?php
// dashboard/review_fraksi.php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
if (!isset($_SESSION['ucp_logged_in'])) { header("Location: ../auth/login.php"); exit; }

require_once __DIR__ . '/../config/database.php';
$pdo = getPDO();

$ucp_name = $_SESSION['ucp_ucp'] ?? '';

// VALIDASI: Hanya High Command LSPD (Rank >= 12) yang bisa masuk
$stmtCheckLeader = $pdo->prepare("SELECT `Char_Faction`, `Char_FactionRank` FROM `player_characters` WHERE `Char_UCP` = ? AND `Char_Faction` = 1 AND `Char_FactionRank` >= 12 LIMIT 1");
$stmtCheckLeader->execute([$ucp_name]);
$isLeader = $stmtCheckLeader->fetch();

if (!$isLeader) {
    echo "<div style='color:red; font-family:sans-serif; text-align:center; margin-top:50px;'>Anda tidak memiliki akses (Bukan High Command LSPD)!</div>";
    exit;
}

$showScheduleForm = false;
$targetAppId = null;
$targetCharName = '';
// Proses Update Status Recruitment jika tombol diklik
if (isset($_POST['toggle_recruitment'])) {
    $new_status = ($_POST['recruitment_status'] === 'OPEN') ? 'OPEN' : 'CLOSED';
    
    // Update langsung ke tabel factions
    $stmtUpdate = $pdo->prepare("UPDATE `factions` SET `fac_recruitment` = ? WHERE `fac_id` = 1");
    $stmtUpdate->execute([$new_status]);
    
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// Ambil Status Recruitment LSPD Saat Ini
$stmtRec = $pdo->prepare("SELECT `fac_recruitment` FROM `factions` WHERE `fac_id` = 1 LIMIT 1");
$stmtRec->execute();
$currentStatus = $stmtRec->fetchColumn() ?? 'CLOSED';

// 1. JIKA JADWAL INTERVIEW DIKIRIM (PROSES TERIMA BERKAS)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_accept'])) {
    $app_id = intval($_POST['app_id']);
    $interview_date = $_POST['interview_date'] ?? '';
    $interview_time = $_POST['interview_time'] ?? '';
    $interview_location = $_POST['interview_location'] ?? 'Markas Besar LSPD (Pershing Square)';

    $stmtApp = $pdo->prepare("SELECT * FROM `faction_applications` WHERE `app_id` = ? AND `app_status` = 'PENDING'");
    $stmtApp->execute([$app_id]);
    $appData = $stmtApp->fetch();

    if ($appData) {
        $target_ucp = $appData['app_ucp_name'];
        $target_char = $appData['app_char_name'];

        // Update status lamaran menjadi ACCEPTED (Lolos berkas)
        $pdo->prepare("UPDATE `faction_applications` SET `app_status` = 'ACCEPTED' WHERE `app_id` = ?")->execute([$app_id]);
        
        // Kirim Notifikasi Jadwal Wawancara (Pelantikan & set faksi tetap di In-Game)
        $pesanNotif = "Selamat! Lamaran berkas karakter Anda **" . str_replace('_', ' ', $target_char) . "** dinyatakan **LOLOS SELEKSI**. Anda diundang untuk mengikuti sesi *Interview* dan Pelantikan In-Game pada:<br><br>" .
                      "📅 **Tanggal:** " . htmlspecialchars($interview_date) . "<br>" .
                      "⏰ **Jam:** " . htmlspecialchars($interview_time) . " WIB<br>" .
                      "📍 **Tempat:** " . htmlspecialchars($interview_location) . "<br><br>" .
                      "Harap hadir tepat waktu menggunakan pakaian rapi dan menyiapkan mental Anda. Semoga sukses!";
                      
        $pdo->prepare("INSERT INTO `user_notifications` (`notif_ucp`, `notif_text`) VALUES (?, ?)")->execute([$target_ucp, $pesanNotif]);
        
        header("Location: review_fraksi.php?status=success_accept");
        exit;
    }
}

// 2. JIKA TOMBOL TERIMA DIKLIK (MEMBUKA FORM JADWAL)
if (isset($_GET['action']) && $_GET['action'] === 'prepare_accept' && isset($_GET['id'])) {
    $targetAppId = intval($_GET['id']);
    $stmtFind = $pdo->prepare("SELECT `app_char_name` FROM `faction_applications` WHERE `app_id` = ? AND `app_status` = 'PENDING'");
    $stmtFind->execute([$targetAppId]);
    $found = $stmtFind->fetch();
    if ($found) {
        $showScheduleForm = true;
        $targetCharName = $found['app_char_name'];
    }
}

// 3. JIKA TOMBOL TOLAK DIKLIK
if (isset($_GET['action']) && $_GET['action'] === 'reject' && isset($_GET['id'])) {
    $app_id = intval($_GET['id']);

    $stmtApp = $pdo->prepare("SELECT * FROM `faction_applications` WHERE `app_id` = ? AND `app_status` = 'PENDING'");
    $stmtApp->execute([$app_id]);
    $appData = $stmtApp->fetch();

    if ($appData) {
        $target_ucp = $appData['app_ucp_name'];
        $target_char = $appData['app_char_name'];

        $pdo->prepare("UPDATE `faction_applications` SET `app_status` = 'REJECTED' WHERE `app_id` = ?")->execute([$app_id]);
        
        $pesanNotif = "Mohon maaf, lamaran berkas karakter Anda **" . str_replace('_', ' ', $target_char) . "** di **Los Santos Police Department** telah **DITOLAK** pada tahap seleksi administrasi.";
        $pdo->prepare("INSERT INTO `user_notifications` (`notif_ucp`, `notif_text`) VALUES (?, ?)")->execute([$target_ucp, $pesanNotif]);
        
        header("Location: review_fraksi.php?status=success_reject");
        exit;
    }
}

// Ambil semua daftar lamaran LSPD yang PENDING
$applications = $pdo->query("SELECT * FROM `faction_applications` WHERE `app_faction_id` = 1 AND `app_status` = 'PENDING' ORDER BY `app_id` ASC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LSPD Panel | Review Kelulusan Academy</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-[#0a0a0a] min-h-screen text-white font-sans antialiased">
    <?php include_once __DIR__ . '/../includes/navbar.php'; ?>
    
    <main class="max-w-4xl mx-auto px-4 py-8 space-y-6">
        
        <div class="space-y-1">
            <h1 class="text-xl font-black uppercase text-blue-500 tracking-wider">LSPD High Command Panel</h1>
            <p class="text-xs text-neutral-400">Tinjau berkas pendaftaran calon Officer baru. Pelantikan resmi tetap dilakukan In-Game.</p>
        </div>
<!-- Widget Kontrol Status Recruitment LSPD -->
<div class="bg-neutral-900 border border-neutral-800 p-5 rounded-2xl mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
    <div>
        <h3 class="text-sm font-bold text-white uppercase tracking-wider">Status Recruitment LSPD</h3>
        <p class="text-xs text-neutral-400 mt-0.5">Atur apakah warga sipil dapat mengirimkan pendaftaran baru.</p>
    </div>

    <form action="" method="POST" class="flex items-center space-x-3 shrink-0">
        <!-- Badge Status -->
        <span class="px-3 py-1 rounded-full text-[11px] font-bold tracking-wider <?= $currentStatus === 'OPEN' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-red-500/10 text-red-400 border border-red-500/20' ?>">
            ● <?= $currentStatus === 'OPEN' ? 'OPEN / DIBUKA' : 'CLOSED / DITUTUP' ?>
        </span>

        <!-- Tombol Aksi -->
        <?php if ($currentStatus === 'OPEN'): ?>
            <input type="hidden" name="recruitment_status" value="CLOSED">
            <button type="submit" name="toggle_recruitment" class="px-4 py-2 bg-red-600 hover:bg-red-500 text-white font-bold rounded-xl text-xs transition uppercase">
                Tutup Pendaftaran
            </button>
        <?php else: ?>
            <input type="hidden" name="recruitment_status" value="OPEN">
            <button type="submit" name="toggle_recruitment" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs transition uppercase">
                Buka Pendaftaran
            </button>
        <?php endif; ?>
    </form>
</div>

        <!-- ================= FORM PENENTUAN JADWAL INTERVIEW ================= -->
        <?php if ($showScheduleForm): ?>
            <div class="bg-neutral-900 border border-blue-500/30 p-6 rounded-2xl shadow-xl space-y-4 max-w-md mx-auto">
                <div class="border-b border-neutral-800 pb-2">
                    <h3 class="text-xs font-black uppercase tracking-wider text-amber-500">Tentukan Jadwal Wawancara</h3>
                    <p class="text-[11px] text-neutral-400">Karakter: <span class="text-blue-400 font-bold"><?= str_replace('_', ' ', $targetCharName) ?></span></p>
                </div>
                
                <form action="review_fraksi.php" method="POST" class="space-y-3 text-xs">
                    <input type="hidden" name="app_id" value="<?= $targetAppId ?>">
                    
                    <div class="space-y-1">
                        <label class="font-bold text-neutral-400 uppercase">Tanggal / Hari Interview</label>
                        <input type="text" name="interview_date" placeholder="Contoh: Sabtu, 25 April 2026" class="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-4 py-2.5 text-white focus:outline-none focus:border-blue-500 transition" required>
                    </div>

                    <div class="space-y-1">
                        <label class="font-bold text-neutral-400 uppercase">Jam Pelaksanaan</label>
                        <input type="text" name="interview_time" placeholder="Contoh: 20:00" class="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-4 py-2.5 text-white focus:outline-none focus:border-blue-500 transition" required>
                    </div>

                    <div class="space-y-1">
                        <label class="font-bold text-neutral-400 uppercase">Lokasi Penjemputan / Tempat IC</label>
                        <input type="text" name="interview_location" value="Markas Besar LSPD (Pershing Square Room 2)" class="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-4 py-2.5 text-white focus:outline-none focus:border-blue-500 transition" required>
                    </div>

                    <div class="flex space-x-2 pt-2">
                        <button type="submit" name="submit_accept" class="flex-1 py-2 bg-emerald-600 hover:bg-emerald-500 font-bold rounded-lg uppercase tracking-wider transition">Kirim Undangan</button>
                        <a href="review_fraksi.php" class="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-center font-bold rounded-lg uppercase transition">Batal</a>
                    </div>
                </form>
            </div>
        <?php endif; ?>

        <!-- ================= DAFTAR BERKAS MASUK ================= -->
        <div class="space-y-4">
            <?php if (count($applications) === 0): ?>
                <div class="bg-neutral-900/80 border border-neutral-800 p-8 rounded-2xl text-center text-xs text-neutral-500 italic">
                    Belum ada berkas pendaftaran baru yang masuk saat ini.
                </div>
            <?php else: ?>
                <?php foreach ($applications as $app): ?>
                    <div class="bg-neutral-900/80 border border-neutral-800 p-5 rounded-2xl shadow-xl space-y-4">
                        <div class="flex justify-between items-start border-b border-neutral-800 pb-3">
                            <div>
                                <a href="detail_lamaran.php?id=<?= $app['app_id'] ?>" class="hover:underline group">
    <h3 class="text-sm font-black text-blue-400 uppercase group-hover:text-blue-300 transition">
        <?= str_replace('_', ' ', $app['app_char_name']) ?> 
        <span class="text-[10px] font-normal lowercase text-neutral-500 ml-1">(Klik untuk lihat detail)</span>
    </h3>
</a>

                                <p class="text-[10px] text-neutral-500">UCP Account: <?= htmlspecialchars($app['app_ucp_name']) ?> | Umur: <?= $app['app_age'] ?> Tahun</p>
                            </div>
                            <div class="flex space-x-2">
                                <!-- Tombol Terima diganti memanggil form set jadwal -->
                                <a href="review_fraksi.php?action=prepare_accept&id=<?= $app['app_id'] ?>" class="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-[10px] font-bold uppercase transition">Terima Berkas</a>
                                <a href="review_fraksi.php?action=reject&id=<?= $app['app_id'] ?>" class="px-3 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded-lg text-[10px] font-bold uppercase transition">Tolak</a>
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                            <div class="bg-neutral-950/50 p-3 rounded-xl border border-neutral-800/40">
                                <span class="block font-bold text-neutral-400 text-[10px] uppercase mb-1">Alasan Bergabung:</span>
                                <p class="text-neutral-300 leading-relaxed"><?= htmlspecialchars($app['app_reason']) ?></p>
                            </div>
                            <div class="bg-neutral-950/50 p-3 rounded-xl border border-neutral-800/40">
                                <span class="block font-bold text-neutral-400 text-[10px] uppercase mb-1">Pengalaman Roleplay:</span>
                                <p class="text-neutral-300 leading-relaxed"><?= htmlspecialchars($app['app_experience']) ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </main>
</body>
</html>
