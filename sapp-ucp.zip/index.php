<?php
// index.php (Halaman Utama / Landing Page)
ini_set('display_errors', 0); 
error_reporting(E_ALL);

require_once __DIR__ . '/config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$is_logged_in = isset($_SESSION['ucp_logged_in']) && $_SESSION['ucp_logged_in'] == 1;

// Mengambil username & ID dari segala kemungkinan nama session login Anda
$ucp_name = $_SESSION['ucp_ucp'] ?? $_SESSION['ucp_username'] ?? $_SESSION['username'] ?? $_SESSION['ucp_Name'] ?? $_SESSION['Char_UCP'] ?? '';
$sessionID = $_SESSION['ucp_ID'] ?? $_SESSION['ucp_id'] ?? $_SESSION['ID'] ?? 0;

// =========================================================================
// 1. KONFIGURASI IP SERVER GAME SA-MP (LEMEHOST)
// =========================================================================
$server_ip   = "15.235.173.7"; 
$server_port = 32296;            

// =========================================================================
// 2. DETEKSI STATUS & PLAYER VIA UDP QUERY (MUTLAK DECODE BINER)
// =========================================================================
$server_status = "OFFLINE";
$total_online   = 0;

$socket = @fsockopen("udp://" . $server_ip, $server_port, $errno, $errstr, 2);

if ($socket) {
    $packet = 'SAMP';
    $ip_parts = explode('.', $server_ip);
    foreach ($ip_parts as $part) {
        $packet .= chr((int)$part);
    }
    $packet .= chr($server_port & 0xFF);
    $packet .= chr($server_port >> 8 & 0xFF);
    $packet .= 'i'; 

    fwrite($socket, $packet);
    stream_set_timeout($socket, 1, 500);
    
    $buffer = fread($socket, 2048);
    fclose($socket);
    
    if ($buffer && strlen($buffer) > 11) {
        $server_status = "ONLINE";
        $pos = strpos($buffer, 'SAMP');
        if ($pos !== false) {
            $server_data = substr($buffer, $pos + 11);
            if (strlen($server_data) >= 4) {
                $unpacked = unpack('vpassword/vplayers', $server_data);
                if (isset($unpacked['players'])) {
                    $raw_players = (int)$unpacked['players'];
                    if ($raw_players >= 256 && $raw_players % 256 === 0) {
                        $total_online = $raw_players / 256;
                    } elseif ($raw_players > 1000) {
                        $total_online = $raw_players & 0xFF;
                    } else {
                        $total_online = $raw_players;
                    }
                }
            }
        }
        if ($total_online < 0) $total_online = 0;
    }
}

if ($server_status === "OFFLINE" || $total_online > 1000) {
    $api_url = "https://api.open.mp/server/" . $server_ip . ":" . $server_port;
    $ctx = stream_context_create([
        "http" => ["timeout" => 2.0, "ignore_errors" => true],
        "ssl"  => ["verify_peer" => false, "verify_peer_name" => false]
    ]);
    $response = @file_get_contents($api_url, false, $ctx);
    if ($response) {
        $data = json_decode($response, true);
        if (isset($data['status']) && ($data['status'] == 1 || $data['status'] == 'online' || isset($data['players']))) {
            $server_status = "ONLINE";
            if (isset($data['players']['online'])) {
                $total_online = (int)$data['players']['online'];
            } else if (isset($data['players']) && !is_array($data['players'])) {
                $total_online = (int)$data['players'];
            }
        }
    }
}

// =========================================================================
// 3. DATABASE INITIALIZATION & LOGIC PROCESSING
// =========================================================================
$total_registered = 0;
$char_data = null;
$initials = "";
$show_lspd_panel = false; 

try {
    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
    $options = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION];
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
    
    // Hitung total terdaftar
    $stmt_reg = $pdo->query("SELECT COUNT(*) FROM " . TB_ACCOUNT);
    $total_registered = $stmt_reg->fetchColumn();

    // Ambil data Akun UCP dahulu untuk admin_level & memvalidasi username asli jika session kosong
    $stmtUCP = $pdo->prepare("SELECT `" . COL_ID . "`, `" . COL_USERNAME . "`, `admin_level` FROM `" . TB_ACCOUNT . "` WHERE `" . COL_ID . "` = ?");
    $stmtUCP->execute([$sessionID]);
    $userData = $stmtUCP->fetch(PDO::FETCH_ASSOC);

    if ($userData) {
        if (empty($ucp_name)) {
            $ucp_name = $userData[COL_USERNAME];
        }
        
        // Ambil data Karakter untuk mendapatkan Nama IC RP (Char_Name)
        $stmtChar = $pdo->prepare("SELECT * FROM `player_characters` WHERE `Char_UCP` = ? LIMIT 1");
        $stmtChar->execute([$ucp_name]);
        $char_data = $stmtChar->fetch(PDO::FETCH_ASSOC);

        // Satukan admin_level
        if ($char_data) {
            $char_data['admin_level'] = (int)($userData['admin_level'] ?? 0);
            
            // Proses Pembuatan Inisial dari nama karakter
            $display_name = $char_data['Char_Name'] ?? $ucp_name;
            $words = explode("_", $display_name);
            foreach ($words as $w) {
                if (!empty($w)) {
                    $initials .= strtoupper(substr($w, 0, 1));
                }
            }
            $initials = substr($initials, 0, 2);
        }
    }
    
    // PROSES VALIDASI KHUSUS HIGH COMMAND LSPD
    if (!empty($ucp_name)) {
        $stmtCheckLspd = $pdo->prepare("SELECT `Char_Faction`, `Char_FactionRank` FROM `player_characters` WHERE `Char_UCP` = ? AND `Char_Faction` = 1 AND `Char_FactionRank` >= 12 LIMIT 1");
        $stmtCheckLspd->execute([$ucp_name]);
        $lspd_auth = $stmtCheckLspd->fetch(PDO::FETCH_ASSOC);

        if ($lspd_auth) {
            $show_lspd_panel = true;
        }
    }
    
    // Cadangan terakhir jika inisial huruf tetap tidak terbuat
    if (empty($initials) && !empty($ucp_name)) {
        $initials = strtoupper(substr($ucp_name, 0, 2));
    }
} catch (Exception $e) {
    $total_registered = 0;
    $show_lspd_panel = false;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SAPP-ROLEPLAY | Official UCP & Community</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body {
            background-color: #0a0a0a;
            background-image: 
                radial-gradient(at 0% 0%, rgba(245, 158, 11, 0.05) 0px, transparent 50%),
                radial-gradient(at 100% 100%, rgba(245, 158, 11, 0.03) 0px, transparent 50%);
        }
    </style>
</head>
<body class="min-h-screen text-white font-sans antialiased">

    <!-- Panggil File Navbar -->
    <?php include_once __DIR__ . '/includes/navbar.php'; ?>

    <!-- HERO SECTION -->
    <header class="max-w-4xl mx-auto px-4 text-center pt-16 pb-12 space-y-6">
        <div class="inline-flex items-center space-x-2 bg-amber-500/10 border border-amber-500/20 px-3 py-1 rounded-full text-xs text-amber-400 font-medium tracking-wide">
            <span>✨ Server SA-MP Android & PC Indonesia</span>
        </div>
        
        <h1 class="text-4xl md:text-6xl font-extrabold tracking-tight leading-none bg-gradient-to-b from-white to-neutral-400 bg-clip-text text-transparent">
            Mulai Cerita Hidup Baru Anda di <span class="bg-gradient-to-r from-amber-500 to-amber-300 bg-clip-text text-transparent">SAPP Roleplay</span>
        </h1>
        
        <p class="text-sm md:text-base text-neutral-400 max-w-xl mx-auto leading-relaxed">
            Bergabunglah dengan komunitas roleplay yang imersif. Buat karakter unik Anda, ajukan Character Story, dan taklukkan kota impian Anda sekarang juga.
        </p>

        <!-- FITUR SALIN IP SERVER OTOMATIS -->
        <div class="max-w-sm mx-auto pt-2">
            <span class="text-xs text-neutral-500 block mb-1.5 font-medium uppercase tracking-wider">Klik alamat di bawah untuk menyalin IP Server:</span>
            <div onclick="copyServerIP()" class="flex items-center justify-between bg-neutral-900 border border-neutral-800 p-3 rounded-xl cursor-pointer hover:border-amber-500/40 hover:bg-neutral-900/80 transition active:scale-95 group">
                <div class="flex items-center space-x-2.5">
                    <div class="w-2 h-2 rounded-full <?= $server_status === 'ONLINE' ? 'bg-emerald-500 animate-pulse' : 'bg-red-500' ?>"></div>
                    <span id="ipAddress" class="font-mono text-xs md:text-sm text-neutral-300 group-hover:text-amber-400 font-semibold tracking-wide"><?= $server_ip . ":" . $server_port ?></span>
                </div>
                <div class="text-neutral-500 group-hover:text-amber-500 flex items-center space-x-1">
                    <span id="copyStatus" class="text-[10px] font-bold uppercase tracking-wider hidden text-amber-500">Tersalin!</span>
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3"/></svg>
                </div>
            </div>
        </div>

        <!-- WIDGET KHUSUS PETINGGI LSPD -->
        <?php if ($show_lspd_panel): ?>
            <div class="max-w-md mx-auto bg-gradient-to-r from-blue-950/50 to-neutral-900/90 border border-blue-500/30 p-4 rounded-xl flex items-center justify-between gap-4 shadow-lg shadow-blue-950/40 text-left">
                <div class="flex items-center space-x-3">
                    <div class="w-9 h-9 rounded-lg bg-blue-500/10 flex items-center justify-center text-blue-400 border border-blue-500/20 shrink-0">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                        </svg>
                    </div>
                    <div class="space-y-0.5">
                        <h4 class="text-[11px] font-black uppercase text-blue-400 tracking-wider">LSPD High Command Panel</h4>
                        <p class="text-[10px] text-neutral-400 leading-tight">Ada berkas pendaftaran baru menunggu Anda tinjau.</p>
                    </div>
                </div>
                <a href="dashboard/review_fraksi.php" class="px-3 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg text-[10px] uppercase tracking-wider text-center transition shrink-0">
                    Review Berkas
                </a>
            </div>
        <?php endif; ?>

        <div class="pt-4 flex flex-wrap justify-center gap-4">
            <?php if ($is_logged_in): ?>
                <div class="flex flex-col items-center space-y-2">
                    <a href="dashboard/profile.php" class="px-8 py-3 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold rounded-xl transition shadow-lg shadow-amber-950/30 text-sm uppercase tracking-wider">
                        Masuk ke Dashboard UCP
                    </a>
                    <p class="text-xs text-emerald-400 font-medium">● Anda telah masuk sebagai <span class="underline font-bold"><?= htmlspecialchars(($char_data['Char_Name'] ?? $ucp_name)) ?></span></p>
                </div>
            <?php else: ?>
                <a href="auth/register.php" class="px-8 py-3 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold rounded-xl transition shadow-lg shadow-amber-950/30 text-sm">
                    Mulai Bermain (Register)
                </a>
                <a href="auth/login.php" class="px-8 py-3 bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 font-medium rounded-xl transition text-sm">
                    Login UCP
                </a>
            <?php endif; ?>
        </div>
    </header>

    <!-- LIVE SERVER STATS DISPLAY -->
    <section class="max-w-4xl mx-auto px-4 pb-8">
        <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div class="bg-gradient-to-b from-neutral-900/60 to-neutral-950 border border-neutral-900 p-4 rounded-xl text-center">
                <span class="text-[10px] font-bold uppercase tracking-widest text-neutral-500 block mb-1">Status Utama</span>
                <span class="text-sm font-black <?= $server_status === 'ONLINE' ? 'text-emerald-400' : 'text-red-500' ?>">
                    ● <?= $server_status ?>
                </span>
            </div>
            <div class="bg-gradient-to-b from-neutral-900/60 to-neutral-950 border border-neutral-900 p-4 rounded-xl text-center">
                <span class="text-[10px] font-bold uppercase tracking-widest text-neutral-500 block mb-1">Pemain Aktif</span>
                <span class="text-lg font-black text-amber-400"><?= number_format($total_online) ?> <span class="text-xs text-neutral-400 font-normal">Online</span></span>
            </div>
            <div class="bg-gradient-to-b from-neutral-900/60 to-neutral-950 border border-neutral-900 p-4 rounded-xl text-center">
                <span class="text-[10px] font-bold uppercase tracking-widest text-neutral-500 block mb-1">Warga Terdaftar</span>
                <span class="text-lg font-black text-white"><?= number_format($total_registered) ?> <span class="text-xs text-neutral-400 font-normal">Akun</span></span>
            </div>
        </div>
    </section>

    <!-- SERVER FEATURES / INFO -->
    <section class="max-w-4xl mx-auto px-4 py-8">
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="bg-neutral-900/40 border border-neutral-800/80 p-6 rounded-2xl space-y-3">
                <div class="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center text-amber-500">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg>
                </div>
                <h3 class="font-bold text-base text-neutral-200">Sistem Character Story</h3>
                <p class="text-xs text-neutral-400 leading-relaxed">Kembangkan latar belakang karakter Anda secara mendalam melalui sistem pengajuan cerita terintegrasi web yang cepat dan dinamis.</p>
            </div>
            <div class="bg-neutral-900/40 border border-neutral-800/80 p-6 rounded-2xl space-y-3">
                <div class="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center text-amber-500">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>
                </div>
                <h3 class="font-bold text-base text-neutral-200">Keamanan Akun UCP</h3>
                <p class="text-xs text-neutral-400 leading-relaxed">Seluruh data akun UCP dilindungi dengan sistem hashing berlapis, menjaga keamanan aset karakter Anda baik PC maupun Android.</p>
            </div>
            <div class="bg-neutral-900/40 border border-neutral-800/80 p-6 rounded-2xl space-y-3">
                <div class="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center text-amber-500">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" /></svg>
                </div>
                <h3 class="font-bold text-base text-neutral-200">UCP Kuis & Rules Terintegrasi</h3>
                <p class="text-xs text-neutral-400 leading-relaxed">Uji pemahaman peraturan roleplay Anda langsung melalui sistem kuis otomatis sebelum mulai membuat karakter baru di server.</p>
            </div>
        </div>
    </section>

    <!-- FOOTER -->
    <footer class="border-t border-neutral-900 py-8 text-center text-xs text-neutral-500">
        <p>&copy; 2026 SAPP Roleplay. All Rights Reserved.</p>
    </footer>

    <script>
    function copyServerIP() {
        const ipText = document.getElementById("ipAddress").innerText;
        const statusSpan = document.getElementById("copyStatus");
        
        navigator.clipboard.writeText(ipText).then(() => {
            statusSpan.classList.remove("hidden");
            setTimeout(() => {
                statusSpan.classList.add("hidden");
            }, 2000);
        }).catch(err => {
            console.error("Gagal menyalin text: ", err);
        });
    }
    </script>
</body>
</html>
