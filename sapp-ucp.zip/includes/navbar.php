<?php
// includes/navbar.php

// 1. Pastikan session sudah berjalan
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 2. Variabel Logika Utama & Status Login
$is_logged_in = isset($_SESSION['ucp_logged_in']) && $_SESSION['ucp_logged_in'] == 1;
$ucp_username = $_SESSION['ucp_username'] ?? $_SESSION['ucp_ucp'] ?? $_SESSION['username'] ?? $_SESSION['ucp_Name'] ?? $_SESSION['Char_UCP'] ?? '';
$sessionID = $_SESSION['ucp_ID'] ?? $_SESSION['ucp_id'] ?? $_SESSION['ID'] ?? 0;

// 3. Proses Aksi "Tandai Dibaca" Notifikasi SMS (Diproses Paling Atas Sebelum Render HTML)
if (isset($_POST['dismiss_notif']) && $is_logged_in) {
    $notif_id = intval($_POST['dismiss_notif']);
    
    if (!empty($ucp_username) && isset($pdo)) {
        try {
            $stmtDismiss = $pdo->prepare("UPDATE `user_notifications` SET `notif_status` = 'READ' WHERE `notif_id` = ? AND `notif_ucp` = ?");
            $stmtDismiss->execute([$notif_id, $ucp_username]);
            
            // Refresh halaman saat ini agar notifikasi langsung hilang
            header("Location: " . $_SERVER['REQUEST_URI']);
            exit;
        } catch (Exception $e) {
            // Silently fallback jika error
        }
    }
}

// 4. Ambil Notifikasi Unread untuk Widget SMS Melayang
$unreadCount = 0;
$floatingNotifs = [];

if ($is_logged_in && !empty($ucp_username) && isset($pdo)) {
    try {
        $stmtFloat = $pdo->prepare("SELECT * FROM `user_notifications` WHERE `notif_ucp` = ? AND `notif_status` = 'UNREAD' ORDER BY `notif_id` DESC");
        $stmtFloat->execute([$ucp_username]);
        $floatingNotifs = $stmtFloat->fetchAll(PDO::FETCH_ASSOC);
        $unreadCount = count($floatingNotifs);
    } catch (Exception $e) {
        $unreadCount = 0;
    }
}

// 5. Query Data Karakter untuk Inisial Profile Avatar
$char_data = $char_data ?? null;
$initials = "";

if ($is_logged_in && isset($pdo)) {
    try {
        $tabel_akun = defined('TB_ACCOUNT') ? TB_ACCOUNT : 'playerucp';
        $kolom_id = defined('COL_ID') ? COL_ID : 'ID';
        $kolom_user = defined('COL_USERNAME') ? COL_USERNAME : 'ucp';

        $stmtUCP = $pdo->prepare("SELECT `admin_level`, `{$kolom_user}` FROM `{$tabel_akun}` WHERE `{$kolom_id}` = ?");
        $stmtUCP->execute([$sessionID]);
        $userData = $stmtUCP->fetch(PDO::FETCH_ASSOC);

        if ($userData) {
            if (empty($ucp_username)) {
                $ucp_username = $userData[$kolom_user] ?? '';
            }
            
            $stmtChar = $pdo->prepare("SELECT * FROM `player_characters` WHERE `Char_UCP` = ? LIMIT 1");
            $stmtChar->execute([$ucp_username]);
            $char_data = $stmtChar->fetch(PDO::FETCH_ASSOC);
            if ($char_data) {
                $char_data['admin_level'] = (int)($userData['admin_level'] ?? 0);

                $display_name = $char_data['Char_Name'] ?? $ucp_username;
                $words = explode("_", $display_name);
                foreach ($words as $w) {
                    if (!empty($w)) $initials .= strtoupper(substr($w, 0, 1));
                }
                $initials = substr($initials, 0, 2);
            }
        }
    } catch (Exception $e) {
        // Silently fallback
    }
}

// Cadangan Inisial
if (empty($initials) && !empty($ucp_username)) {
    $words = explode("_", $ucp_username);
    foreach ($words as $w) {
        if (!empty($w)) $initials .= strtoupper(substr($w, 0, 1));
    }
    $initials = substr($initials, 0, 2);
}
if (empty($initials)) {
    $initials = "?";
}

// Menentukan Base Path Tautan
$base_url = (basename(dirname($_SERVER['PHP_SELF'])) == 'dashboard' || basename(dirname($_SERVER['PHP_SELF'])) == 'auth') ? '../' : './';
?>

<!-- NAVIGATION BAR -->
<nav class="border-b border-neutral-900 bg-neutral-950/80 backdrop-blur-md sticky top-0 z-50 text-sm">
    <div class="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
        
        <!-- Logo -->
        <div class="flex items-center space-x-2">
            <a href="<?= $base_url ?>index.php" class="text-xl font-black tracking-wider text-amber-500">
                Los Santos <span class="text-white">RP</span>
            </a>
        </div>
        
        <!-- Desktop Menu -->
        <div class="hidden md:flex items-center justify-between flex-1 ml-8">
            <div class="flex items-center space-x-4 lg:space-x-6">
                <?php if (isset($char_data['admin_level']) && $char_data['admin_level'] >= 1): ?>
                    <a href="<?= $base_url ?>dashboard/admin.php" class="px-3 py-1 bg-red-600 hover:bg-red-500 text-white font-bold rounded-lg transition shadow-md text-[11px] uppercase tracking-wide">Admin Panel</a>
                <?php endif; ?>

                <a href="<?= $base_url ?>index.php" class="font-bold tracking-wide uppercase text-amber-500 text-xs transition hover:text-amber-400">Dashboard</a>
                <a href="<?= $base_url ?>dashboard/fraksi.php" class="font-bold tracking-wide uppercase text-neutral-400 hover:text-white transition text-xs">Faction</a>
                <a href="<?= $base_url ?>dashboard/family.php" class="font-bold tracking-wide uppercase text-neutral-400 hover:text-white transition text-xs">Family</a>
                <a href="<?= $base_url ?>dashboard/gacha.php" class="font-bold tracking-wide uppercase text-neutral-400 hover:text-white transition text-xs">Roulette Gacha</a>
                <a href="<?= $base_url ?>dashboard/character_story.php" class="font-bold tracking-wide uppercase text-neutral-400 hover:text-amber-500 transition text-xs">Character Story</a>
                <a href="<?= $base_url ?>dashboard/settings.php" class="font-bold tracking-wide uppercase text-neutral-400 hover:text-amber-500 transition text-xs">Settings</a>
            </div>
            
            <div class="flex items-center space-x-4 border-l border-neutral-800 pl-4">
                <?php if ($is_logged_in): ?>
                    <a href="<?= $base_url ?>auth/logout.php" class="font-bold text-xs text-red-400 hover:text-red-300 transition uppercase tracking-wide">Keluar</a>
                    <a href="<?= $base_url ?>dashboard/profile.php" title="Lihat Profil Lengkap Anda" class="w-8 h-8 rounded-full bg-amber-500 border border-amber-400 flex items-center justify-center text-neutral-950 shadow-md hover:bg-amber-400 transition transform hover:scale-105 select-none">
                        <span class="text-xs font-black tracking-wider text-neutral-950"><?= htmlspecialchars($initials) ?></span>
                    </a>
                <?php else: ?>
                    <a href="<?= $base_url ?>auth/login.php" class="font-bold tracking-wide uppercase text-neutral-400 hover:text-amber-500 transition text-xs">Masuk</a>
                <?php endif; ?>
            </div>
        </div>

        <!-- Tombol Hamburger Mobile -->
        <div class="md:hidden flex items-center">
            <button id="hamburgerBtn" class="text-neutral-400 hover:text-white focus:outline-none p-2 rounded-lg bg-neutral-900/50 border border-neutral-800">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path id="hamburgerIcon" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
                </svg>
            </button>
        </div>
    </div>

    <!-- Mobile Menu Dropdown -->
    <div id="mobileMenu" class="hidden md:hidden border-t border-neutral-900 bg-neutral-950 px-4 py-4 space-y-3">
        <?php if (isset($char_data['admin_level']) && $char_data['admin_level'] >= 1): ?>
            <a href="<?= $base_url ?>dashboard/admin.php" class="block text-center py-2 bg-red-600 hover:bg-red-500 text-white font-medium rounded-xl transition text-xs">Admin Panel</a>
        <?php endif; ?>

        <a href="<?= $base_url ?>index.php" class="block font-bold tracking-wide uppercase text-amber-500 text-xs py-1">Dashboard</a>
        <a href="<?= $base_url ?>dashboard/fraksi.php" class="block font-bold tracking-wide uppercase text-neutral-400 hover:text-white transition text-xs py-1">Faction</a>
        <a href="<?= $base_url ?>dashboard/family.php" class="block font-bold tracking-wide uppercase text-neutral-400 hover:text-white transition text-xs py-1">Family</a>
        <a href="<?= $base_url ?>dashboard/gacha.php" class="block font-bold tracking-wide uppercase text-neutral-400 hover:text-white transition text-xs py-1">Roulette Gacha</a>
        <a href="<?= $base_url ?>dashboard/character_story.php" class="block font-bold tracking-wide uppercase text-neutral-400 hover:text-white transition text-xs py-1">Character Story</a>
        <a href="<?= $base_url ?>dashboard/settings.php" class="block font-bold tracking-wide uppercase text-neutral-400 hover:text-white transition text-xs py-1">Settings</a>
        
        <div class="border-t border-neutral-900 pt-3 flex items-center justify-between">
            <?php if ($is_logged_in): ?>
                <a href="<?= $base_url ?>dashboard/profile.php" class="flex items-center space-x-3 group">
                    <div class="w-8 h-8 rounded-full bg-amber-500 border border-amber-400 flex items-center justify-center text-neutral-950 font-bold group-hover:bg-amber-400">
                        <span class="text-xs font-black tracking-wider text-neutral-950"><?= htmlspecialchars($initials) ?></span>
                    </div>
                    <span class="text-xs text-neutral-400 group-hover:text-white">Lihat Profil</span>
                </a>
                <a href="<?= $base_url ?>auth/logout.php" class="font-bold text-xs text-red-400 hover:text-red-300 py-1">Keluar</a>
            <?php else: ?>
                <a href="<?= $base_url ?>auth/login.php" class="block text-center w-full py-2 bg-neutral-900 border border-neutral-800 font-bold tracking-wide uppercase text-neutral-300 hover:text-white rounded-xl transition text-xs">Masuk</a>
            <?php endif; ?>
        </div>
    </div>
</nav>

<!-- WIDGET NOTIFIKASI MELAYANG (FLOATING SMS CONTAINER) -->
<?php if ($unreadCount > 0): ?>
    <div class="fixed bottom-6 right-6 z-50 flex flex-col items-end space-y-3">
        
        <!-- POPUP BOX SMS -->
        <div id="smsPopupBox" class="hidden w-80 max-w-[calc(100vw-3rem)] bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl p-4 space-y-3 transition-all duration-300">
            <div class="flex items-center justify-between pb-2 border-b border-neutral-800">
                <div class="flex items-center space-x-2">
                    <span class="text-xs font-black uppercase text-amber-400 tracking-wider">💬 Kotak Masuk SMS</span>
                    <span class="bg-amber-500/20 text-amber-400 text-[10px] font-bold px-2 py-0.5 rounded-full font-mono"><?= $unreadCount ?> Baru</span>
                </div>
                <button onclick="toggleSmsPopup()" class="text-neutral-500 hover:text-white text-xs font-bold px-1">✕</button>
            </div>

            <!-- Daftar SMS -->
            <div class="max-h-60 overflow-y-auto space-y-2 pr-1">
                <?php foreach ($floatingNotifs as $notif): ?>
                    <div class="bg-neutral-950 border border-neutral-800/80 p-3 rounded-xl space-y-2">
                        <p class="text-xs text-neutral-300 leading-relaxed">
                            <?= htmlspecialchars($notif['notif_text'] ?? '') ?>
                        </p>
                        <div class="flex justify-end">
                            <form action="" method="POST">
                                <button type="submit" name="dismiss_notif" value="<?= $notif['notif_id'] ?>" class="text-[10px] font-bold uppercase text-neutral-400 hover:text-emerald-400 transition bg-neutral-900 border border-neutral-800 px-2 py-1 rounded-lg flex items-center space-x-1">
                                    <span>Tandai Dibaca</span>
                                    <span>✓</span>
                                </button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- TOMBOL FLOATING LOGO PESAN -->
        <button onclick="toggleSmsPopup()" class="relative bg-amber-500 hover:bg-amber-400 text-neutral-950 p-3.5 rounded-full shadow-lg shadow-amber-500/20 transition-all transform active:scale-95 flex items-center justify-center group">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 012 2h-5l-5 5v-5z" />
            </svg>
            <span class="absolute -top-1 -right-1 bg-red-600 text-white text-[10px] font-extrabold w-5 h-5 rounded-full flex items-center justify-center border-2 border-[#0a0a0a] animate-pulse">
                <?= $unreadCount ?>
            </span>
        </button>

    </div>

    <script>
        function toggleSmsPopup() {
            const popup = document.getElementById('smsPopupBox');
            if (popup) {
                popup.classList.toggle('hidden');
            }
        }
    </script>
<?php endif; ?>

<!-- JavaScript Hamburger Mobile Menu -->
<script>
document.addEventListener("DOMContentLoaded", function() {
    const btn = document.getElementById("hamburgerBtn");
    const menu = document.getElementById("mobileMenu");
    const icon = document.getElementById("hamburgerIcon");

    if(btn && menu) {
        btn.addEventListener("click", () => {
            menu.classList.toggle("hidden");
            if(menu.classList.contains("hidden")) {
                icon.setAttribute("d", "M4 6h16M4 12h16M4 18h16");
            } else {
                icon.setAttribute("d", "M6 18L18 6M6 6l12 12");
            }
        });
    }
});
</script>
