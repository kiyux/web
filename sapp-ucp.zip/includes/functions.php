<?php
/**
 * includes/functions.php
 * Kumpulan helper keamanan yang dipakai di seluruh project.
 */

require_once __DIR__ . '/../config/database.php';

/**
 * Membuat salt acak yang formatnya konsisten dengan contoh salt gamemode
 * Anda (campuran huruf, angka, dan simbol, panjang 16 karakter).
 * random_bytes() bersifat cryptographically secure (CSPRNG).
 */
function generateSalt(int $length = 16): string
{
    // [GANTI DI SINI] jika gamemode PAWN Anda memakai charset salt yang berbeda
    $charset = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*_-:.,[]/';
    $max = strlen($charset) - 1;
    $salt = '';
    for ($i = 0; $i < $length; $i++) {
        // random_int lebih aman dari rand()/mt_rand() untuk keperluan kriptografi
        $salt .= $charset[random_int(0, $max)];
    }
    return $salt;
}

/**
 * Hash password sesuai skema gamemode: SHA-256(salt+password) atau
 * SHA-256(password+salt), lalu di-uppercase agar sama persis dengan
 * format hash yang tersimpan di kolom `password` (64 char kapital).
 *
 * CATATAN KEAMANAN: SHA-256+salt jauh lebih lemah dibanding bcrypt/argon2
 * terhadap serangan brute-force offline (SHA-256 didesain cepat, bukan
 * lambat). Ini dipertahankan HANYA demi kompatibilitas dengan skrip PAWN
 * yang sudah berjalan. Jika suatu saat Anda bisa mengubah gamemode juga,
 * migrasi ke password_hash()/PASSWORD_ARGON2ID sangat disarankan.
 */
function hashPassword(string $password, string $salt): string
{
    $combined = (HASH_ORDER === 'password_salt')
        ? $password . $salt
        : $salt . $password;
    return strtoupper(hash('sha256', $combined));
}

/**
 * Validasi username: hanya huruf, angka, underscore, 3-24 karakter.
 * Mencegah karakter aneh yang bisa dipakai untuk manipulasi form/SQLi
 * (walau prepared statement sudah jadi lapisan utama, validasi input
 * tetap wajib sebagai defense-in-depth).
 */
function isValidUsername(string $username): bool
{
    return (bool) preg_match('/^[A-Za-z0-9_]{3,24}$/', $username);
}

/**
 * Format nama karakter in-game SA-MP: "Nama_Belakang" (huruf awal kapital).
 */
function isValidCharacterName(string $name): bool
{
    return (bool) preg_match('/^[A-Z][a-z]+_[A-Z][a-z]+$/', $name);
}

function isValidEmail(string $email): bool
{
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Password minimal 8 karakter, kombinasi huruf & angka.
 * (Ini password akun UCP yang diinput user di form register — sebelum
 * di-hash — bukan validasi terhadap hash yang sudah ada di DB.)
 */
function isStrongPassword(string $password): bool
{
    return (bool) preg_match('/^(?=.*[A-Za-z])(?=.*\d).{8,64}$/', $password);
}

/**
 * Sanitasi output untuk mencegah XSS saat menampilkan data user di HTML.
 * Selalu bungkus data dinamis dengan fungsi ini saat di-echo ke HTML.
 */
function e(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

/**
 * CSRF token: cegah form disubmit dari situs lain / auto-submit tersembunyi.
 */
function csrfToken(): string
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verifyCsrfToken(?string $token): bool
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    return isset($_SESSION['csrf_token'], $token)
        && hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Rate limiting sederhana berbasis session, untuk memperlambat brute-force
 * pada form login/register dari sisi aplikasi (idealnya dikombinasikan
 * dengan rate limiting di level web server / firewall juga).
 */
function tooManyAttempts(string $key, int $maxAttempts = 5, int $windowSeconds = 300): bool
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    $now = time();
    $bucket = $_SESSION['attempts'][$key] ?? ['count' => 0, 'first' => $now];

    if ($now - $bucket['first'] > $windowSeconds) {
        $bucket = ['count' => 0, 'first' => $now];
    }
    $bucket['count']++;
    $_SESSION['attempts'][$key] = $bucket;

    return $bucket['count'] > $maxAttempts;
}
